# PacketLab

## Prerequisite
- A [POSIX.1-2004](https://pubs.opengroup.org/onlinepubs/009695399/nfindex.html) compliant OS.

### Endpoint-specific (`pktlabme`) Prerequisite
- `me.conf` file (prototype available in the `pktlab/src` directory)
> There are six available options in me.conf, namely
>> - `BufMax`: The max buffer size (for nsend and ndata messages) for the endpoint.
>> - `VMemLocalAddrStrIPv4`: Exported local interface addresses (IPv4) in the form of a comma-separated list of addresses __with subnet masks__ (e.g. `127.0.0.1/8,192.168.0.1/24`).
>> - `VMemLocalAddrStrIPv6`: Exported local interface addresses (IPv6) in the form of a comma-separated list of addresses (e.g. `2606:4700:4700::1111,::1`).
>> - `VMemLocalDNSAddrStrIPv4`: Exported local DNS resolver addresses (IPv4) in the form of a comma-separated list of addresses (e.g. `8.8.8.8,1.1.1.1`).
>> - `VMemLocalDNSAddrStrIPv6`: Exported local DNS resolver addresses (IPv6) in the form of a comma-separated list of addresses (e.g. `2001:4860:4860::8888,2606:4700:4700::1111`).
>> - `HostID`: The ID for the endpoint.

> Lines starting with `#` are comments and are ignored by the parser.

> Comma-separated lists should not contain spaces in the middle (e.g. `127.0.0.1/8, 192.168.0.1/24` is __NOT__ acceptable).

> Note that it is highly likely that the default values (especially for those address settings) may be invalid. One should refer to the comments in the `me.conf` file and modify the settings to match their specific environment & needs.

## How to compile the endpoint and pktlab library?
To compile the endpoint (`pktlabme`) and `libpktlab`, first `git clone` the repo, and then run
```
make
```
in the `pktlab/src` directory.

## How to compile the example experiment controllers?
To compile the example experiment controllers (`tcp_ec` and `udp_ec`), run
```
make
```
in the `pktlab/src/example` directory.

## How to run the endpoint?
To run the endpoint, run
```
./pktlabme -c MECONF_PATH pktlab.caida.org,5566
```
which tries to connect to the experiment controller at pktlab.caida.org (resolves to vector 1 workstation) port 5566.
> `MECONF_PATH` is the path to the `me.conf` file mentioned in the prerequisite. If not supplied, `pktlabme` by default searches for the `me.conf` file in the current working directory. Note that a configured sample version of the file is available at `/etc/pktlabme/me.conf` on both vector 0 and 1.

> Note that currently, the First-Shot project's controller lives on port 20556 on vector 1, which is the default address if no argument was provided to the endpoint program. Please remember to provide the argument to the program or the endpoint will connect to the First-Shot project's controller.

## How to run the example experiment controller?
To run the example experiment controller, run
```
./tcp_ec
```
or
```
./upd_ec
```
directly.
> Note that both example controllers listen on port 20556, which is currently occupied by the First-Shot project's controller. One will need to change the listening port of the controllers before running them on vector 1

> Note that in the case of vector 1 running the controllers while remote endpoints connect to vector 1, due to there being a firewall on vector 1, one will need to have the controller listen on configured open ports such as port 5566 or port 5567 (for now, one will need to change the source of the example controllers to do this) to prevent firewall blocking.
