// raw_ec.c
// PacketLab Raw Socket Experiment Controller Example Program
// Use pktlab measurement endpoint to run ping (for IPv4 only)
//

#include <assert.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <arpa/inet.h>
#include <netinet/ip.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include "pktlab.h"

#define PROBENUM 10
#define DELAY_PROBE_SEC 5
#define WAIT_REPLY_SEC (PROBENUM+DELAY_PROBE_SEC+2)

#define ADDRSTRLEN 64
#define BUFSZ 0x10000

#define IP4_ADDRLEN PKTLAB_IPV4_WO_MSK_ADDR_LEN
#define IP_HDRLEN 20

#define PROTO_2_ADDRFAM(proto) (((proto & PKTLAB_NETPROTO_MASK) == PKTLAB_IP4_PROTO) ?\
    AF_INET : AF_INET6)
#define PROTO_2_ADDRLEN(proto) (((proto & PKTLAB_NETPROTO_MASK) == PKTLAB_IP4_PROTO) ?\
    PKTLAB_IPV4_WO_MSK_ADDR_LEN : PKTLAB_IPV6_ADDR_LEN)

#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#define MAX(a, b) (((a) > (b)) ? (a) : (b))

struct IPHdr {
    uint8_t ihl:4;
    uint8_t ver:4;
    uint8_t tos;
    uint16_t len;
    uint16_t id;
    uint16_t frag;
    uint8_t ttl;
    uint8_t proto;
    uint16_t cksum;
    uint32_t src;
    uint32_t dst;
};

struct ICMPHdr {
    uint8_t type;
    uint8_t code;
    uint16_t checksum;
    uint16_t id;
    uint16_t sequence;
};

static void perror_exit(const char * str, int exit_val) {
    perror(str);
    exit(exit_val);
}

static void print_err_exit(int exit_val, const char * fmt, ...) {
    static char buf[256];
    va_list args;

    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    fprintf(stderr, "%s", buf);

    exit(exit_val);
}

static int create_nopen (
    struct pktlab_message * msg,
    uint8_t sktid, uint8_t proto,
    uint8_t intf, uint32_t rbufsize)
{
    msg->type = PKTLAB_NOPEN_MESSAGE;
    msg->nopen.sktid = sktid;
    msg->nopen.proto = proto;
    msg->nopen.intf = intf;
    msg->nopen.rbufsz = rbufsize;

    return 0;
}

static int create_nsend (
    struct pktlab_message * msg,
    uint8_t sktid, uint8_t proto,
    uint16_t tidx, pktlab_time_t time,
    uint32_t len, const void * ptr)
{
    msg->type = PKTLAB_NSEND_MESSAGE;
    msg->nsend.sktid = sktid;
    msg->nsend.proto = proto;
    msg->nsend.tidx = tidx;
    msg->nsend.time = time;

    switch (proto & PKTLAB_TRANSPORT_MASK) {
    case PKTLAB_RAW_PROTO:
        msg->nsend.raw.len = len;
        msg->nsend.raw.ptr = ptr;
        break;
    case PKTLAB_TCP_PROTO:
        msg->nsend.tcp.len = len;
        msg->nsend.tcp.ptr = ptr;
        break;
    case PKTLAB_UDP_PROTO:
        msg->nsend.udp.len = len;
        msg->nsend.udp.ptr = ptr;
        break;
    default:
        return -1;
    }

    return 0;
}

static int create_npoll (
    struct pktlab_message * msg, pktlab_time_t time)
{
    msg->type = PKTLAB_NPOLL_MESSAGE;
    msg->npoll.time = time;
    return 0;
}

static int create_ncap (
    struct pktlab_message * msg,
    pktlab_time_t time,
    const void * filtptr, uint32_t filtlen)
{
    msg->type = PKTLAB_NCAP_MESSAGE;
    msg->ncap.time = time;
    msg->ncap.filtptr = filtptr;
    msg->ncap.filtlen = filtlen;
    return 0;
}

static int create_mread (
    struct pktlab_message * msg,
    uint32_t memaddr, uint32_t bytecnt)
{
    if (bytecnt > PKTLAB_MREAD_MAX)
        return -1;

    msg->type = PKTLAB_MREAD_MESSAGE;
    msg->mread.addr = memaddr;
    msg->mread.len = bytecnt;
    return 0;
}

static int create_nclose (
    struct pktlab_message * msg, uint8_t sktid)
{
    msg->type = PKTLAB_NCLOSE_MESSAGE;
    msg->nsend.sktid = sktid;
    return 0;
}

static int try_send (
    struct pktlab_writer * w,
    const struct pktlab_message * msg)
{
    int rst;
    int i;
    struct timespec time = {.tv_sec = 0, .tv_nsec=100000000};

    rst = pktlab_write_message(w, msg);

    for (i = 0; i < 2 && rst == 0; ++i) {
        nanosleep(&time, NULL); // sleep 0.1 sec
        rst = pktlab_write_message(w, msg);
    }

    return rst;
}

static void send_n_recv (
    struct pktlab_writer * w,
    struct pktlab_reader * r,
    const struct pktlab_message * send_msg,
    struct pktlab_message ** recv_msg)
{
    if (try_send(w, send_msg) != 1)
        perror_exit("try_send", -1);

    if (pktlab_read_message(r, recv_msg) < 0)
        perror_exit("pktlab_read_message", -1);
}

static void print_pkt(const uint8_t * ptr, size_t len) {
    puts(">> Printing pkt hex dump");
    for (size_t i = 0; i < len; ++i) {
        printf("%02x ", (unsigned int) ptr[i]);

        if (i % 16 == 7)
            printf(" ");
        if (i % 16 == 15)
            puts("");
    }

    if (len % 16 != 15)
        puts("");
}

static void print_nstat(struct pktlab_message * msg) {
    int i;
    const uint8_t * ptr;

    if (msg->type != PKTLAB_NSTAT_MESSAGE)
        printf(">> ***WARNING*** msg->type(%u) does not equal PKTLAB_NSTAT_MESSAGE\n",
            msg->type);

    puts(">> Socket States");
    for (i = 0; i < msg->nstat.len; i += PKTLAB_STATLIST_SIZE) {
        ptr = msg->nstat.ptr + i;

        printf(">>> sktid:%u\tstate:%u\tbytecnt:%lu\tpktcnt:%lu\n",
            pktlab_get8(ptr),
            pktlab_get8(ptr+1),
            pktlab_get24n(ptr+2),
            pktlab_get24n(ptr+5));
    }
}

static uint16_t calcksum(const uint8_t * buf, size_t len) {
    uint32_t rst = 0xffff;
    uint16_t tmp;

    for (size_t i = 0; i < len-1; i += 2) {
        memcpy(&tmp, buf+i, 2);
        rst = (rst + ntohs(tmp)) % 0xffff;
    }

    // Handle any partial block at the end of the data.
    if (len % 2 == 1) {
        tmp = 0;
        memcpy(&tmp, buf+len-1, 1);
        rst = (rst + ntohs(tmp)) % 0xffff;
    }

    // Return the checksum in network byte order.
    return htons(~rst);
}

static ssize_t create_ip4_pkt (
    uint8_t * buf, size_t buflen,
    uint16_t ID, uint8_t ttl,
    uint8_t proto, uint16_t payloadlen,
    const void * src, const void * dst)
{
    /*
     * Refer to RFC 791 for more information on the fields of ipv4
     *
     *   0                   1                   2                   3
     *   0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |Version|  IHL  |Type of Service|          Total Length         |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |         Identification        |Flags|      Fragment Offset    |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |  Time to Live |    Protocol   |         Header Checksum       |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |                       Source Address                          |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |                    Destination Address                        |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |                    Options                    |    Padding    |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     */

    if (buflen < IP_HDRLEN)
        return -1;

    struct IPHdr * iphdr = (struct IPHdr *) buf;
    iphdr->ihl = 5;
    iphdr->ver = 4;
    iphdr->tos = 0;
    iphdr->len = htons(IP_HDRLEN+payloadlen);
    iphdr->id = htons(ID);
    iphdr->frag = 0;
    iphdr->ttl = 30;
    iphdr->proto = proto;
    iphdr->cksum = 0;
    memcpy(&iphdr->src, src, IP4_ADDRLEN);
    memcpy(&iphdr->dst, dst, IP4_ADDRLEN);
    iphdr->cksum = calcksum(buf, IP_HDRLEN);

    return IP_HDRLEN;
}

static ssize_t create_icmp_echo (
    uint8_t * buf, size_t buflen,
    uint16_t ID, uint16_t seq)
{
    /*
     * Refer to RFC 792 for more information on the fields of icmp echos
     *
     *   0                   1                   2                   3
     *   0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |     Type      |     Code      |          Checksum             |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |           Identifier          |        Sequence Number        |
     *  +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     *  |     Data ...
     *  +-+-+-+-+-
     */

    if (buflen < 8)
        return -1;

    struct ICMPHdr * icmphdr = (struct ICMPHdr *) buf;
    icmphdr->type=8;
    icmphdr->code=0;
    icmphdr->checksum=0;
    icmphdr->id=htons(ID);
    icmphdr->sequence=htons(seq);
    icmphdr->checksum = calcksum(buf, 8);

    return 8;
}

static ssize_t create_icmp_echoreply_filter (
    uint8_t * buf, size_t buflen, uint16_t id)
{
    id = htons(id);
    uint8_t * ptr = (uint8_t *) &id;
    struct bpfinstr {
        uint16_t code;
        uint8_t jt;
        uint8_t jf;
        uint32_t k;
    } filter[] = {
        { 0x30, 0, 0, 0x00000009 },
        { 0x15, 0, 9, 0x00000001 }, // check ip header proto
        { 0x30, 0, 0, 0x00000014 },
        { 0x15, 0, 7, 0x00000000 }, // check icmp type
        { 0x30, 0, 0, 0x00000015 },
        { 0x15, 0, 5, 0x00000000 }, // check icmp code
        { 0x30, 0, 0, 0x00000018 },
        { 0x15, 0, 3,     ptr[0] }, // check icmp id 1st byte
        { 0x30, 0, 0, 0x00000019 },
        { 0x15, 0, 1,     ptr[1] }, // check icmp id 2nd byte
        {  0x6, 0, 0, 0x00040000 },
        {  0x6, 0, 0, 0x00000000 }
    };

    if (buflen < sizeof(filter))
        return -1;

    for (size_t i = 0; i < sizeof(filter) / sizeof(filter[0]); ++i) {
        filter[i].code = htons(filter[i].code);
        filter[i].k = htonl(filter[i].k);
    }

    memcpy(buf, filter, sizeof(filter));
    return sizeof(filter);
}

static int is_icmp_echoreply(const uint8_t * pkt, size_t len, uint16_t id) {
    struct IPHdr * iphdr;
    struct ICMPHdr * icmphdr;

    iphdr = (struct IPHdr *) pkt;
    icmphdr = (struct ICMPHdr *) (pkt + iphdr->ihl*4);
    id = htons(id);

    // same check as bpf filter
    if (len < IP_HDRLEN ||
        len < iphdr->len ||
        iphdr->proto != 0x1 ||
        icmphdr->code != 0x0 ||
        icmphdr->type != 0x0 ||
        icmphdr->id != id)
        return -1;

    return 0;
}

static uint16_t get_icmp_echoreply_seq(const uint8_t * pkt, size_t len) {
    struct IPHdr * iphdr;
    struct ICMPHdr * icmphdr;

    iphdr = (struct IPHdr *) pkt;
    icmphdr = (struct ICMPHdr *) (pkt + iphdr->ihl*4);

    assert(len >= IP_HDRLEN && len >= ntohs(iphdr->len)); // also account for padding

    return ntohs(icmphdr->sequence);
}

static float nano2ms(pktlab_time_t t) {
    return (float) t / 1000000;
}

int main(void) {

    puts("> PacketLab Experiment Controller: Raw socket usage example");

    //
    // Set up connection between experiment controller and measurement endpoint
    //

    int welcome_sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (welcome_sock < 0)
        perror_exit("socket", -1);

    puts("> Create socket");
    int on = 1;
    if (setsockopt(welcome_sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0 )
        perror_exit("setsockopt", -1);

    puts("> Binding");
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(20556);
    if (bind(welcome_sock, (struct sockaddr *) &addr, sizeof(addr)) < 0)
        perror_exit("bind", -1);

    puts("> Listening");
    if (listen(welcome_sock, 0) < 0)
        perror_exit("listen", -1);

    puts("> Awaiting measurement endpoint connection ...");
    socklen_t socklen = sizeof(addr);
    int sock = accept(welcome_sock, (struct sockaddr *) &addr, &socklen);
    if (sock < 0)
        perror_exit("accept", -1);

    char me_addr[ADDRSTRLEN] = {};
    if (inet_ntop(AF_INET, &(addr.sin_addr.s_addr), me_addr, (socklen_t) sizeof(me_addr)) == NULL)
        perror_exit("inet_ntop", -1);
    printf("> Got measurement endpoint connection from %s. Closing welcome socket.\n", me_addr);
    close(welcome_sock);

    //
    // Start experiments
    //

    //
    // Create pktlab reader writer
    //

    struct pktlab_writer * w = pktlab_create_writer(sock);
    if (w == NULL)
        perror_exit("pktlab_create_writer", -1);

    struct pktlab_reader * r = pktlab_create_reader(sock);
    if (r == NULL)
        perror_exit("pktlab_create_reader", -1);

    //
    // Create and send nopen msg
    // Receive status
    //

    puts("> Sending nopen msg");

    struct pktlab_message send_msg;
    uint8_t sktid = 0; // special socket 0 for raw
    uint8_t proto = PKTLAB_IP4_PROTO | PKTLAB_RAW_PROTO;
    uint8_t intf = 0;
    uint32_t rbufsize = 0x10000;

    if (create_nopen(&send_msg, sktid, proto, intf, rbufsize) < 0)
        perror_exit("create_nopen", -1);

    struct pktlab_message * recv_msg;
    send_n_recv(w, r, &send_msg, &recv_msg);

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    } else if (recv_msg->status.id != 0) { // only 0 imply success
        print_err_exit(-1, "Status msg %d\n", (int) recv_msg->status.id);
    }

    printf(">> status msg id: %d\n", recv_msg->status.id);

    free(recv_msg);

    //
    // Create and send ncap msg
    // Receive status
    //

    puts("> Sending ncap msg");

    uint16_t id = 5566;
    pktlab_time_t time = PKTLAB_TIME_MAX; // raw socket recv forever
    uint8_t filter[BUFSZ];
    ssize_t filtlen;

    if ((filtlen = create_icmp_echoreply_filter(
            filter, sizeof(filter), id)) < 0)
        print_err_exit(-1, "create_icmp_echoreply_filter: ret -1\n");

    if (create_ncap(&send_msg, time, filter, filtlen) < 0)
        print_err_exit(-1, "create_nsend: ret -1\n");

    send_n_recv(w, r, &send_msg, &recv_msg);

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    } else if (recv_msg->status.id != 0) { // only 0 imply success
        print_err_exit(-1, "Status msg %d\n", (int) recv_msg->status.id);
    }

    printf(">> status msg id: %d\n", recv_msg->status.id);

    free(recv_msg);

    //
    // Create and send nsend msg
    // Receive status
    //

    uint16_t probe_num = PROBENUM;
    uint16_t tidx;
    uint8_t icmp_echo_probe[BUFSZ];
    ssize_t icmp_len, iphdr_len;
    uint8_t ttl = 30;
    uint8_t icmp_proto = 0x01;
    uint8_t src[IP4_ADDRLEN], dst[IP4_ADDRLEN];
    char srcaddr[] = "0.0.0.0";
    char dstaddr[] = "101.101.101.101";
    pktlab_time_t ec_nsend_time[PROBENUM];

    if (inet_pton(AF_INET, srcaddr, src) != 1)
        perror_exit("inet_pton", -1);
    if (inet_pton(AF_INET, dstaddr, dst) != 1)
        perror_exit("inet_pton", -1);
    time = pktlab_time_now() + pktlab_time_sec(DELAY_PROBE_SEC);

    for (uint16_t i = 0; i < probe_num; ++i) {
        puts("> Sending nsend msg");

        tidx = i;
        time += pktlab_time_sec(1);

        icmp_len = create_icmp_echo(
            icmp_echo_probe+IP_HDRLEN,
            sizeof(icmp_echo_probe)-IP_HDRLEN,
            id, i);
        if (icmp_len < 0)
            print_err_exit(-1, "create_icmp_echo: ret -1\n");

        iphdr_len = create_ip4_pkt(
            icmp_echo_probe, IP_HDRLEN,
            id, ttl, icmp_proto,
            icmp_len, src, dst);
        if (iphdr_len < 0)
            print_err_exit(-1, "create_ip4_pkt: ret -1\n");

        if (create_nsend(&send_msg, sktid, proto,
                tidx, time, icmp_len+IP_HDRLEN, icmp_echo_probe) < 0)
            print_err_exit(-1, "create_nsend: ret -1\n");

        send_n_recv(w, r, &send_msg, &recv_msg);
        ec_nsend_time[i] = pktlab_time_now();

        if (recv_msg == NULL) {
            print_err_exit(-1, "pktlab_read_message: sock EOF\n");
        } else if (recv_msg->status.id != 0) { // only 0 imply success
            print_err_exit(-1, "Status msg %d\n", (int) recv_msg->status.id);
        }

        printf(">> status msg id: %d\n", recv_msg->status.id);

        free(recv_msg);
    }

    //
    // Create and send npoll msg
    // Receive ndata and nstat
    //

    printf("> Sleep for %d s for ICMP echo reply\n", WAIT_REPLY_SEC);

    sleep(WAIT_REPLY_SEC);

    puts("> Sending npoll msg");

    time = pktlab_time_now() + pktlab_time_sec(10);
    create_npoll(&send_msg, time);

    if (try_send(w, &send_msg) != 1)
        perror_exit("try_send", -1);

    // recv ndata msg until recv nstat msg
    uint16_t seq = 0;
    pktlab_time_t me_recv_time[PROBENUM] = {};
    pktlab_time_t ec_npoll_time;

    int done = 0;
    while (!done) {
        if (pktlab_read_message(r, &recv_msg) < 0)
            perror_exit("pktlab_read_message", -1);

        if (recv_msg == NULL)
            print_err_exit(-1, "pktlab_read_message: sock EOF\n");

        printf(">> Got message type: %d\n", recv_msg->type);
        switch (recv_msg->type) {
        case PKTLAB_NDATA_MESSAGE:
            if (recv_msg->ndata.sktid != sktid)
                print_err_exit(-1, "Got ndata from uknown socket: %d\n",
                    recv_msg->ndata.sktid);

            print_pkt(recv_msg->ndata.ptr, recv_msg->ndata.len);

            if (is_icmp_echoreply(recv_msg->ndata.ptr,
                    recv_msg->ndata.len, id)) {
                seq = get_icmp_echoreply_seq(
                    recv_msg->ndata.ptr,
                    recv_msg->ndata.len);
                if (seq >= probe_num)
                    print_err_exit(-1, "ICMP echo reply seq (%x) too large", seq);

                me_recv_time[seq] = recv_msg->ndata.time;
            } else
                puts(">>> Not ICMP echo reply, ignoring");
            break;
        case PKTLAB_NSTAT_MESSAGE:
            ec_npoll_time = pktlab_time_now();
            print_nstat(recv_msg);
            done = 1;
            break;
        case PKTLAB_STATUS_MESSAGE:
            // an error
            print_err_exit(-1, "npoll msg received status msg %d\n", recv_msg->status.id);
            break;
        default:
            print_err_exit(-1, "Unknown msg type %d\n", recv_msg->type);
            break;
        }

        free(recv_msg);
    }

    //
    // Create and send mread msg for send time
    // Receive mdata
    //

    puts("> Sending mread msg");

    uint32_t memaddr = 0x30000000;
    uint32_t bytecnt = sizeof(pktlab_time_t)*probe_num;
    if (create_mread(&send_msg, memaddr, bytecnt) < 0)
        print_err_exit(-1, "create_mread: ret < 0\n");

    if (try_send(w, &send_msg) != 1)
        perror_exit("try_send", -1);

    if (pktlab_read_message(r, &recv_msg) < 0)
        perror_exit("pktlab_read_message", -1);

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    }

    pktlab_time_t me_send_time[PROBENUM];
    const uint8_t * ptr;
    switch (recv_msg->type) {
    case PKTLAB_MDATA_MESSAGE:
        if (recv_msg->mdata.len != sizeof(pktlab_time_t)*probe_num)
            print_err_exit(-1, "Memory data amount not expected: %u\n",
                recv_msg->mdata.len);

        ptr = recv_msg->mdata.ptr;
        for (uint16_t i = 0; i < probe_num; ++i) {
            me_send_time[i] = pktlab_get64n(
                ptr+i*sizeof(pktlab_time_t));
            printf(">> Got tidx time: %lu\n", me_send_time[i]);
        }
        break;
    case PKTLAB_STATUS_MESSAGE:
        // an error
        print_err_exit(-1, "npoll msg received status msg %d\n", recv_msg->status.id);
        break;
    default:
        print_err_exit(-1, "Unknown msg type %d\n", recv_msg->type);
        break;
    }

    free(recv_msg);

    //
    // Create and send nclose msg
    // Receive status
    //

    puts("> Sending nclose msg");

    create_nclose(&send_msg, sktid);

    send_n_recv(w, r, &send_msg, &recv_msg);

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    } else if (recv_msg->status.id != 0) { // only 0 imply success
        print_err_exit(-1, "Status msg %d\n", (int) recv_msg->status.id);
    }

    free(recv_msg);

    close(sock);

    //
    // Print rst
    //

    puts("\n---->Results<----");

    pktlab_time_t min = PKTLAB_TIME_MAX, max = 0, sum = 0, tmp;
    uint16_t recv_probe = 0;
    for (uint16_t i = 0; i < probe_num; ++i) {
        if (me_recv_time[i] == 0) {
            printf("Probe %u - Send: %llu\tRecv: lost\n",
                (unsigned int) i, (unsigned long long) me_send_time[i]);
            continue;
        }

        tmp = me_recv_time[i] - me_send_time[i];
        printf("Probe %u - Send: %llu\tRecv: %llu\ttime: %.2f ms\n",
            (unsigned int) i, (unsigned long long) me_send_time[i],
            (unsigned long long) me_recv_time[i], nano2ms(tmp));

        min = MIN(min, tmp);
        max = MAX(max, tmp);
        sum += tmp;
        ++recv_probe;
    }

    printf("%u packets transmitted, %u received, %.2f%% packet loss\n",
        (unsigned int) probe_num, (unsigned int) recv_probe,
        (float) 100*(1-recv_probe/probe_num));
    if (recv_probe != 0)
        printf("rtt min/avg/max/mdev = %.3f/%.3f/%.3f/%.3f ms\n",
            nano2ms(min), nano2ms(sum)/recv_probe,
            nano2ms(max), nano2ms(max-min)/2);

    printf("Spent time at EC: %.3f ms\n",
        nano2ms(ec_npoll_time-ec_nsend_time[0]));
    return 0;
}