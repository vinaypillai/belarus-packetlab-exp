// udp_ec.c
// PacketLab UDP Experiment Controller Example Program
// Use pktlab measurement endpoint to issue DNS request
//

#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <arpa/inet.h>
#include <netinet/ip.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include "pktlab.h"

#define ADDRSTRLEN 64
#define BUFSZ 0x10000

#define PROTO_2_ADDRFAM(proto) (((proto & PKTLAB_NETPROTO_MASK) == PKTLAB_IP4_PROTO) ?\
    AF_INET : AF_INET6)
#define PROTO_2_ADDRLEN(proto) (((proto & PKTLAB_NETPROTO_MASK) == PKTLAB_IP4_PROTO) ?\
    PKTLAB_IPV4_WO_MSK_ADDR_LEN : PKTLAB_IPV6_ADDR_LEN)

static void perror_exit(const char * str, int exit_val) {
    perror(str);
    exit(exit_val);
}

static void print_err_exit(int exit_val, const char * fmt, ...) {
    static char buf[256];
    va_list args;
    
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    
    fprintf(stderr, "%s", buf);

    exit(exit_val);
}

static int create_nopen (
    struct pktlab_message * msg,
    uint8_t * addrptr, uint8_t * portptr,
    uint8_t sktid, uint8_t proto, uint8_t intf,
    uint32_t rbufsize, const char * ip,
    uint16_t localport, uint16_t remoteport)
{
    uint8_t transproto = proto & PKTLAB_TRANSPORT_MASK;
    
    msg->type = PKTLAB_NOPEN_MESSAGE;
    msg->nopen.sktid = sktid;
    msg->nopen.proto = proto;
    msg->nopen.intf = intf;
    msg->nopen.rbufsz = rbufsize;
    
    if (transproto == PKTLAB_TCP_PROTO || transproto == PKTLAB_UDP_PROTO) {
        if (inet_pton(PROTO_2_ADDRFAM(proto), ip, addrptr) != 1)
            return -1;
        msg->nopen.addrlen = PROTO_2_ADDRLEN(proto);
        msg->nopen.addrptr = addrptr;

        pktlab_set16n(portptr, localport);
        pktlab_set16n(portptr+sizeof(uint16_t), remoteport);
        msg->nopen.portlen = PKTLAB_PORTLEN_MAX;
        msg->nopen.portptr = portptr;
    }

    return 0;
}

static int create_nsend (
    struct pktlab_message * msg,
    uint8_t sktid, uint8_t proto,
    uint16_t tidx, pktlab_time_t time,
    uint32_t len, const void * ptr)
{
    msg->type = PKTLAB_NSEND_MESSAGE;
    msg->nsend.sktid = sktid;
    msg->nsend.proto = proto;
    msg->nsend.tidx = tidx;
    msg->nsend.time = time;
    
    switch (proto & PKTLAB_TRANSPORT_MASK) {
    case PKTLAB_TCP_PROTO:
        msg->nsend.tcp.len = len;
        msg->nsend.tcp.ptr = ptr;
        break;
    case PKTLAB_UDP_PROTO:
        msg->nsend.udp.len = len;
        msg->nsend.udp.ptr = ptr;
        break;
    default:
        return -1;
    }

    return 0;
}

static int create_npoll (
    struct pktlab_message * msg, pktlab_time_t time)
{
    msg->type = PKTLAB_NPOLL_MESSAGE;
    msg->npoll.time = time;
    return 0;
}

static int create_mread (
    struct pktlab_message * msg,
    uint32_t memaddr, uint32_t bytecnt)
{
    if (bytecnt > PKTLAB_MREAD_MAX)
        return -1;

    msg->type = PKTLAB_MREAD_MESSAGE;
    msg->mread.addr = memaddr;
    msg->mread.len = bytecnt;
    return 0;
}

static int create_nclose (
    struct pktlab_message * msg, uint8_t sktid)
{
    msg->type = PKTLAB_NCLOSE_MESSAGE;
    msg->nsend.sktid = sktid;
    return 0;
}

static int try_send (
    struct pktlab_writer * w,
    const struct pktlab_message * msg)
{
    int rst;
    int i;
    struct timespec time = {.tv_sec = 0, .tv_nsec=100000000};

    rst = pktlab_write_message(w, msg);

    for (i = 0; i < 2 && rst == 0; ++i) {
        nanosleep(&time, NULL); // sleep 0.1 sec
        rst = pktlab_write_message(w, msg);
    }

    return rst;
}

static void send_n_recv (
    struct pktlab_writer * w,
    struct pktlab_reader * r,
    const struct pktlab_message * send_msg,
    struct pktlab_message ** recv_msg)
{
    if (try_send(w, send_msg) != 1)
        perror_exit("try_send", -1);

    if (pktlab_read_message(r, recv_msg) < 0)
        perror_exit("pktlab_read_message", -1);
}

void print_nstat(struct pktlab_message * msg) {
    int i;
    const uint8_t * ptr;

    if (msg->type != PKTLAB_NSTAT_MESSAGE)
        printf(">> ***WARNING*** msg->type(%u) does not equal PKTLAB_NSTAT_MESSAGE\n",
            msg->type);

    puts(">> Socket States");
    for (i = 0; i < msg->nstat.len; i += PKTLAB_STATLIST_SIZE) {
        ptr = msg->nstat.ptr + i;

        printf(">>> sktid:%u\tstate:%u\tbytecnt:%lu\tpktcnt:%lu\n",
            pktlab_get8(ptr),
            pktlab_get8(ptr+1),
            pktlab_get24n(ptr+2),
            pktlab_get24n(ptr+5));
    }
}

ssize_t create_dns_query (
    uint8_t * buf, size_t buflen,
    uint16_t ID, uint8_t RD,
    char * domain, size_t domainlen)
{
    /* 
     * Refer to RFC 1035 for more information on the fields of DNS msgs
     * 
     *                                 1  1  1  1  1  1
     *   0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                      ID                       |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |QR|   Opcode  |AA|TC|RD|RA|   Z    |   RCODE   |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    QDCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    ANCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    NSCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     * |                    ARCOUNT                    |
     * +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
     */

    //
    // Create DNS query header
    //

    if (buflen < 12+domainlen+2+4)
        return -1;

    uint16_t tmp;

    memcpy(buf, &ID, sizeof(ID));

    tmp = htons(0 | ((uint16_t) RD) << 8);
    memcpy(buf+2, &tmp, sizeof(tmp));

    printf("%u %u", *(buf+2), *(buf+3));

    tmp = htons(1);
    memcpy(buf+4, &tmp, sizeof(tmp));

    tmp = 0;
    memcpy(buf+6, &tmp, sizeof(tmp));
    memcpy(buf+8, &tmp, sizeof(tmp));
    memcpy(buf+10, &tmp, sizeof(tmp));

    //
    // Create query content
    //

    char * ptr;
    size_t off = 12;
    size_t toklen;
    for (ptr = strtok(domain, "."); ptr != NULL; ptr = strtok(NULL, ".")) {
        toklen = strlen(ptr);

        *(buf+off) = toklen;
        memcpy(buf+off+1, ptr, toklen);
        off += toklen+1;
    }

    *(buf+off) = '\0';
    
    tmp = htons(1);
    memcpy(buf+off+1, &tmp, sizeof(tmp));
    memcpy(buf+off+3, &tmp, sizeof(tmp));

    return off+5;
}

int main(void) {

    puts("> PacketLab Experiment Controller: UDP socket usage example");

    //
    // Set up connection between experiment controller and measurement endpoint
    //

    int welcome_sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (welcome_sock < 0)
        perror_exit("socket", -1);

    puts("> Create socket");
    int on = 1;
    if (setsockopt(welcome_sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0 )
        perror_exit("setsockopt", -1);

    puts("> Binding");
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(20556);
    if (bind(welcome_sock, (struct sockaddr *) &addr, sizeof(addr)) < 0)
        perror_exit("bind", -1);

    puts("> Listening");
    if (listen(welcome_sock, 0) < 0)
        perror_exit("listen", -1);

    puts("> Awaiting measurement endpoint connection ...");
    socklen_t socklen = sizeof(addr);
    int sock = accept(welcome_sock, (struct sockaddr *) &addr, &socklen);
    if (sock < 0)
        perror_exit("accept", -1);

    char me_addr[ADDRSTRLEN] = {};
    if (inet_ntop(AF_INET, &(addr.sin_addr.s_addr), me_addr, (socklen_t) sizeof(me_addr)) == NULL)
        perror_exit("inet_ntop", -1);
    printf("> Got measurement endpoint connection from %s. Closing welcome socket.\n", me_addr);
    close(welcome_sock);

    //
    // Start experiments
    //

    //
    // Create pktlab reader writer
    //

    struct pktlab_writer * w = pktlab_create_writer(sock);
    if (w == NULL)
        perror_exit("pktlab_create_writer", -1);

    struct pktlab_reader * r = pktlab_create_reader(sock);
    if (r == NULL)
        perror_exit("pktlab_create_reader", -1);

    //
    // Create and send nopen msg
    // Receive status
    //

    puts("> Sending nopen msg");

    struct pktlab_message send_msg;
    uint8_t sktid = 1;
    uint8_t proto = PKTLAB_IP4_PROTO | PKTLAB_UDP_PROTO;
    uint8_t intf = 0;
    uint32_t rbufsize = 0x1000;
    const char ip[] = "8.8.8.8";
    uint16_t localport = 0;
    uint16_t remoteport = 53;
    uint8_t remoteaddr[PKTLAB_ADDRLEN_MAX];
    uint8_t ports[PKTLAB_PORTLEN_MAX];

    if (create_nopen(&send_msg, remoteaddr, ports,
            sktid, proto, intf, rbufsize,
            ip, localport, remoteport) < 0)
        perror_exit("create_nopen", -1);

    struct pktlab_message * recv_msg;
    send_n_recv(w, r, &send_msg, &recv_msg);

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    } else if (recv_msg->status.id != 0) { // only 0 imply success
        print_err_exit(-1, "Status msg %d\n", (int) recv_msg->status.id);
    }

    printf(">> status msg id: %d\n", recv_msg->status.id);

    free(recv_msg);

    //
    // Create and send nsend msg
    // Receive status
    //

    puts("> Sending nsend msg");
    
    uint16_t tidx = 0;
    pktlab_time_t time = 0;
    pktlab_time_t ec_nsend_time;
    uint8_t payload[BUFSZ];
    ssize_t payloadlen;
    uint16_t ID = 5566;
    uint8_t RD = 1;
    char domain[BUFSZ] = "www.example.com";

    payloadlen = create_dns_query (
        payload, BUFSZ, ID, RD,
        domain, strlen(domain));

    if (payloadlen < 0)
        print_err_exit(-1, "create_dns_query: ret -1\n");

    if (create_nsend(&send_msg, sktid, proto,
            tidx, time, payloadlen, payload) < 0)
        print_err_exit(-1, "create_nsend: ret -1\n");

    send_n_recv(w, r, &send_msg, &recv_msg);
    ec_nsend_time = pktlab_time_now();

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    } else if (recv_msg->status.id != 0) { // only 0 imply success
        print_err_exit(-1, "Status msg %d\n", (int) recv_msg->status.id);
    }

    printf(">> status msg id: %d\n", recv_msg->status.id);
    
    free(recv_msg);

    //
    // Create and send npoll msg
    // Receive ndata and nstat
    //

    puts("> Sending npoll msg");

    time = pktlab_time_now() + pktlab_time_sec(10);
    create_npoll(&send_msg, time);

    if (try_send(w, &send_msg) != 1)
        perror_exit("try_send", -1);

    // recv ndata msg until recv nstat msg
    unsigned long cnt = 0;
    uint8_t buf[BUFSZ];
    pktlab_time_t me_recv_time;
    pktlab_time_t ec_npoll_time;

    int done = 0;
    while (!done) {
        if (pktlab_read_message(r, &recv_msg) < 0)
            perror_exit("pktlab_read_message", -1);

        if (recv_msg == NULL)
            print_err_exit(-1, "pktlab_read_message: sock EOF\n");

        printf(">> Got message type: %d\n", recv_msg->type);
        switch (recv_msg->type) {
        case PKTLAB_NDATA_MESSAGE:
            if (recv_msg->ndata.sktid != sktid)
                print_err_exit(-1, "Got ndata from uknown socket: %d\n",
                    recv_msg->ndata.sktid);
            
            memcpy(buf+cnt, recv_msg->ndata.ptr, recv_msg->ndata.len);
            cnt += recv_msg->ndata.len;
            me_recv_time = recv_msg->ndata.time;
            break;
        case PKTLAB_NSTAT_MESSAGE:
            ec_npoll_time = pktlab_time_now();
            print_nstat(recv_msg);
            done = 1;
            break;
        case PKTLAB_STATUS_MESSAGE:
            // an error
            print_err_exit(-1, "npoll msg received status msg %d\n", recv_msg->status.id);
            break;
        default:
            print_err_exit(-1, "Unknown msg type %d\n", recv_msg->type);
            break;
        }

        free(recv_msg);
    }

    //
    // Create and send mread msg for send time
    // Receive mdata
    //

    puts("> Sending mread msg");

    uint32_t memaddr = 0x30000000;
    uint32_t bytecnt = sizeof(pktlab_time_t);
    if (create_mread(&send_msg, memaddr, bytecnt) < 0)
        print_err_exit(-1, "create_mread: ret < 0\n");

    if (try_send(w, &send_msg) != 1)
        perror_exit("try_send", -1);

    if (pktlab_read_message(r, &recv_msg) < 0)
        perror_exit("pktlab_read_message", -1);

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    }
    
    pktlab_time_t me_send_time;
    switch (recv_msg->type) {
    case PKTLAB_MDATA_MESSAGE:
        if (recv_msg->mdata.len != sizeof(pktlab_time_t))
            print_err_exit(-1, "Memory data amount not expected: %u\n",
                recv_msg->mdata.len);

        me_send_time = pktlab_get64n(recv_msg->mdata.ptr);
        printf(">> Got tidx time: %lu\n", me_send_time);
        break;
    case PKTLAB_STATUS_MESSAGE:
        // an error
        print_err_exit(-1, "npoll msg received status msg %d\n", recv_msg->status.id);
        break;
    default:
        print_err_exit(-1, "Unknown msg type %d\n", recv_msg->type);
        break;
    }

    free(recv_msg);

    //
    // Create and send nclose msg
    // Receive status
    //

    puts("> Sending nclose msg");

    create_nclose(&send_msg, sktid);

    send_n_recv(w, r, &send_msg, &recv_msg);

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    } else if (recv_msg->status.id != 0) { // only 0 imply success
        print_err_exit(-1, "Status msg %d\n", (int) recv_msg->status.id);
    }

    free(recv_msg);

    close(sock);

    //
    // Print rst
    //

    puts("\n---->Results<----");
    printf("Received data length: %lu\n", cnt);
    printf("Spent time at ME: %lu\n", me_recv_time - me_send_time);
    printf("Spent time at EC: %lu\n", ec_npoll_time - ec_nsend_time);
    puts("\n-->Content<--");
    
    size_t i;
    for (i = 0; i < cnt; ++i) {
        printf("%02x ", buf[i]);
        if (i % 8 == 7)
            puts("");
    }

    return 0;
}
