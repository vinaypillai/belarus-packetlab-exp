#include <stdio.h>

#include "../include/pktlab_libc.h"
#include "../pktlab_util/pktlab_ops.h"
#include "../include/socket.h"

#include <string.h>


int main() {
    // non piped
    handle = dlopen("libc.so.6", RTLD_LOCAL | RTLD_LAZY);
    #if PKTLAB_PIPED
    me_socket = pl_connect("127.0.0.1", PKTLAB_EC_PORT);
    #else
    me_socket = pl_connect("127.0.0.1", PKTLAB_ME_PORT);
    #endif
    pl_create_reader_writer(me_socket);
    
    pl_socket_t pl_sock;
    memset(&pl_sock, 0, sizeof(pl_sock));
    pl_sock.sktid = pl_get_sktid(0);
    pl_sock.intf = 0;
    pl_sock.tidx = 0;
    pl_sock.domain = AF_INET;
    pl_sock.type = SOCK_STREAM;
    if (inet_pton(AF_INET, "127.0.0.1", pl_sock.remote_addr) != 1) {
        perror("inet_pton");
        exit(-1);
    }
    pl_sock.remote_port = htons(10001);

    pl_nopen(&pl_sock);

    while (true) {
        pl_send_npoll(0, 0);
        pl_recv_npoll(&pl_sock, 0, 0);
    }
        
        
    
}