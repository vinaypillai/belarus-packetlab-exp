#!/usr/bin/python3

import requests

r = requests.get("http://www.example.com")
print(r.status_code)

print(r.text)

