#include "include/pktlab_libc.h" // this must be the first

#include "include/fcntl.h"
#include <assert.h>
#include <stdarg.h>

static int fcntl_default(int fd, int cmd, va_list args) {
    libc_fcntl_t fn_p;
    if (handle)
        fn_p = LIBC_ORIG(fcntl);
    else
        fn_p = ((libc_fcntl_t)dlsym(RTLD_NEXT, "fcntl"));

    switch (cmd) {
    case F_DUPFD: {
        int fd_start = va_arg(args, int);
        return fn_p(fd, cmd, fd_start);
    }
    case F_GETFD:
    case F_GETFL:
        return fn_p(fd, cmd);
    case F_SETFD:
    case F_SETFL: {
        int flag = va_arg(args, int);
        return fn_p(fd, cmd, flag);
    }

    default:
        warn("Unhandled fcntl cmd: %d\n", cmd);
        return fn_p(fd, cmd);
    }
}

static int fnctl_pl(int fd, int cmd, va_list args) {
    libc_fcntl_t fn_p = LIBC_ORIG(fcntl);
    pl_socket_t *pl_sock = fd_map[fd];
    switch (cmd) {
    // TODO:
    case F_GETFD:
    case F_GETFL: {
        debug("F_GETFL");
        return fn_p(fd, cmd);
    }
    // TODO:
    case F_SETFD:
    case F_SETFL: {
        int flag = va_arg(args, int);
        debug("F_SETFL flag: %d", flag);
        if (pl_sock) {
            if (flag & O_NONBLOCK)
                pl_sock->is_blocking = !!(flag & O_NONBLOCK);
        }
        return fn_p(fd, cmd, flag);
    }
    case F_DUPFD: {
        int rv;
        int fd_start = va_arg(args, int);
        if ((rv = fn_p(fd, cmd, fd_start)) == -1)
            return rv;
        assert(fd_map[rv] == NULL);
        // point the duplicated fd to the same plsock
        fd_map[rv] = pl_sock;
        if (pl_sock->n_ref < pl_sock->fd_size)
            pl_sock->fd[pl_sock->n_ref++] = rv;
        else {
            void* temp = realloc(pl_sock->fd, pl_sock->fd_size * 2);
            if (!temp) {
                fatal("realloc failed");
            }
            pl_sock->fd = temp;
            pl_sock->fd_size *= 2;
            pl_sock->fd[pl_sock->n_ref++] = rv;
        }
        return rv;
    }
    default:
        warn("Unhandled fcntl cmd: %d\n", cmd);
        return fn_p(fd, cmd);
    }
}

int fcntl(int fd, int cmd, ... /* arg */) {
    int rv;
    va_list args;
    va_start(args, cmd);

    if (!fd_map || !fd_map[fd]) {
        rv = fcntl_default(fd, cmd, args);
    } else {
        rv = fnctl_pl(fd, cmd, args);
    }
    va_end(args);
    return rv;
}
