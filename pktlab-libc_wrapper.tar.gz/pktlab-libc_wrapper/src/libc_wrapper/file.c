#include "include/file.h"
#include "include/pktlab_libc.h"
#include "include/socket.h"
#include "pktlab_util/pktlab_ops.h"

int close(int fd) {
    // INIT_HEADER();
    // LIBC_ORIG(close)(fd);
    // trace("Called %s", __func__);
    // using init header will interfere with gdb
    if (!IS_PL_SOCK(fd)) {
        return ((libc_close_t)dlsym(RTLD_NEXT, "close"))(fd);
    }

    pl_socket_t *pl_sock = fd_map[fd];
    for (int i = 0; i < pl_sock->n_ref; ++i) {
        if (pl_sock->fd[i] == fd) {
            if (i == pl_sock->n_ref - 1)
                pl_sock->n_ref--;
            else {
                pl_sock->fd[i] = pl_sock->fd[--pl_sock->n_ref];
            }
            break;
        }
        // FIXME: debug
        if (unlikely(i == pl_sock->n_ref - 1)) {
            warn("fd not found");
        }
    }
    if (pl_sock->n_ref == 0)
        free_pl_socket(pl_sock);
    fd_map[fd] = NULL;

    if (handle)
        return LIBC_ORIG(close)(fd);
    return ((libc_close_t)dlsym(RTLD_NEXT, "close"))(fd);
}

ssize_t write(int fd, const void *buf, size_t count) {
    if (!fd_map || !fd_map[fd]) {
        return ((libc_write_t)dlsym(RTLD_NEXT, "write"))(fd, buf, count);
    }
    trace("Called %s", __func__);
    return send(fd, buf, count, 0);
}

ssize_t read(int fd, void *buf, size_t count) {
    if (!fd_map || !fd_map[fd]) {
        return ((libc_read_t)dlsym(RTLD_NEXT, "read"))(fd, buf, count);
    }
    trace("Called %s", __func__);
    return recv(fd, buf, count, 0);
}