// struct definition from: https://github.com/wahern/dns.git

#include "include/getaddrinfo.h"
#include "include/pktlab_libc.h"
#include "pktlab_util/pktlab_ops.h"
#include <netdb.h>
#include <string.h>
#include <unistd.h>

#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <assert.h>
#include <netinet/in.h>
#include <resolv.h>
#include <stdlib.h>
int getaddrinfo(const char *node, const char *service,
                const struct addrinfo *hints, struct addrinfo **res) {
    INIT_HEADER();
    if (node)
        debug("node: %s", node);
    if (service)
        debug("service: %s", service);
    // FIXME: only supporting ipv4
    if (node != NULL && node[0] == '*' && node[1] == 0)
        node = NULL;

    if (service != NULL && service[0] == '*' && service[1] == 0)
        service = NULL;

    if (node == NULL && service == NULL)
        return EAI_NONAME;

    if (hints == NULL)
        hints = &default_hints;

    uint16_t service_port = 0;
    if (service && service[0]) {
        char *c;
        service_port = (uint16_t)strtoul(service, &c, 10);
        if (*c == '\0') {
            service_port = htons(service_port);
        } else {
            char proto[10];
            if (hints->ai_socktype == SOCK_DGRAM)
                strncpy(proto, "udp", 9);
            else if (hints->ai_socktype == SOCK_STREAM)
                strncpy(proto, "tcp", 9);
            else
                proto[0] = '\0';
            struct servent *s = getservbyname(service, proto[0] ? proto : NULL);
            if (s)
                service_port = s->s_port;
            else {
                return EAI_SERVICE;
            }
        }
    }

    // supported flags
    // FIXME:
    if (hints->ai_flags &
        ~(AI_PASSIVE | AI_CANONNAME | AI_NUMERICHOST | AI_ADDRCONFIG |
          AI_V4MAPPED | AI_NUMERICSERV | AI_ALL))
        return EAI_BADFLAGS;

    if ((hints->ai_flags & AI_CANONNAME) && node == NULL)
        return EAI_BADFLAGS;

    // ipv4 only
    if (hints->ai_family == AF_INET6)
        return EAI_ADDRFAMILY;

    if (res == NULL) {
        // libc getaddrinfo simply segfaults is res is NULL
        // we return something less useful, but won't crash
        return EAI_MEMORY;
    }
    *res = NULL;

    // return a wildcard address suitable for bind/accept
    if ((hints->ai_flags & AI_PASSIVE) && !node) {

        struct addrinfo *ai = malloc(sizeof(*ai));
        ai->ai_flags = hints->ai_flags;
        ai->ai_family = AF_INET;
        ai->ai_socktype = hints->ai_socktype;
        ai->ai_protocol = hints->ai_protocol;
        ai->ai_addrlen = 4; // ipv4

        ai->ai_addr = malloc(sizeof(*(ai->ai_addr)));
        ai->ai_addr = (struct sockaddr *)&(struct sockaddr_in){
            .sin_port = service_port, .sin_addr = INADDR_ANY};
        ai->ai_canonname = NULL;

        ai->ai_next = *res;
        *res = ai;
        return 0;
    }

    // return immediately if node is an ipv4 address
    {
        struct in_addr ip_addr;
        int rv = inet_aton(node, &ip_addr);
        if (rv == 1) {
            struct sockaddr_in *addr_in = malloc(sizeof(*addr_in));
            if (!addr_in) {
                return EAI_MEMORY;
            }
            addr_in->sin_family = AF_INET;
            addr_in->sin_port = service_port;
            memcpy(&(addr_in->sin_addr), &(ip_addr.s_addr), sizeof(in_addr_t));
            struct addrinfo *ai = malloc(sizeof(*ai));
            if (!ai) {
                return EAI_MEMORY;
            }
            ai->ai_flags = hints->ai_flags;
            ai->ai_family = AF_INET;
            ai->ai_socktype = hints->ai_socktype;
            ai->ai_protocol = hints->ai_protocol;
            ai->ai_addrlen = sizeof(*addr_in);
            ai->ai_addr = (struct sockaddr *)addr_in;
            ai->ai_canonname = NULL;
            ai->ai_next = *res;
            *res = ai;
            return 0;
        }
    }

    // construct query DNS struct
    uint8_t *query_buf = malloc(DNS_QUERY_SIZE);
    uint16_t tran_id;
    int query_buf_sz;
    if ((query_buf_sz = res_mkquery(QUERY, node, C_IN, T_A, NULL, 0, NULL,
                                    query_buf, DNS_QUERY_SIZE)) == -1) {
        free(query_buf);
        herror("res_mkquery");
        return EAI_NONAME;
    }
    tran_id = *((uint16_t *)query_buf);

    // send query
    // obtain DNS server address
    uint8_t dns_serv_cnt = pl_get_ipv4_dns_server_count();
    if (dns_serv_cnt == 0) {
        free(query_buf);
        return EAI_FAIL;
    }
    // query only the first one
    struct sockaddr_in dns_addr;
    dns_addr.sin_family = AF_INET;
    dns_addr.sin_port = htons(53);
    pl_get_ipv4_dns_server_addr(0, &(dns_addr.sin_addr),
                                sizeof(dns_addr.sin_addr));
    // using UDP to send the query
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (connect(sock, &dns_addr, sizeof(dns_addr))) {
        perror("connect:");
        free(query_buf);
        close(sock);
        return EAI_AGAIN;
    }
    ssize_t sent = send(sock, query_buf, query_buf_sz, 0);
    if (sent != query_buf_sz) {
        free(query_buf);
        close(sock);
        return EAI_AGAIN;
    }
    free(query_buf);

    // recv resp
    char *resp_buf = malloc(DNS_QUERY_SIZE);
    if (!resp_buf) {
        close(sock);
        return EAI_MEMORY;
    }
    size_t resp_buf_size = DNS_QUERY_SIZE;
    ssize_t recved = recv(sock, resp_buf, DNS_QUERY_SIZE, 0);
    if (recved == -1) {
        close(sock);
        return EAI_AGAIN;
    }
    while (recved == resp_buf_size) {
        resp_buf = realloc(resp_buf, 2 * resp_buf_size);
        if (!resp_buf) {
            close(sock);
            return EAI_MEMORY;
        }
        recved += recv(sock, resp_buf + resp_buf_size, resp_buf_size, 0);
        resp_buf_size *= 2;
    }
    close(sock);
#if defined(DEBUG) && !defined(SUPPRESS_INFO)
    debug("received %ld bytes", recved);
    fputs("-->Content<--\n", stderr);

    for (size_t j = 0; j < recved; ++j) {
        fprintf(stderr, "%02x ", (uint8_t)resp_buf[j]);
        if (j % 8 == 7)
            fprintf(stderr, "\n");
    }
    fputs("-->end<--\n", stderr);
#endif
    assert(tran_id == *(uint16_t *)resp_buf);

    // parse response
    struct dns_header *header = (struct dns_header *)resp_buf;
    size_t reader = sizeof(*header);
    assert(header->qr == 1); // response
    switch (header->rcode) {
    case 0:
        break;
    case 1:
        return EAI_AGAIN;
    case 2:
        return EAI_AGAIN;
    case 3:
        return EAI_NONAME;
    case 4:
        return EAI_FAIL;
    default:
        break;
    }

    // skip query section
    for (int i = 0; i < ntohs(header->qdcount); ++i) {
        reader += dns_peek_name(resp_buf + reader);
        reader += sizeof(struct query_section);
    }

    // answer resource section
    for (int i = 0; i < ntohs(header->ancount); ++i) {
        char *rr_name = malloc(RR_NAME_SIZE);
        if (!rr_name) {
            free(resp_buf);
            return EAI_MEMORY;
        }
        // FIXME: dynamic growing?
        int rv = dns_decode_name(resp_buf, reader, rr_name, RR_NAME_SIZE);
        if (rv) {
            free(resp_buf);
            free(rr_name);
            return EAI_MEMORY;
        }
        rr_name = realloc(rr_name, strlen(rr_name) + 1); // +1 for nul
        reader += dns_peek_name(resp_buf + reader);
        struct rr_section *rr_rec = (struct rr_section *)(resp_buf + reader);
        reader += sizeof(*rr_rec);

        switch (ntohs(rr_rec->rrtype)) {
        case T_A: {
            assert(ntohs(rr_rec->rrtype) == T_A);
            assert(ntohs(rr_rec->rrclass) == C_IN);
            assert(ntohs(rr_rec->data_len) == sizeof(in_addr_t));
            struct sockaddr_in *addr_in = malloc(sizeof(*addr_in));
            if (!addr_in) {
                free(resp_buf);
                free(rr_name);
                return EAI_MEMORY;
            }
            addr_in->sin_family = AF_INET;
            addr_in->sin_port = service_port;
            memcpy(&(addr_in->sin_addr), resp_buf + reader, sizeof(in_addr_t));
            reader += ntohs(rr_rec->data_len);

            struct addrinfo *ai = malloc(sizeof(*ai));
            if (!ai) {
                free(addr_in);
                free(resp_buf);
                free(rr_name);
                return EAI_MEMORY;
            }
            ai->ai_flags = hints->ai_flags;
            ai->ai_family = AF_INET;
            ai->ai_socktype = hints->ai_socktype;
            ai->ai_protocol = hints->ai_protocol;
            ai->ai_addrlen = sizeof(*addr_in);
            ai->ai_addr = (struct sockaddr *)addr_in;
            ai->ai_canonname = rr_name;
            ai->ai_next = *res;
            *res = ai;
            break;
        }
        // canonical name
        case T_CNAME:
            reader += ntohs(rr_rec->data_len);
            break;
        default:
            reader += ntohs(rr_rec->data_len);
            break;
        }
    }

    // TODO: any AR?

    free(resp_buf);

    return 0;
}

void freeaddrinfo(struct addrinfo *res) {
    struct addrinfo *p;

    while (res != NULL) {
        p = res;
        res = res->ai_next;
        free(p->ai_canonname);
        free(p);
    }
}