#include "include/gethostbyname.h"

struct hostent* gethostbyname(const char* name) {
    INIT_HEADER();
    if (name)
        debug("%s", name);

    if (!name)
        return NULL;

    return LIBC_ORIG(gethostbyname)(name);
}