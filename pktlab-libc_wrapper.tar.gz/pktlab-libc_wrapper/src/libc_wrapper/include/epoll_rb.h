#ifndef _PKTLAB_LIBC_EPOLL_RB_H
#define _PKTLAB_LIBC_EPOLL_RB_H

#include "lib/rb.h"
#include <sys/epoll.h>

// node in the linked list tracking all epfds
struct epfd_tree {
    int epfd;
    struct rb_table *tp;
};

// node in the rb tree tracking all pl_sockets
struct tree_node {
    int fd;
    struct epoll_event event;
};

extern struct llist *epfd_list;
extern size_t epfd_list_len;

extern int is_epfd(int epfd);
extern int epoll_rbtree_create(int epfd);
extern int epoll_rbtree_insert(int epfd, int fd, struct epoll_event *event);
extern int epoll_rbtree_replace(int epfd, int fd, struct epoll_event *event);
extern struct epoll_event *epoll_rbtree_find(int epfd, int fd);
extern int epoll_rb_tree_delete(int epfd, int fd);
extern int epoll_rbtree_destroy(int epfd);

#endif