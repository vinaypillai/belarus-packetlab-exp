#ifndef _PKTLAB_LIBC_FILE_H
#define _PKTLAB_LIBC_FILE_H
#define _GNU_SOURCE

#include <stddef.h>
#include <unistd.h>

// fcntl
// typedef int (*libc_fcntl_t)(int fd, int cmd, ...);
// open, close, read, write
typedef int (*libc_open_t)(const char *pathname, int flags);
typedef int (*libc_close_t)(int fd);
typedef ssize_t (*libc_read_t)(int fd, void *buf, size_t count);
typedef ssize_t (*libc_write_t)(int fd, const void *buf, size_t count);

extern int close(int fd);

#endif