#ifndef _PKTLAB_GETHOSTBYNAME_H
#define _PKTLAB_GETHOSTBYNAME_H
#include "include/pktlab_libc.h"
#include "include/getaddrinfo.h" // for dns record decoding
#include <netdb.h>

typedef struct hostent* (*libc_gethostbyname_t)(const char* name);

#endif