#ifndef _PKTLAB_GETNAMEINFO_H
#define _PKTLAB_GETNAMEINFO_H
#include <netdb.h>
#include <sys/socket.h>

typedef int (*libc_getnameinfo_t)(const struct sockaddr *addr,
                                  socklen_t addrlen, char *host,
                                  socklen_t hostlen, char *serv,
                                  socklen_t servlen, int flags);

#endif