#ifndef _PKTLAB_LIBC_H
#define _PKTLAB_LIBC_H
#define _GNU_SOURCE
#include "pktlab.h"
#include "user_config.h"
#include "pktlab_util/pktlab_debug.h"
#include "socket.h"
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX(a, b)                                                              \
    ({                                                                         \
        __typeof__(a) _a = (a);                                                \
        __typeof__(b) _b = (b);                                                \
        _a > _b ? _a : _b;                                                     \
    })

#define MIN(a, b)                                                              \
    ({                                                                         \
        __typeof__(a) _a = (a);                                                \
        __typeof__(b) _b = (b);                                                \
        _a < _b ? _a : _b;                                                     \
    })

#define IS_PL_SOCK(fd) (!(!fd_map || !fd_map[fd]))

#define likely(cond) __glibc_likely(cond)
#define unlikely(cond) __glibc_unlikely(cond)

#define LIBC_ORIG(func) ((libc_##func##_t)dlsym(handle, #func))
#define INIT_HEADER()                                                          \
    do {                                                                       \
        if (unlikely(!handle)) {                                               \
            init_wrapper();                                                    \
        }                                                                      \
        trace("%s", __func__);                                          \
    } while (0)

// dl handle to libc.so.6
extern void *handle;
extern int me_socket;
extern pl_socket_t **fd_map;

// dup and dup2 later?

extern void init_wrapper(void);
extern void destroy_wrapper(void);

#endif //_PKTLAB_LIBC_H