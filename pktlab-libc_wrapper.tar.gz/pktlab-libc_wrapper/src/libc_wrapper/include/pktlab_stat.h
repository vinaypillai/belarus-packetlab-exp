#ifndef _PKTLAB_STAT_H
#define _PKTLAB_STAT_H
#include "pktlab.h"
#include "socket.h"
#include <stdint.h>

// This file contains functions that helps produce an overall stat at wrapper
// exit Including: Total run time; amount of data sent/received/delivered; # of
// pkts ... avg packet RTT; to me RTT UDP packet drop rate
extern double total_rtt;
extern uint32_t rtt_n;

extern void stat_add_byte_send(uint32_t num);
extern void stat_add_byte_recv(uint32_t num);
// extern void stat_add_rtt_point(pl_socket_t * pl_sock);
extern void stat_add_rtt_point(const struct timeval *t1,
                               const struct timeval *t2);
extern void stat_print_summary(void);

#endif