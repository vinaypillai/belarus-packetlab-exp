#ifndef _PKTLAB_LIBC_SELECT_H
#define _PKTLAB_LIBC_SELECT_H

#include <sys/select.h>

typedef int (*libc_select_t)(int nfds, fd_set *readfds, fd_set *writefds,
                             fd_set *exceptfds, struct timeval *timeout);

#endif
