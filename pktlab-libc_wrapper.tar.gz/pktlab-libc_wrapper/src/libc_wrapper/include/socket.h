#ifndef _PKTLAB_LIBC_SOCKET_H
#define _PKTLAB_LIBC_SOCKET_H
#define _GNU_SOURCE
#include "include/time.h"
#include "pktlab.h"
#include <stdint.h>
#include <sys/socket.h>
#include "pktlab_util/pktlab_socket.h"

// global variables
extern int last_op_sock;

// typedef for original libc function calls
typedef int (*libc_accept_t)(int socket, struct sockaddr *address,
                             socklen_t *address_len);
typedef int (*libc_bind_t)(int socket, const struct sockaddr *address,
                           socklen_t address_len);
typedef int (*libc_connect_t)(int socket, const struct sockaddr *address,
                              socklen_t address_len);
typedef int (*libc_getpeername_t)(int socket, struct sockaddr *address,
                                  socklen_t *address_len);
typedef int (*libc_getsockname_t)(int socket, struct sockaddr *address,
                                  socklen_t *address_len);
typedef int (*libc_getsockopt_t)(int socket, int level, int option_name,
                                 void *option_value, socklen_t *option_len);
typedef int (*libc_listen_t)(int socket, int backlog);
typedef ssize_t (*libc_recv_t)(int socket, void *buffer, size_t length,
                               int flags);
typedef ssize_t (*libc_recvfrom_t)(int socket, void *buffer, size_t length,
                                   int flags, struct sockaddr *address,
                                   socklen_t *address_len);
typedef ssize_t (*libc_recvmsg_t)(int socket, struct msghdr *message,
                                  int flags);
typedef ssize_t (*libc_send_t)(int socket, const void *message, size_t length,
                               int flags);
typedef ssize_t (*libc_sendmsg_t)(int socket, const struct msghdr *message,
                                  int flags);
typedef ssize_t (*libc_sendto_t)(int socket, const void *message, size_t length,
                                 int flags, const struct sockaddr *dest_addr,
                                 socklen_t dest_len);
typedef int (*libc_setsockopt_t)(int socket, int level, int option_name,
                                 const void *option_value,
                                 socklen_t option_len);
typedef int (*libc_shutdown_t)(int socket, int how);
typedef int (*libc_socket_t)(int domain, int type, int protocol);
typedef int (*libc_socketpair_t)(int domain, int type, int protocol,
                                 int socket_vector[2]);

#endif