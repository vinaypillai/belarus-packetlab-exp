#ifndef _PKTLAB_LIBC_TIME_H
#define _PKTLAB_LIBC_TIME_H
#define _GNU_SOURCE
#include <sys/time.h>
#include <time.h>

#define MILLI_PER_SEC 1000
#define MICRO_PER_MILLI 1000
#define NANOS_PER_SEC 1000000000L
#define MICRO_PER_SEC 1000000

// typedef for original libc function calls
typedef int (*libc_gettimeofday_t)(struct timeval *tv, struct timezone *tz);
typedef int (*libc_clock_gettime_t)(clockid_t clk_id, struct timespec *tp);

typedef enum {
    GETTIME_RESET = 0,
    GETTIME_SENT,
    GETTIME_RECVED
} gettime_state_t;

// extern gettime_state_t time_state;
extern void millisec_to_timeval(int milli, struct timeval *tv);

#endif