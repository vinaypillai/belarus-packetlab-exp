#include "ll.h"
#include <malloc.h>
#include <stddef.h>

struct llist *ll_create(ll_comp_func *comp, ll_deallocator *dealloc) {
    if (!comp)
        return NULL;

    struct llist *l = malloc(sizeof(*l));
    if (!l)
        return NULL;

    l->head = NULL;
    l->ll_compare = comp;
    l->ll_free = dealloc;

    return l;
}

int ll_insert(struct llist *l, void *elem) {
    if (!l || !elem)
        return -1;

    struct ll_node *new_node = malloc(sizeof(*new_node));
    if (!new_node)
        return -1;

    new_node->elem = elem;
    new_node->next = l->head;
    l->head = new_node;
    return 0;
}

void *ll_find(const struct llist *l, const void *e) {
    if (!l || !e)
        return NULL;

    struct ll_node *cur = l->head;
    while (cur) {
        if (l->ll_compare(cur->elem, e) == 0)
            return cur->elem;
        cur = cur->next;
    }

    return NULL;
}

void *ll_delete(struct llist *l, const void *e) {
    if (!l || !e)
        return NULL;

    struct ll_node **cur = &(l->head);
    while (*cur) {
        if (l->ll_compare((*cur)->elem, e) == 0) {
            struct ll_node *p = *cur;
            *cur = p->next;
            void *e = p->elem;
            free(p);
            return e;
        }
        cur = &((*cur)->next);
    }
    return NULL;
}

int ll_destroy(struct llist *l) {
    if (!l)
        return 0;

    struct ll_node *cur = l->head;
    struct ll_node *to_free;
    while (cur) {
        to_free = cur;
        cur = to_free->next;
        if (l->ll_free)
            l->ll_free(to_free->elem);
        free(to_free);
    }
    free(l);
    return 0;
}