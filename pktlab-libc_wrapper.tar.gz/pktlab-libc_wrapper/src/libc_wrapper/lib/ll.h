// a simple linked list implementation
#ifndef _LL_H
#define _LL_H

typedef int ll_comp_func(const void *a, const void *b);
typedef void ll_deallocator(void *ptr);

struct ll_node {
    void *elem;
    struct ll_node *next;
};

struct llist {
    struct ll_node *head;
    ll_comp_func *ll_compare;
    // used when destroying the entire list
    ll_deallocator *ll_free;
};

extern struct llist *ll_create(ll_comp_func *comp, ll_deallocator *dealloc);
// insert at the head of the list
extern int ll_insert(struct llist *l, void *elem);
// find and delete operates on the first matched node
extern void *ll_find(const struct llist *l, const void *n);
extern void *ll_delete(struct llist *l, const void *n);
extern int ll_destroy(struct llist *l);

#endif