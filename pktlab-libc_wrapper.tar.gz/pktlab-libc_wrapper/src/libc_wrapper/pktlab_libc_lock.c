#include "include/pktlab_libc_lock.h"
#include <assert.h>

struct pktlab_lock *pl_lock = NULL;

#define SANITY_CHECK()                                                         \
    do {                                                                       \
        if (unlikely(!pl_lock)) {                                              \
            fatal("pl_lock not initialized");                                  \
        }                                                                      \
    } while (0)

void pl_lock_init() {
    int rv;
    if (!pl_lock) {
        pl_lock = malloc(sizeof(*pl_lock));
        if (!pl_lock)
            exit(-1);
        rv = pthread_mutex_init(&pl_lock->send_mtx, NULL);
        assert(rv == 0);
        rv = pthread_mutex_init(&pl_lock->recv_mtx, NULL);
        assert(rv == 0);
        rv = pthread_cond_init(&pl_lock->cv, NULL);
        assert(rv == 0);
        pl_lock->send_ctr = 0;
        pl_lock->recv_ctr = 0;
    }
}

void pl_lock_destroy() {
    int rv __attribute__((unused));
    if (pl_lock) {
        rv = pthread_mutex_destroy(&pl_lock->send_mtx);
        debug("pthread sendmtx destroy returns: %d", rv);
        rv = pthread_mutex_destroy(&pl_lock->recv_mtx);
        debug("pthread recvmtx destroy returns: %d", rv);
        rv = pthread_cond_destroy(&pl_lock->cv);
        debug("pthread cond destroy returns: %d", rv);
        debug("pl_lock->send_ctr: %d", pl_lock->send_ctr);
        debug("pl_lock->recv_ctr: %d", pl_lock->recv_ctr);
        free(pl_lock);
    }
}

// 1. lock to make sure send is atomic
// 2. assign a incrementing id to ctr
// 3. ctr must match recv_ctr to ensure recv ordering
void pl_lock_send_lock(int *ctr) {
    int rv __attribute__((unused));
    SANITY_CHECK();

    rv = pthread_mutex_lock(&pl_lock->send_mtx);
    *ctr = pl_lock->send_ctr++;
    debug("assigned ctr: %d", *ctr);
}

void pl_lock_send_unlock() {
    int rv __attribute__((unused));
    SANITY_CHECK();

    rv = pthread_mutex_unlock(&pl_lock->send_mtx);
}

void pl_lock_recv_lock(const int *ctr) {
    int rv __attribute__((unused));
    SANITY_CHECK();
    rv = pthread_mutex_lock(&pl_lock->recv_mtx);
    while (*ctr != pl_lock->recv_ctr) {
        pthread_cond_wait(&pl_lock->cv, &pl_lock->recv_mtx);
    }
    ++pl_lock->recv_ctr;
    debug("received lock: %d", *ctr);
}

void pl_lock_recv_unlock() {
    pthread_cond_broadcast(&pl_lock->cv);
    pthread_mutex_unlock(&pl_lock->recv_mtx);
}
