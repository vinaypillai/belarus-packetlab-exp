#include "pktlab_debug.h"
#include <stdarg.h>

void pl_msg_dump_(struct pktlab_message *msg, size_t size) {
    if (msg == NULL) {
        fprintf(stderr, "pl_msg_dump nullptr");
        exit(-1);
    }

    char *p = (char *)msg;
    puts("> pktlab msg dump start----------------------------\n");
    for (size_t i = 0; i < size; ++i) {
        printf("%02x ", p[i]);
    }
    puts("\n> pktlab msg dump end----------------------------\n");
}

void print_err_exit(int exit_val, const char *fmt, ...) {
    static char buf[256];
    va_list args;

    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    fprintf(stderr, "%s", buf);

    exit(exit_val);
}

void perror_exit(const char *str, int exit_val) {
    perror(str);
    exit(exit_val);
}

void pl_print_nstat(struct pktlab_message *msg) {
    if (msg->type != PKTLAB_NSTAT_MESSAGE)
        printf(">> ***WARNING*** msg->type(%u) does not equal "
               "PKTLAB_NSTAT_MESSAGE\n",
               msg->type);
    // #ifdef LIBC_DEBUG
    //     int i;
    //     const uint8_t * ptr;
    //     puts(">> Socket States");
    //     for (i = 0; i < msg->nstat.len; i += PKTLAB_STATLIST_SIZE) {
    //         ptr = msg->nstat.ptr + i;

    //         printf(">>> sktid:%u\tstate:%u\tbytecnt:%lu\tpktcnt:%lu\n",
    //             pktlab_get8(ptr),
    //             pktlab_get8(ptr+1),
    //             pktlab_get24n(ptr+2),
    //             pktlab_get24n(ptr+5));
    //     }
    // #endif
}

void pktlab_wrapper_print_(const char *filename, int lineno, const char *label,
                           const char *fmt, ...) {
    static char buf[256];
    va_list args;

    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    fprintf(stderr, "%s (%s:%d): %s\n", label, filename, lineno, buf);
}