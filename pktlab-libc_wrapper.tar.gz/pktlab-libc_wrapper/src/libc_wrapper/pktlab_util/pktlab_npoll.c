#include "include/epoll.h"
#include "include/epoll_rb.h"
#include "include/pktlab_libc_lock.h"
#include "include/pktlab_stat.h"
#include "include/time.h"
#include "lib/ll.h"
#include "pktlab_debug.h"
#include "pktlab_ops.h"
#include "pktlab_util.h"
#include "pktlab_struct.h"
#include <assert.h>
#include <poll.h>
#include <string.h>

#define BUF_SIZE_BASE 2048

#define READ_MESSAGE()                                                         \
    do {                                                                       \
        int stat;                                                              \
        pl_set_tcpquickack();                                                  \
        if ((stat = pktlab_read_message(pl_reader, &recv_msg)) < 0)            \
            perror_exit("pktlab_read_message", -1);                            \
                                                                               \
        if (stat == 0) {                                                       \
            debug("stat: %d", stat);                                           \
            continue;                                                          \
        }                                                                      \
                                                                               \
        if (recv_msg == NULL)                                                  \
            print_err_exit(-1, "pktlab_read_message: sock EOF\n");             \
                                                                               \
        break;                                                                 \
    } while (1)

static int create_npoll(struct pktlab_message *msg, pktlab_time_t time) {
    msg->type = PKTLAB_NPOLL_MESSAGE;
    msg->npoll.time = time;
    return 0;
}

static void allocate_buf(pl_socket_t *pl_sock, size_t size) {
    if (!pl_sock->buf) {
        pl_sock->buf = malloc(BUF_SIZE_BASE);
        if (!pl_sock->buf) {
            print_err_exit(-1, "No memory\n");
        }
        pl_sock->buf_size = BUF_SIZE_BASE;
        pl_sock->buf_len = 0;
    }

    while (pl_sock->buf_size - pl_sock->buf_len < size) {
        // FIXME: realloc should be thread safe
        pl_sock->buf = realloc(pl_sock->buf, 2 * pl_sock->buf_size);
        if (!pl_sock->buf) {
            print_err_exit(-1, "No memory\n");
        }
        pl_sock->buf_size *= 2;
    }
}

static inline void add_recv_timestamp(pl_socket_t *pl_sock,
                                      struct pktlab_message *recv_msg) {
    if (!pl_sock->ec_recv_time) {
        pl_sock->ec_recv_time = libc_orig_pktlab_time_now();
        pl_sock->me_recv_time = recv_msg->ndata.time;
    }
}

static void buffer_message(struct pktlab_message *recv_msg) {
    trace(__func__);
    if (!sktid_plsock_map[recv_msg->ndata.sktid])
        print_err_exit(-1, "Got ndata from unknown socket: %d",
                       recv_msg->ndata.sktid);

    pl_socket_t *pl_sock_recv = sktid_plsock_map[recv_msg->ndata.sktid];
    if (!pl_sock_recv)
        fatal("socket present in sktid map but not in fd map");

    allocate_buf(pl_sock_recv, recv_msg->ndata.len);

    memcpy(pl_sock_recv->buf + pl_sock_recv->buf_len, recv_msg->ndata.ptr,
           recv_msg->ndata.len);
    pl_sock_recv->buf_len += recv_msg->ndata.len;
    pl_sock_recv->bytes_recved += recv_msg->ndata.len;
    add_recv_timestamp(pl_sock_recv, recv_msg);
    if (pl_sock_recv->time_state == GETTIME_SENT)
        pl_sock_recv->time_state = GETTIME_RECVED;
    // FIXME: rather arbitrary, uses the first one as last_op sock
    last_op_sock = sktid_plsock_map[recv_msg->ndata.sktid]->fd[0];
}


static void parse_nstat(struct pktlab_message *nstat_msg) {
    trace(__func__);
    assert(nstat_msg->type == PKTLAB_NSTAT_MESSAGE);

    if (!nstat_msg->nstat.len)
        return;

    const struct nstat_list* ptr = nstat_msg->nstat.ptr;
    
    if (nstat_msg->nstat.len % sizeof(*ptr))
        warn("malformed nstat list");
    
    uint32_t len = nstat_msg->nstat.len / sizeof(*ptr);
    for (uint32_t i = 0; i < len; ++i) {
        pl_socket_t* pl_sock = sktid_plsock_map[ptr[i].sktid];
        if (!pl_sock) {
            warn("parse_nstat sktid: %d not found in plsock map", ptr[i].sktid);
            continue;
        }
        pl_sock->me_skt_state = ptr[i].state;
        debug("sktid: %d state: %s", ptr[i].sktid, pktlab_sktstate_name(pl_sock->state));
        // TODO: record bytecnt and packet cnt
    }
}

int pl_send_npoll(uint32_t timeout_sec, uint32_t timeout_usec) {
    struct pktlab_message send_msg;
    debug("> Sending npoll msg");
    // usec per sec 1'000'000
    pktlab_time_t time = libc_orig_pktlab_time_now() +
                         pktlab_time_sec(timeout_sec) +
                         pktlab_time_sec(timeout_usec) / MICRO_PER_SEC;
    create_npoll(&send_msg, time);
    if (pl_try_send(pl_writer, &send_msg) != 1) {
        perror("try_send");
        return -1;
    }

    return 0;
}

int pl_send_npoll_fifo(uint32_t timeout_sec, uint32_t timeout_usec, int *ctr) {
    int rv;
    pl_lock_send_lock(ctr);
    rv = pl_send_npoll(timeout_sec, timeout_usec);
    pl_lock_send_unlock();
    return rv;
}

size_t pl_recv_npoll(pl_socket_t *pl_sock, uint8_t *buf, size_t buf_size) {
    struct pktlab_message *recv_msg = NULL;
    // recv ndata msg until recv nstat msg
    size_t cnt = 0;

    int done = 0;
    while (!done) {
        READ_MESSAGE();

        switch (recv_msg->type) {
        case PKTLAB_NDATA_MESSAGE:
            if (!pl_sock || recv_msg->ndata.sktid != pl_sock->sktid) {
                buffer_message(recv_msg);
                break;
            }

            // store msg to buf
            pl_sock->bytes_recved += recv_msg->ndata.len;

            if (cnt + recv_msg->ndata.len <= buf_size) {
                memcpy(buf + cnt, recv_msg->ndata.ptr, recv_msg->ndata.len);
                cnt += recv_msg->ndata.len;
            } else {
                size_t diff = cnt + recv_msg->ndata.len - buf_size;
                size_t offset = 0;
                if (buf_size > cnt) {
                    memcpy(buf + cnt, recv_msg->ndata.ptr, buf_size - cnt);
                    offset = buf_size - cnt;
                    cnt = buf_size;
                }
                allocate_buf(pl_sock, diff);
                memcpy(pl_sock->buf + pl_sock->buf_len,
                       (char *)recv_msg->ndata.ptr + offset, diff);
                pl_sock->buf_len += diff;
            }
            add_recv_timestamp(pl_sock, recv_msg);
            break;
        case PKTLAB_NSTAT_MESSAGE:
            parse_nstat(recv_msg);
            pl_print_nstat(recv_msg);
            done = 1;
            break;
        case PKTLAB_STATUS_MESSAGE:
            // an error
            print_err_exit(-1, "npoll msg received status msg %d\n",
                           recv_msg->status.id);
            break;
        default:
            print_err_exit(-1, "Unknown msg type %d\n", recv_msg->type);
            break;
        }
        free(recv_msg);
    }
    return cnt;
}

size_t pl_recv_npoll_fifo(pl_socket_t *pl_sock, uint8_t *buf, size_t buf_size,
                          const int *ctr) {
    size_t rv;
    pl_lock_recv_lock(ctr);
    rv = pl_recv_npoll(pl_sock, buf, buf_size);
    pl_lock_recv_unlock();
    return rv;
}

int pl_parse_npoll_select(fd_set *fds, fd_set *fds_selected) {
    struct pktlab_message *recv_msg;
    int done = 0;
    int fd_ready = 0;
    while (!done) {
        READ_MESSAGE();
        debug(">> Got message type: %c", recv_msg->type);

        switch (recv_msg->type) {
        case PKTLAB_NDATA_MESSAGE: {
            buffer_message(recv_msg);
            pl_socket_t* pl_sock = sktid_plsock_map[recv_msg->ndata.sktid];
            assert(pl_sock);
            for (int i = 0; i < pl_sock->n_ref; ++i) {
                int fd = pl_sock->fd[i];
                if (FD_ISSET(fd, fds_selected) && !FD_ISSET(fd, fds)) {
                    FD_SET(fd, fds);
                    ++fd_ready;
                }
            }
            break;
        }

        case PKTLAB_NSTAT_MESSAGE: {
            parse_nstat(recv_msg);
            done = 1;
            break;
        }

        case PKTLAB_STATUS_MESSAGE:
            break;

        default:
            print_err_exit(-1, "Unknown msg type %d\n", recv_msg->type);
            break;
        }
        free(recv_msg);
    }
    return fd_ready;
}

int pl_parse_npoll_select_fifo(fd_set *fds, fd_set *fds_selected, 
                               const int *ctr) {
    int rv;
    pl_lock_recv_lock(ctr);
    rv = pl_parse_npoll_select(fds, fds_selected);
    pl_lock_recv_unlock();
    return rv;
}

// returns number of pollfd whose revents is changed from zero to non-zero
int pl_parse_npoll_poll(struct pollfd **lookup) {
    struct pktlab_message *recv_msg;
    int done = 0;
    int fd_ready = 0;
    while (!done) {
        READ_MESSAGE();

        switch (recv_msg->type) {
        case PKTLAB_NDATA_MESSAGE: {
            buffer_message(recv_msg);
            // FIXME: possible problem with new fd layout in plsocket
            struct pollfd *pollfd = lookup[recv_msg->ndata.sktid];
            if (pollfd) {
                if (!pollfd->revents)
                    ++fd_ready;
                pollfd->revents |= ((POLLIN | POLLRDNORM) & pollfd->events);
            }
            break;
        }

        case PKTLAB_NSTAT_MESSAGE:
            parse_nstat(recv_msg);
            done = 1;
            break;

        case PKTLAB_STATUS_MESSAGE:
            break;

        default:
            print_err_exit(-1, "Unknown msg type %d\n", recv_msg->type);
            break;
        }
        free(recv_msg);
    }
    return fd_ready;
}

int pl_parse_npoll_poll_fifo(struct pollfd **lookup, const int *ctr) {
    int rv;
    pl_lock_recv_lock(ctr);
    rv = pl_parse_npoll_poll(lookup);
    pl_lock_recv_unlock();
    return rv;
}

static inline int fd_comp(const void *a, const void *b) {
    return (int)(intptr_t)a - (int)(intptr_t)b;
}

// epfd_tree: what pl_sockets are being tracked by this epfd
// events:
int pl_parse_npoll_epoll(struct epfd_tree *t, struct epoll_event *events,
                         int events_len, int maxevents, uint32_t out_flag) {
    struct pktlab_message *recv_msg;
    int done = 0;
    int events_offset = events_len;
    struct llist *recorded = ll_create(fd_comp, NULL);
    int rv;
    while (!done) {
        READ_MESSAGE();
        switch (recv_msg->type) {
        case PKTLAB_NDATA_MESSAGE: {
            buffer_message(recv_msg);
            pl_socket_t* pl_sock = sktid_plsock_map[recv_msg->ndata.sktid];
            assert(pl_sock);
            for (int i = 0; i < pl_sock->n_ref; ++i) {
                int fd = pl_sock->fd[i];
            struct tree_node n_search = {.fd = fd};
            struct tree_node *n = rb_find(t->tp, &n_search);
            if (n && n->event.events & EPOLL_IN_EVENTS &&
                events_offset < maxevents) {
                ll_insert(recorded, (void *)(intptr_t)fd);
                events[events_offset].events =
                    n->event.events & EPOLL_IN_EVENTS;
                if (unlikely(out_flag)) {
                    events[events_offset].events =
                        n->event.events & EPOLL_OUT_EVENTS;
                }
                events[events_offset].data = n->event.data;
                ++events_offset;
            }
            }
            break;
        }

        case PKTLAB_NSTAT_MESSAGE:
            parse_nstat(recv_msg);
            done = 1;
            break;

        case PKTLAB_STATUS_MESSAGE:
            break;

        default:
            break;
        }
    }

    if (unlikely(out_flag)) {
        struct rb_traverser trav;
        for (struct tree_node *n = rb_t_first(&trav, t->tp); n != NULL;
             n = rb_t_next(&trav)) {
            if (ll_find(recorded, (void *)(intptr_t)n->fd) == NULL &&
                n->event.events & EPOLL_OUT_EVENTS &&
                events_offset < maxevents) {
                events[events_offset].events =
                    n->event.events & EPOLL_OUT_EVENTS;
                events[events_offset].data = n->event.data;
                ++events_offset;
            }
        }
    }
    rv = ll_destroy(recorded);
    assert(rv == 0);
    return events_offset;
}

int pl_parse_npoll_epoll_fifo(struct epfd_tree *t, struct epoll_event *events,
                              int events_len, int maxevents, uint32_t out_flag,
                              const int *ctr) {
    int rv;
    pl_lock_recv_lock(ctr);
    rv = pl_parse_npoll_epoll(t, events, events_len, maxevents, out_flag);
    pl_lock_recv_unlock();
    return rv;
}

/*
polls the socket pointed by the structure pl_sock
pl_sock: the socket to poll. If null, function will return 0 immediately
buf/buf_size: buffer to copy a maximum of buf_size bytes of received data into.
              It's the caller's responsibility to ensure the space is reserved.
              If buf_size == 0, all received data will be copied to an internal
              buffer in pl_socket_t, can be used for polling.
timeout_sec/timeout_usec: If there's no data on the socket, the socket interface
                          will wait for at least timeout_sec+timeout_usec before
                          returning.
*/
size_t pl_npoll(pl_socket_t *pl_sock, uint8_t *buf, size_t buf_size,
                uint32_t timeout_sec, uint32_t timeout_usec) {
    if (!pl_sock) {
        // TODO: future errno
        return 0;
    }
    int ctr;
#ifdef PKTLAB_FIFO
    if (pl_send_npoll_fifo(timeout_sec, timeout_usec, &ctr) != 0)
        return 0;
    size_t cnt = pl_recv_npoll_fifo(pl_sock, buf, buf_size, &ctr);
#else
    if (pl_send_npoll(timeout_sec, timeout_usec) != 0)
        return 0;
    size_t cnt = pl_recv_npoll(pl_sock, buf, buf_size);
#endif

    // read send time
    // pl_mread_send_time(pl_sock);
    return cnt;
}
