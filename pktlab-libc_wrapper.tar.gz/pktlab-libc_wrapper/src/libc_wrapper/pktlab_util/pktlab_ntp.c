#include "include/pktlab_libc.h"

#include "include/fcntl.h"
#include "include/file.h"
#include "include/socket.h"
#include "include/time.h"
#include "pktlab_ntp.h"
#include "pktlab_util/pktlab_ops.h"
#include "pktlab_util/pktlab_util.h"

#include <assert.h>
#include <ifaddrs.h>
#include <signal.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/un.h>

#define IPC_PATH "/tmp/pktlab/wrapperipc"
struct sockaddr controller_addr = {};
struct sockaddr endpoint_addr = {};
struct sockaddr_un ipc_addr = {.sun_family = AF_UNIX, .sun_path = IPC_PATH};
static pktlab_time_t t0, t1, t2, t3;
int64_t t_offset = 0;
struct timeval tv_offset = {};
bool add_tv_offset = true;


int pl_ntp_server_run() {
    // spawn a separate process
    int pid;
    if ((pid = fork())) {
        return pid;
    }

    // make sure child dies after parent exits
    prctl(PR_SET_PDEATHSIG, SIGHUP);

    // child process
    // 1. create a UDP socket

    int rv;
    int sock = LIBC_ORIG(socket)(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (!sock) {
        perror("NTP server sock");
        exit(-1);
    }

    int on = 1;
    if (LIBC_ORIG(setsockopt)(sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) <
        0) {
        LIBC_ORIG(close)(sock);
        perror("NTP server setsockopt");
        exit(-1);
    }

    // 2. bind to local port
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
#if PKTLAB_PIPED
    addr.sin_port = htons(PKTLAB_EC_PORT);
#else
    addr.sin_port = htons(PKTLAB_ME_PORT);
#endif
    if (LIBC_ORIG(bind)(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        LIBC_ORIG(close)(sock);
        perror("NTP server bind");
        exit(-1);
    }

    // 3. call blocking recv on that
    int flag = LIBC_ORIG(fcntl)(sock, F_GETFL);
    flag &= ~O_NONBLOCK;
    rv = LIBC_ORIG(fcntl)(sock, F_SETFL, flag);
    assert(rv == 0);

    // FIXME: race condition here
    // if the client sends data before we start listening
    // we are stuck here forever
    // realistically shouldn't happen bc me-ec rtt
    uint8_t buf[1024];
    ssize_t rv_sz;
    socklen_t len = sizeof(endpoint_addr);
    rv_sz = LIBC_ORIG(recvfrom)(sock, buf, sizeof(buf), 0,
                                (struct sockaddr *)&endpoint_addr, &len);
    if (rv_sz < 0) {
        perror("NTP server recvfrom");
        exit(-1);
    }

    // record recv time
    t1 = libc_orig_pktlab_time_now();
    // record send time
    t2 = libc_orig_pktlab_time_now();

    // send a response back to ntp client (dummy response)
    rv = LIBC_ORIG(sendto)(sock, buf, rv_sz, 0, &endpoint_addr, len);
    if (rv != rv_sz) {
        perror("NTP server sendto");
        exit(-1);
    }

    close(sock);

    int ipc_sock = LIBC_ORIG(socket)(AF_UNIX, SOCK_STREAM, 0);

    while ((rv = LIBC_ORIG(connect)(ipc_sock, (struct sockaddr *)&ipc_addr,
                                    sizeof(ipc_addr))) < 0) {
        continue;
    }

    memcpy(buf, &t1, sizeof(t1));
    memcpy(buf + sizeof(t1), &t2, sizeof(t2));

    rv = LIBC_ORIG(send)(ipc_sock, buf, sizeof(t1) + sizeof(t2), 0);

    if (rv != sizeof(t1) + sizeof(t2)) {
        perror("NTP server ipc_sock send");
        exit(-1);
    }

    LIBC_ORIG(close)(ipc_sock);

    exit(0);
    return 0;
}

int pl_ntp_client_run() {
    // FIXME: using this to prevent race-condition on lo
    trace("ntp client");
    sleep(1);
    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (fd == -1) {
        perror("NTP client socket");
        exit(-1);
    }

    uint8_t buf[16] = {};
    int rv = sendto(fd, buf, 1, 0, &controller_addr, sizeof(controller_addr));

    if (rv != 1) {
        perror("NTP client sendto");
        exit(-1);
    }

    pktlab_time_t t = libc_orig_pktlab_time_now();
    uint32_t timeout_sec = UINT32_MAX - t / NANOS_PER_SEC - 1;
    rv = pl_npoll(fd_map[fd], buf, sizeof(buf), timeout_sec, 0);

    if (rv != 1) {
        perror("NTP client npoll");
        exit(-1);
    }

    pl_mread_send_time(fd_map[fd]);
    t0 = fd_map[fd]->me_send_time;
    t3 = fd_map[fd]->me_recv_time;

    rv = close(fd);

    int ipc_sock = LIBC_ORIG(socket)(AF_UNIX, SOCK_STREAM, 0);
    if (rv == -1) {
        perror("NTP client ipc_sock socket");
        exit(-1);
    }

    int on = 1;
    if (LIBC_ORIG(setsockopt)(ipc_sock, SOL_SOCKET, SO_REUSEADDR, &on,
                              sizeof(on)) < 0) {
        LIBC_ORIG(close)(ipc_sock);
        perror("NTP client setsockopt");
        exit(-1);
    }

    unlink(IPC_PATH);
    rv = LIBC_ORIG(bind)(ipc_sock, (struct sockaddr *)&ipc_addr,
                         sizeof(ipc_addr));
    if (rv == -1) {
        perror("NTP client ipc_sock bind");
        exit(-1);
    }

    rv = LIBC_ORIG(listen)(ipc_sock, 1);
    if (rv < 0) {
        perror("NTP client ipc_sock listen");
        exit(-1);
    }

    int acc_ipc_sock = LIBC_ORIG(accept)(ipc_sock, NULL, NULL);
    if (acc_ipc_sock < 0) {
        perror("NTP client ipc_sock accept");
        exit(-1);
    }
    rv = close(ipc_sock);

    rv = LIBC_ORIG(recv)(acc_ipc_sock, buf, sizeof(buf), 0);
    if (rv < 0) {
        perror("NTP client ipc_sock recv");
        exit(-1);
    }
    rv = LIBC_ORIG(close)(acc_ipc_sock);

    memcpy(&t1, buf, sizeof(t1));
    memcpy(&t2, buf + sizeof(t1), sizeof(t2));

    t_offset = -(int64_t)((t1 - t0) + (t2 - t3)) / 2;
    if (t_offset < 0) {
        add_tv_offset = false;
        pktlab_time_to_timeval(-t_offset, &tv_offset);
    } else {
        add_tv_offset = true;
        pktlab_time_to_timeval(t_offset, &tv_offset);        
    }
    debug("NTP offset: %lld", t_offset);
    debug("NTP tv_offset: %d sec %d usec", tv_offset.tv_sec, tv_offset.tv_usec);

    return 0;
}