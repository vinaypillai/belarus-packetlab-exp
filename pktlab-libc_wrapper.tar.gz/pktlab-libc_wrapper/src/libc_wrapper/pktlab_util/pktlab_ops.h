#ifndef _PKTLAB_APP_H
#define _PKTLAB_APP_H
#include "include/epoll_rb.h"
#include "include/pktlab_libc.h"
#include "pktlab.h"

#include <poll.h>

extern struct pktlab_writer *pl_writer;
extern struct pktlab_reader *pl_reader;

extern int pl_connect(const char *ip, int port);

extern void pl_create_reader_writer(int sock);
extern void pl_destroy_reader_writer(void);

extern int pl_nopen(pl_socket_t *pl_sock);
extern int pl_nclose(pl_socket_t *pl_sock);
extern int pl_nsend(pl_socket_t *pl_sock, const uint8_t *payload,
                    size_t payloadlen);
extern size_t pl_npoll(pl_socket_t *pl_sock, uint8_t *buf, size_t buf_size,
                       uint32_t timeout_sec, uint32_t timeout_usec);
extern void pl_mread(uint32_t memaddr, uint32_t bytecnt, void *buf);

extern uint8_t pl_get_ipv4_dns_server_count();
extern int pl_get_ipv4_dns_server_addr(uint8_t offset, void *buf,
                                       size_t buflen);
extern uint8_t pl_get_ipv4_list();



// the npoll family
extern int pl_send_npoll(uint32_t timeout_sec, uint32_t timeout_usec);
extern size_t pl_recv_npoll(pl_socket_t *pl_sock, uint8_t *buf,
                            size_t buf_size);
extern int pl_parse_npoll_select(fd_set *fds, fd_set *fds_selected);
extern int pl_parse_npoll_poll(struct pollfd **lookup);
extern int pl_parse_npoll_epoll(struct epfd_tree *t, struct epoll_event *events,
                                int events_len, int max_events,
                                uint32_t out_flag);

// fifo wrapped version of the above functions
extern int pl_send_npoll_fifo(uint32_t timeout_sec, uint32_t timeout_usec,
                              int *ctr);
extern size_t pl_recv_npoll_fifo(pl_socket_t *pl_sock, uint8_t *buf,
                                 size_t buf_size, const int *ctr);
extern int pl_parse_npoll_select_fifo(fd_set *fds, fd_set *fds_selected,
                                      const int *ctr);
extern int pl_parse_npoll_poll_fifo(struct pollfd **lookup, const int *ctr);
extern int pl_parse_npoll_epoll_fifo(struct epfd_tree *t,
                                     struct epoll_event *events, int events_len,
                                     int max_events, uint32_t out_flag,
                                     const int *ctr);

#endif //_PKTLAB_APP_H