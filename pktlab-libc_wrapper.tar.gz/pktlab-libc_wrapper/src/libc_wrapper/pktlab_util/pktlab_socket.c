#include "pktlab_util/pktlab_socket.h"
#include "pktlab_util/pktlab_util.h"
#include "pktlab_util/pktlab_ops.h"
#include "pktlab_util/pktlab_debug.h"
#include <stdlib.h>

pl_socket_t* sktid_plsock_map[N_SKTID] = {};


void pl_sock_reset_time(pl_socket_t *pl_sock) {
    pl_sock->ec_recv_time = 0;
    pl_sock->ec_send_time = 0;
    pl_sock->me_recv_time = 0;
    pl_sock->me_send_time = 0;
    pl_sock->send_flag = false;
}

void pl_sock_init(pl_socket_t *pl_sock) {
    // pl_sock->local_port = 0;
    pl_sock->remote_port = 0;
    // pl_sock->is_bound = false;
    pl_sock->state = PL_SOCKET_STATE_RESET;
    pl_sock->time_state = GETTIME_RESET;
    pl_sock->pl_type = PL_SOCKET_TYPE_DEFAULT;
    if (pl_sock->buf) 
        free(pl_sock->buf);
    pl_sock->buf = NULL;
    if (pl_sock->buf_len)
        warn("pl_sock non-zero buffer length");
    pl_sock->buf_len = 0;
    pl_sock->buf_size = 0;
    pl_sock->buf_off = 0;
    pl_sock->bytes_recved = 0;
    pl_sock->bytes_delivered = 0;
    pl_sock->is_blocking = 1;

    if (!pl_sock->n_ref && !pl_sock->fd) {
        pl_sock->fd = malloc(sizeof(*pl_sock->fd) * BASE_FD_LEN);
        if (!pl_sock->fd) {
            fatal("malloc failed");
        }
        pl_sock->fd_size = BASE_FD_LEN;
    }
    pl_sock->n_ref = 0;
    pl_sock->me_skt_state = PKTLAB_SKTST_RESET;
    pl_sock_reset_time(pl_sock);
}

void free_pl_socket(pl_socket_t *pl_sock) {
    if (!pl_sock)
        return;
#if defined(PKTLAB_SKT_SUMMARY) && !defined(SUPPRESS_INFO)
    // print stat
    fprintf(stderr, "-------------socket summary---------------\n");
    fprintf(stderr,"sktid: %d intf: %d tidx: %d fd: %d\n", pl_sock->sktid,
           pl_sock->intf, pl_sock->tidx, pl_sock->fd[0]);
    fprintf(stderr,"bytes recved: %lu bytes delivered: %lu\n", pl_sock->bytes_recved,
           pl_sock->bytes_delivered);
    fprintf(stderr,"buf size: %lu buf length: %lu\n", pl_sock->buf_size,
           pl_sock->buf_len);
    fprintf(stderr,"-------------socket summary end---------------\n");
#endif
    if (pl_sock->state != PL_SOCKET_STATE_RESET &&
        pl_sock->state != PL_SOCKET_STATE_OPEN) {
        pl_mread_send_time(pl_sock);
        pl_nclose(pl_sock);
        pl_release_sktid(pl_sock);
    }

    if (pl_sock->buf) {
        if (pl_sock->buf_len) {
            warn("unread msg in buffer");
        }
        free(pl_sock->buf);
    }

    if (pl_sock->fd) {
        if (pl_sock->n_ref) {
            warn("positive n_ref");
        }
        free(pl_sock->fd);
    }
    free(pl_sock);
}



uint8_t pl_get_sktid(pl_socket_t *pl_sock) {
    // make sktid 0 reserved
    for (uint8_t i = 1; i < 256; ++i) {
        if (!sktid_plsock_map[i]) {
            sktid_plsock_map[i] = pl_sock;
            debug("%s returns %d", __func__, i);
            return i;
        }
    }
}

void pl_release_sktid(pl_socket_t *pl_sock) {
    if (pl_sock->sktid == 0) {
        return;
    }
    sktid_plsock_map[pl_sock->sktid] = NULL;
    pl_sock->sktid = 0;
}