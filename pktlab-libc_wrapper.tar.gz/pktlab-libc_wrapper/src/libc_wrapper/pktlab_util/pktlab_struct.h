#ifndef _PKTLAB_STRUCT_H
#define _PKTLAB_STRUCT_H

#include "pktlab.h"

struct nstat_list {
    uint8_t sktid;
    int8_t state;
    uint32_t bytecnt:24;
    uint32_t pktcnt:24;
} __attribute__((packed));


#endif