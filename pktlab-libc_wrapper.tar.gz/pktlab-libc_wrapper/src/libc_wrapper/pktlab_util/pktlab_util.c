#include "pktlab_util.h"
#include "include/pktlab_libc_lock.h"
#include "include/time.h"
#include "pktlab_debug.h"
#include "pktlab_ops.h"
#include "pktlab_util/pktlab_ntp.h"
#include <netinet/tcp.h>
#include <time.h>

int pl_try_send(struct pktlab_writer *w, const struct pktlab_message *msg) {
    int rst;
    int i;
    struct timespec time = {.tv_sec = 0, .tv_nsec = 100000000};

    rst = pktlab_write_message(w, msg);

    for (i = 0; i < 2 && rst == 0; ++i) {
        nanosleep(&time, NULL); // sleep 0.1 sec
        rst = pktlab_write_message(w, msg);
    }

    return rst;
}

enum pktlab_status pl_send_n_recv(const struct pktlab_message *send_msg,
                                  struct pktlab_message **recv_msg) {
#ifdef PKTLAB_FIFO
    int ctr;
    pl_lock_send_lock(&ctr);
    if (pl_try_send(pl_writer, send_msg) != 1) {
        pl_lock_send_unlock();
        perror_exit("try_send", -1);
    }
    pl_lock_send_unlock();

    pl_set_tcpquickack();

    pl_lock_recv_lock(&ctr);
    if (pktlab_read_message(pl_reader, recv_msg) < 0) {
        pl_lock_recv_unlock();
        perror_exit("pktlab_read_message", -1);
    }
    pl_lock_recv_unlock();
#else
    if (pl_try_send(pl_writer, send_msg) != 1) {
        perror_exit("try_send", -1);
    }
    pl_set_tcpquickack();

    if (pktlab_read_message(pl_reader, recv_msg) < 0) {
        perror_exit("pktlab_read_message", -1);
    }
#endif

    if (*recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    } else if ((*recv_msg)->status.id != 0) { // only 0 imply success
        info("Status msg %d\n", (int)(*recv_msg)->status.id);
        return (*recv_msg)->status.id;
    }
    return PKTLAB_SUCCESS;
}

void pl_set_tcpquickack(void) {
    // static int on = 1;
    // if (setsockopt(me_socket, IPPROTO_TCP, TCP_QUICKACK, &on, sizeof(on)))
    //     perror("setsockopt");
}

void pl_mread_send_time(pl_socket_t *pl_sock) {
    uint32_t memaddr = 0x30000000 + sizeof(pktlab_time_t) * pl_sock->sktid;
    pktlab_time_t t;
    pl_mread(memaddr, sizeof(t), &t);
    pl_sock->me_send_time = pktlab_get64n(&t);
}

pktlab_time_t libc_orig_pktlab_time_now() {
    struct timeval tv;
    LIBC_ORIG(gettimeofday)(&tv, NULL);
    return pktlab_timeval_to_time(&tv) + t_offset;
}

