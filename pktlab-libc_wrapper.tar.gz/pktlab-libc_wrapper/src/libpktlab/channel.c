// channel.c
//

#include "pktlab.h"

// 
// INTERNAL CONSTANTS
// 

// ...

// 
// INTERNAL TYPE DEFINITIONS
// 

struct pktlab_channel {
	struct pktlab_reader * reader;
	struct pktlab_writer * writer;
	int fd;
};

// 
// INTERNAL FUNCTION DECLARATIONS
// 

// ...

// 
// INTERNAL STATE CONSTANTS
// 

// ...

// 
// EXPORTED FUNCTION DEFINITIONS
// 

void pktlab_channel_init(struct pktlab_channel * ch, int fd) {
	ch->reader = NULL;
	ch->writer = NULL;
	ch->fd = -1;
}

int pktlab_channel_connect (
	struct pktlab_channel * ch, const char * spec)
{
	// ...
}

int pktlab_channel_attach(struct pktlab_channel * ch, int fd) {
	// ...
}

int pktlab_channel_prepare_select(...) {
	// ...
}

int pktlab_channel_process_select(...) {
	// ...
}

int pktlab_channel_pause(struct pktlab_channel * ch) {
	// ...
}

int pktlab_channel_resume(struct pktlab_channel * ch) {
	// ...
}

int pktlab_channel_get (
	struct pktlab_channel * ch, struct pktlab_message ** msgptr)
{
	// ...
}

int pktlab_channel_put (
	struct pktlab_channel * ch, struct pktlab_message * msg)
{
	// ...
}
