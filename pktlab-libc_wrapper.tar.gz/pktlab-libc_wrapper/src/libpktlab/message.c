// pktlab/message.c
// 

#include "pktlab.h"

#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <inttypes.h>
#include <arpa/inet.h>
#include <sys/uio.h>

#include "private.h"

// 
// INTERNAL FUNCTION DECLARATIONS
// 

// Message decoders are called by pktlab_decode_message to decode a raw
// sequence of bytes. On entry, msg is a pointer to an uninitialized
// pktlab_message structure and ptr is a pointer to len bytes of memory
// containing the received message, starting with the header. Headers are
// dispatched by pktlab_decode_message using the message type supplied in
// the header. A decoder returns true if decoding succeeded and false
// otherwise. The msg structure may be initialized with pointers into the
// len bytes of memory starting with ptr. Decoders must not return any
// pointers to dynamically allocated memory. That is, any pointers in msg
// must be NULL or must point into memory pointed to by ptr.

typedef bool (*message_decoder_t) (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static void make_raw_message (
	struct pktlab_message * restrict msg,
	const void * restrict rawptr, uint_fast32_t rawlen, bool malformed);

static bool decode_status_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_mread_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_mwrite_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_mdata_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_nopen_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_nclose_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_npoll_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_nsend_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_ndata_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_nstat_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_ncap_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_xsub_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_xstart_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_xyield_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_xend_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_xdescr_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_xfilt_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_xkey_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

static bool decode_xcert_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, uint_fast32_t len);

// Message encoders are called by pktlab_encode_message to encode a message
// given as a pklab_message structure into up to PKTLAB_ENCODE_IOVCNT
// non-contiguous sequences of bytes. On entry, msg points to an
// initialized pklab_message structure and iov points to an array of
// PKTLAB_ENCODE_IOVCNT struct iovec elements. All but the first element of
// iov are initialized to 0. The first element is initialized so that
// iov[0].iov_base points to a buffer of size at least PKTLAB_ENCODE_BUFSZ
// and iov[0].iov_len is PKTLAB_HLEN. The encoder may use the remaining
// PKTLAB_ENCODE_BUFSZ - PKTLAB_HLEN bytes of the buffer to encode parts of
// the message as well as the remaining elements of iov. On return, iov
// should be filled in so that, excluding the header, the regions of memory
// defined by the iov array encode a valid message. The message header will
// be initialized by pktlab_encode_message after return from the encoder.
// Encoders must not return any pointers to dynamically allocated memory,
// however, iov_base pointers may point to memory regions referenced by msg.
// An encoder must return the number of iovec elements used (including the
// first) if encoding was successful and -1 otherwise. In the latter case,
// errno must be set to indicate the error.

typedef int (*message_encoder_t) (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_status_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_mread_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_mwrite_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_mdata_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_nopen_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_nclose_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_npoll_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_nsend_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_ndata_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_nstat_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_ncap_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_xsub_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_xstart_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_xyield_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_xend_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_xdescr_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_xfilt_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_xkey_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

static int encode_xcert_message (
	const struct pktlab_message * restrict msg,
	struct iovec * restrict iov);

// 
// INTERNAL MACRO DEFINITIONS
// 

#define RETURN_IF(c,v) if (c) return (v)

// 
// EXPORTED FUNCTION DEFINITIONS
// 

size_t pktlab_decode_message (
	struct pktlab_message * msg, const void * ptr, size_t len)
{
	static const message_decoder_t decoders[] = {
		[PKTLAB_STATUS_MESSAGE]		= & decode_status_message,
		[PKTLAB_MREAD_MESSAGE]		= & decode_mread_message,
		[PKTLAB_MWRITE_MESSAGE]		= & decode_mwrite_message,
		[PKTLAB_MDATA_MESSAGE]		= & decode_mdata_message,
		[PKTLAB_NOPEN_MESSAGE]		= & decode_nopen_message,
		[PKTLAB_NCLOSE_MESSAGE]		= & decode_nclose_message,
		[PKTLAB_NPOLL_MESSAGE]		= & decode_npoll_message,
		[PKTLAB_NSEND_MESSAGE]		= & decode_nsend_message,
		[PKTLAB_NDATA_MESSAGE]		= & decode_ndata_message,
		[PKTLAB_NSTAT_MESSAGE]		= & decode_nstat_message,
		[PKTLAB_NCAP_MESSAGE]		= & decode_ncap_message,
		[PKTLAB_XSUB_MESSAGE]		= & decode_xsub_message,
		[PKTLAB_XSTART_MESSAGE]		= & decode_xstart_message,
		[PKTLAB_XYIELD_MESSAGE]		= & decode_xyield_message,
		[PKTLAB_XEND_MESSAGE]		= & decode_xend_message,
		[PKTLAB_XDESCR_MESSAGE]		= & decode_xdescr_message,
		[PKTLAB_XFILT_MESSAGE]		= & decode_xfilt_message,
		[PKTLAB_XKEY_MESSAGE]		= & decode_xkey_message,
		[PKTLAB_XCERT_MESSAGE]		= & decode_xcert_message
	};
	
	message_decoder_t decoder;
	bool malformed = false;
	uint_fast8_t msgtype;
	uint_fast32_t msglen;
	const void * msgptr;
	
	trace("pktlab_decode_message(len:%zu)", len);

	if(len < PKTLAB_HLEN)
		return 0;
	
	msgtype = *(const uint8_t*)ptr;
	msglen = get24n(ptr+1);
	msgptr = ptr+PKTLAB_HLEN;
	
	debug("msgtype: %d", msgtype);
	debug("raw: %d %d %d %d",
		*((uint8_t *) ptr), *((uint8_t *) ptr+1), *((uint8_t *) ptr+2), *((uint8_t *) ptr+3));
	if(msglen > len - PKTLAB_HLEN)
		return 0;
	
	memset(msg, 0, sizeof(struct pktlab_message));
	
	if (msgtype < sizeof(decoders) / sizeof(message_decoder_t)) {
		if ((decoder = decoders[msgtype])) {
			if (!decoder(msg, msgptr, msglen))
				malformed = true;
			else
				goto done;
		}
	}
	
	make_raw_message(msg, ptr, PKTLAB_HLEN + msglen, malformed);
	
done:
	trace("pktlab_decode_message(msg:{type:%c}, msglen:{%u}, len:{%u})", msg->type, msglen, msg->ndata.len);	
	return PKTLAB_HLEN + msglen;
}

int pktlab_encode_message (
	const struct pktlab_message * restrict msg,
	void * restrict buf, struct iovec * restrict iov)
{
	static const message_encoder_t encoders[] = {
		[PKTLAB_STATUS_MESSAGE]		= & encode_status_message,
		[PKTLAB_MREAD_MESSAGE]		= & encode_mread_message,
		[PKTLAB_MWRITE_MESSAGE]		= & encode_mwrite_message,
		[PKTLAB_MDATA_MESSAGE]		= & encode_mdata_message,
		[PKTLAB_NOPEN_MESSAGE]		= & encode_nopen_message,
		[PKTLAB_NCLOSE_MESSAGE]		= & encode_nclose_message,
		[PKTLAB_NPOLL_MESSAGE]		= & encode_npoll_message,
		[PKTLAB_NSEND_MESSAGE]		= & encode_nsend_message,
		[PKTLAB_NDATA_MESSAGE]		= & encode_ndata_message,
		[PKTLAB_NSTAT_MESSAGE]		= & encode_nstat_message,
		[PKTLAB_NCAP_MESSAGE]		= & encode_ncap_message,
		[PKTLAB_XSUB_MESSAGE]		= & encode_xsub_message,
		[PKTLAB_XSTART_MESSAGE]		= & encode_xstart_message,
		[PKTLAB_XYIELD_MESSAGE]		= & encode_xyield_message,
		[PKTLAB_XEND_MESSAGE]		= & encode_xend_message,
		[PKTLAB_XDESCR_MESSAGE]		= & encode_xdescr_message,
		[PKTLAB_XFILT_MESSAGE]		= & encode_xfilt_message,
		[PKTLAB_XKEY_MESSAGE]		= & encode_xkey_message,
		[PKTLAB_XCERT_MESSAGE]		= & encode_xcert_message
	};

	message_encoder_t encoder;
	uint_fast32_t msglen;
	int iovcnt;
	int i;
	
	trace("pktlab_encode_message(msg:{type:%d})", (int) msg->type);
	
	memset(iov, 0, PKTLAB_ENCODE_IOVCNT * sizeof(struct iovec));
	
	if (msg->type < sizeof(encoders) / sizeof(message_encoder_t))
		encoder = encoders[msg->type];
	else
		encoder = NULL;

	if (encoder != NULL) {
		iov[0].iov_base = buf;
		iov[0].iov_len = PKTLAB_HLEN;
		
		iovcnt = encoder(msg, iov);
		RETURN_IF(iovcnt <= 0, iovcnt);
		
		msglen = -PKTLAB_HLEN;
		for (i = 0; i < iovcnt; i++)
			msglen += iov[i].iov_len;
		
		if (msglen > UINT32_C(0xffffff)) {
			errno = EMSGSIZE;
			return -1;
		}
		
		set32n(buf, ((uint_fast32_t) msg->type << 24) | msglen);
		trace("pktlab_encode_message(msg:{type:%c}, msglen:{%u}, len:{%u})", msg->type, msglen, msg->ndata.len);	
		debug("encoded header: %08" PRIxFAST32, get32n(buf));
		
		return iovcnt;
	} 
	
	if (msg->type == PKTLAB_UNDEF_MESSAGE) {
		iov[0].iov_base = (void*) msg->raw.ptr;
		iov[0].iov_len = msg->raw.len;
		return 1;
	}
	
	errno = EINVAL;
	return -1;
}

extern struct pktlab_message * pktlab_create_status_message (
	enum pktlab_status status, const char * fmt, ...)
{
	struct pktlab_message * msg;
	char * textptr;
	size_t textlen;
	char buf[256];
	
	va_list args;
	int result;
		
	if (fmt != NULL) {
		va_start(args, fmt);
		result = vsnprintf(buf, sizeof(buf), fmt, args);
		va_end(args);
		
		RETURN_IF(result < 0, NULL);
		textlen = result;
		
		msg = safe_malloc(sizeof(struct pktlab_message) + result);
		
		textptr = (char*)(msg+1);		
		memcpy(textptr, buf, textlen);
		msg->status.textptr = textptr;
		msg->status.textlen = textlen;
	
	} else
		msg = safe_malloc(sizeof(struct pktlab_message));
	
	memset(msg, 0, sizeof(struct pktlab_message));
	msg->type = PKTLAB_STATUS_MESSAGE;
	msg->status.id = status;
	return msg;
}

// 
// INTERNAL FUNCTION DEFINITIONS
// 

void make_raw_message(struct pktlab_message * msg,
	const void * rawptr, uint_fast32_t rawlen, bool malformed)
{
	trace("make_raw_message(rawlen:%" PRIuFAST32 ", malformed:%s)",
		rawlen, malformed ? "true" : "false");

	msg->type = PKTLAB_UNDEF_MESSAGE;
	msg->raw.malformed = malformed;
	msg->raw.ptr = rawptr;
	msg->raw.len = rawlen;
}

bool decode_status_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);
		
	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   1 id (int8) [optional, implies id == 0 if missing]
	//   1   n textual description [optional]

	msg->type = PKTLAB_STATUS_MESSAGE;
	
	if (len != 0) {
		RETURN_IF(len < 1, false);
		msg->status.id = (int8_t) get8(ptr);
		msg->status.textptr = (len > 1) ? ptr + 1 : NULL;
		msg->status.textlen = len - 1;
	} else {
		msg->status.id = PKTLAB_SUCCESS;
		msg->status.textptr = NULL;
		msg->status.textlen = 0;
	}

	return true;
}

bool decode_mread_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   4 addr (uint32)
	//   4   4 len (uint32)

	RETURN_IF(len != 8, false);
	
	msg->type = PKTLAB_MREAD_MESSAGE;
	msg->mread.addr = get32n(ptr+0);
	msg->mread.len = get32n(ptr+4);
	return true;
}

bool decode_mwrite_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   4 addr (uint32)
	//   4   n data (0 <= n)

	RETURN_IF(len < 4, false);
	
	msg->type = PKTLAB_MWRITE_MESSAGE;
	msg->mwrite.addr = get32n(ptr);
	msg->mwrite.ptr = ptr + 4;
	msg->mwrite.len = len - 4;
	return true;
}

bool decode_mdata_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   4 addr (uint32)
	//   4   n data (0 <= n)

	RETURN_IF(len < 4, false);
	
	msg->type = PKTLAB_MDATA_MESSAGE;
	msg->mdata.addr = get32n(ptr);
	msg->mdata.ptr = ptr + 4;
	msg->mdata.len = len - 4;
	return true;
}

bool decode_nopen_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	uint_fast8_t addrlen;
	
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);
	
	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   1 sktid (uint8)
	//   1   1 proto (uint8)
	//   2   1 interface (uint8)
	//   3   4 rbufsz (uint32)
	//   7   n address (0 < n)
	// 7+n   m ports (0 <= m)

	RETURN_IF(len < 7, false);
	
	msg->type = PKTLAB_NOPEN_MESSAGE;
	msg->nopen.sktid = get8(ptr+0);
	msg->nopen.proto = get8(ptr+1);
	msg->nopen.intf = get8(ptr+2);
	msg->nopen.rbufsz = get32n(ptr+3);
			
	switch (msg->nopen.proto & PKTLAB_NETPROTO_MASK) {
	case PKTLAB_IP4_PROTO:
		addrlen = 4;
		break;
	case PKTLAB_IP6_PROTO:
		addrlen = 16;
		break;
	default:
		return false;
	}
	
	switch (msg->nopen.proto & PKTLAB_TRANSPORT_MASK) {
	case PKTLAB_RAW_PROTO:
	case PKTLAB_ICMP_ECHO_PROTO:
		return (len == 7);
	case PKTLAB_TCP_PROTO:
	case PKTLAB_UDP_PROTO:
		break;
	default:
		return false;
	}
	
	RETURN_IF(len < 7+addrlen, false);
	msg->nopen.addrptr = ptr + 7;
	msg->nopen.addrlen = addrlen;
	msg->nopen.portptr = ptr + (7+addrlen);
	msg->nopen.portlen = len - (7+addrlen);
	return true;
}

bool decode_nclose_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   1 sktid (uint8)

	RETURN_IF(len != 1, false);

	msg->type = PKTLAB_NCLOSE_MESSAGE;
	msg->nclose.sktid = get8(ptr);
	return true;
}

bool decode_npoll_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);
	
	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   8 time until in effect

	RETURN_IF(len != 8, false);

	msg->type = PKTLAB_NPOLL_MESSAGE;
	msg->npoll.time = get64n(ptr);
	return true;
}

bool decode_nsend_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	uint8_t addrlen;

	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   1 sktid (uint8)
	//   1   1 proto (uint8)
	//   2   2 tidx (uint16)
	//   4   8 time received
	//  12     proto-specific data

	// proto-specific data field format
	//  OFF LEN DESCRIPTION
	// ---- --- -----------
	// - For raw, tcp & udp send sockets
	//   12   n data (0 <= n)
	//
	// - For icmp echo sockets
	//   12   m dest. addr (0 < m)
	// m+12   1 TTL (uint8)
	// m+13   2 seq (uint16)
	// m+15   n data (0 <= n)

	RETURN_IF(len < 12, false);

	msg->type = PKTLAB_NSEND_MESSAGE;
	msg->nsend.sktid = get8(ptr+0);
	msg->nsend.proto = get8(ptr+1);
	msg->nsend.tidx = get16n(ptr+2);
	msg->nsend.time = get64n(ptr+4);

	switch (msg->nsend.proto & PKTLAB_TRANSPORT_MASK) {
	case PKTLAB_RAW_PROTO:
		msg->nsend.raw.ptr = ptr + 12;
		msg->nsend.raw.len = len - 12;
		return true;
	case PKTLAB_TCP_PROTO:
		msg->nsend.tcp.ptr = ptr + 12;
		msg->nsend.tcp.len = len - 12;
		return true;
	case PKTLAB_UDP_PROTO:
		msg->nsend.udp.ptr = ptr + 12;
		msg->nsend.udp.len = len - 12;
		return true;
	case PKTLAB_ICMP_ECHO_PROTO:
		msg->nsend.icmp.addrptr = ptr + 12;

		switch (msg->nsend.proto & PKTLAB_NETPROTO_MASK) {
		case PKTLAB_IP4_PROTO:
			addrlen = PKTLAB_IPV4_WO_MSK_ADDR_LEN;
			break;
		case PKTLAB_IP6_PROTO:
			addrlen = PKTLAB_IPV6_ADDR_LEN;
			break;
		default:
			return false;
		}

		RETURN_IF(len < 12+addrlen+3, false);

		msg->nsend.icmp.addrlen = addrlen;
		msg->nsend.icmp.ttl = get8(ptr+addrlen+12);
		msg->nsend.icmp.seq = get16n(ptr+addrlen+13);
		msg->nsend.icmp.dataptr = ptr + addrlen + 15;
		msg->nsend.icmp.datalen = len - addrlen - 15;
		return true;
	default:
		return false;
	}
}

bool decode_ndata_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   1 sktid (uint8)
	//   1   1 proto (uint8)
	//   2   8 time received
	//   10   n data (0 <= n)

	RETURN_IF(len < 10, false);

	msg->type = PKTLAB_NDATA_MESSAGE;
	msg->ndata.sktid = get8(ptr+0);
	msg->ndata.proto = get8(ptr+1);
	msg->ndata.time = get64n(ptr+2);
	msg->ndata.ptr = ptr + 10;
	msg->ndata.len = len - 10;
	return true;
}

bool decode_nstat_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------


	msg->type = PKTLAB_NSTAT_MESSAGE;
	msg->nstat.ptr = ptr;
	msg->nstat.len = len;
	return true;
}

bool decode_ncap_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   8 time until in effect
	//   8   n filter program (0 <= n)

	RETURN_IF(len < 8, false);

	msg->type = PKTLAB_NCAP_MESSAGE;
	msg->ncap.time = get64n(ptr);
	msg->ncap.filtptr = ptr + 8;
	msg->ncap.filtlen = len - 8;
	return true;
}

bool decode_xsub_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   n key or experiment hash (0 < n)
	
	RETURN_IF(len <= 0, false);
	
	msg->type = PKTLAB_XSUB_MESSAGE;
	msg->xsub.hashptr = ptr;
	msg->xsub.hashlen = len;
	return true;
}

bool decode_xstart_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   8 wait until time if busy
	//   8   2 priority (preempt lower-priority experiments after waiting)
	//  10   n experiment hash (0 < n)
	
	RETURN_IF(len <= 10, false);
	
	msg->type = PKTLAB_XSTART_MESSAGE;
	msg->xstart.time = get64n(ptr+0);
	msg->xstart.prio = get16n(ptr+8);
	msg->xstart.hashptr = ptr+10;
	msg->xstart.hashlen = len-10;
	return true;
}

bool decode_xyield_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	
	RETURN_IF(len != 0, false);
	
	msg->type = PKTLAB_XYIELD_MESSAGE;
	return true;
}

bool decode_xend_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	
	RETURN_IF(len != 0, false);
	
	msg->type = PKTLAB_XEND_MESSAGE;
	return true;
}

bool decode_xdescr_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   n experiment descriptor (0 < n)
	
	RETURN_IF(len <= 0, false);
	
	msg->type = PKTLAB_XDESCR_MESSAGE;
	msg->xdescr.ptr = ptr;
	msg->xdescr.len = len;
	return true;
}

bool decode_xfilt_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);

	// OFF LEN DESCRIPTION
	// --- --- -----------
	//   0   n filter program (0 <= n)
	
	RETURN_IF(len < 0, false);
	
	msg->type = PKTLAB_XFILT_MESSAGE;
	msg->xfilt.ptr = ptr;
	msg->xfilt.len = len;
	return true;
}

bool decode_xkey_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);
	debug("decode_xkey_message not implemented");
	return false;
}

bool decode_xcert_message (
	struct pktlab_message * msg, const void * ptr, uint_fast32_t len)
{
	trace("%s(len:%" PRIuFAST32 ")", __func__, len);
	debug("decode_xcert_message not implemented");
	return false;
}

int encode_status_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	void * ptr = iov[0].iov_base + iov[0].iov_len;
	
	trace("encode_status_message(msg:{id:%d,textlen:%u})",
		(int) msg->status.id, (unsigned int) msg->status.textlen);
	
	if (msg->status.id != 0) {
		set8(ptr, (uint8_t) msg->status.id);
		iov[0].iov_len += 1;
	} else
		return 1;
	
	if (msg->status.textptr != NULL && msg->status.textlen > 0) {
		iov[1].iov_base = (void*) msg->status.textptr;
		iov[1].iov_len = msg->status.textlen;
		return 2;
	} else
		return 1;
}

int encode_mread_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	void * ptr = iov[0].iov_base + iov[0].iov_len;
	
	trace("encode_mread_message(msg:{addr:%u,len:%u})",
		(unsigned int) msg->mread.addr, (unsigned int) msg->mread.len);
	
	set32n(ptr+0, msg->mread.addr);
	set32n(ptr+4, msg->mread.len);
	iov[0].iov_len += 8;
	return 1;
}

int encode_mwrite_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	void * ptr = iov[0].iov_base + iov[0].iov_len;
	
	trace("encode_mwrite_message(msg:{addr:%u,len:%u})",
		(unsigned) msg->mwrite.addr, (unsigned) msg->mwrite.len);
	
	set32n(ptr, msg->mwrite.addr);
	iov[0].iov_len += 4;
	
	iov[1].iov_base = (void*) msg->mwrite.ptr;
	iov[1].iov_len = msg->mwrite.len;
	return 2;
}

int encode_mdata_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	void * ptr = iov[0].iov_base + iov[0].iov_len;
	
	trace("encode_mdata_message(msg:{addr:%u,len:%u})",
		(unsigned) msg->mdata.addr, (unsigned) msg->mdata.len);
	
	set32n(ptr, msg->mdata.addr);
	iov[0].iov_len += 4;
	
	iov[1].iov_base = (void*) msg->mdata.ptr;
	iov[1].iov_len = msg->mdata.len;
	return 2;
}

int encode_nopen_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	void * ptr = iov[0].iov_base + iov[0].iov_len;
	
	trace("encode_nopen_message(msg:{sktid:%d,proto:0x%02x,intf:%u,rbufsz:%u})",
		(int) msg->nopen.sktid, (int) msg->nopen.proto,
		(unsigned int) msg->nopen.intf, (unsigned int) msg->nopen.rbufsz);

	set8(ptr+0, msg->nopen.sktid);
	set8(ptr+1, msg->nopen.proto);
	set8(ptr+2, msg->nopen.intf);
	set32n(ptr+3, msg->nopen.rbufsz);
	iov[0].iov_len += 7;
	
	switch (msg->nopen.proto & PKTLAB_TRANSPORT_MASK) {
	case PKTLAB_RAW_PROTO:
	case PKTLAB_ICMP_ECHO_PROTO:
		return 1;
	case PKTLAB_TCP_PROTO:
	case PKTLAB_UDP_PROTO:
		iov[1].iov_base = (void*) msg->nopen.addrptr;
		iov[1].iov_len = msg->nopen.addrlen;
		iov[2].iov_base = (void*) msg->nopen.portptr;
		iov[2].iov_len = msg->nopen.portlen;
		return 3;
	default:
		return -1;
	}
}

int encode_nclose_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	void * ptr = iov[0].iov_base + iov[0].iov_len;

	trace("encode_nclose_message(msg:{sktid:%d})", (int) msg->nclose.sktid);
	
	set8(ptr+0, (uint8_t) msg->nclose.sktid);
	iov[0].iov_len += 1;
	return 1;
}

int encode_npoll_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	void * ptr = iov[0].iov_base + iov[0].iov_len;

	trace("encode_npoll_message(msg:{time:%.6f})",
		(double) msg->npoll.time / PKTLAB_TICKS_PER_SECOND);
	
	set64n(ptr, msg->npoll.time);
	iov[0].iov_len += 8;
	return 1;
}

int encode_nsend_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	void * ptr = iov[0].iov_base + iov[0].iov_len;
	uint8_t addrlen;

	trace("encode_nsend_message(msg:{" \
		"sktid:%d, proto:0x%02x, tidx:%u, time:%.6f})",
		(int) msg->nsend.sktid,
		(int) msg->nsend.proto,
		(unsigned int) msg->nsend.tidx,
		(double) msg->nsend.time / PKTLAB_TICKS_PER_SECOND);
	
	set8(ptr+0, (uint8_t) msg->nsend.sktid);
	set8(ptr+1, (uint8_t) msg->nsend.proto);
	set16n(ptr+2, (uint16_t) msg->nsend.tidx);
	set64n(ptr+4, msg->nsend.time);
	iov[0].iov_len += 12;

	switch (msg->nsend.proto & PKTLAB_TRANSPORT_MASK) {
	case PKTLAB_RAW_PROTO:
		iov[1].iov_base = (void*) msg->nsend.raw.ptr;
		iov[1].iov_len = msg->nsend.raw.len;
		return 2;
	case PKTLAB_TCP_PROTO:
		iov[1].iov_base = (void*) msg->nsend.tcp.ptr;
		iov[1].iov_len = msg->nsend.tcp.len;
		return 2;
	case PKTLAB_UDP_PROTO:
		iov[1].iov_base = (void*) msg->nsend.udp.ptr;
		iov[1].iov_len = msg->nsend.udp.len;
		return 2;
	case PKTLAB_ICMP_ECHO_PROTO:
		addrlen = msg->nsend.icmp.addrlen;

		memcpy(ptr+12, msg->nsend.icmp.addrptr, addrlen);
		set8(ptr+12+addrlen, (uint8_t) msg->nsend.icmp.ttl);
		set16n(ptr+12+addrlen+1, (uint16_t) msg->nsend.icmp.seq);
		iov[0].iov_len += addrlen + 3;

		iov[1].iov_base = (void*) msg->nsend.icmp.dataptr;
		iov[1].iov_len = msg->nsend.icmp.datalen;
		return 2;
	default:
		return -1;
	}
}

int encode_ndata_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	void * ptr = iov[0].iov_base + iov[0].iov_len;

	trace("encode_ndata_message(msg:{" \
		"sktid:%d, proto:0x%02x, time:%.6f, len:%u})",
		(int) msg->ndata.sktid,
		(int) msg->ndata.proto,
		(double) msg->ndata.time / PKTLAB_TICKS_PER_SECOND,
		(unsigned int) msg->ndata.len);
	
	set8(ptr+0, (uint8_t) msg->ndata.sktid);
	set8(ptr+1, (uint8_t) msg->ndata.proto);
	set64n(ptr+2, msg->ndata.time);
	iov[0].iov_len += 10;

	iov[1].iov_base = (void*) msg->ndata.ptr;
	iov[1].iov_len = msg->ndata.len;
	return 2;
}

int encode_nstat_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	trace("encode_nstat_message(msg:{len:%u})", (unsigned int) msg->nstat.len);
	
	if (msg->nstat.ptr != NULL && msg->nstat.len > 0) {
		iov[1].iov_base = (void*) msg->nstat.ptr;
		iov[1].iov_len = msg->nstat.len;
		return 2;
	} else
		return 1;
}

int encode_ncap_message (
	const struct pktlab_message * msg, struct iovec * iov)
{
	void * ptr = iov[0].iov_base + iov[0].iov_len;
	
	trace("encode_ncap_message(msg:{time:%.6f, filtlen:%u})",
		(double) msg->ncap.time / PKTLAB_TICKS_PER_SECOND,
		(unsigned int) msg->ncap.filtlen);
	

	set64n(ptr+0, msg->ncap.time);
	iov[0].iov_len += 8;
	
	if (msg->ncap.filtptr != NULL && msg->ncap.filtlen > 0) {
		iov[1].iov_base = (void*) msg->ncap.filtptr;
		iov[1].iov_len = msg->ncap.filtlen;
		return 2;
	} else 
		return 1;
}

int encode_xsub_message (
	const struct pktlab_message * msg, struct iovec * iov)
{	
	if (msg->xsub.hashlen > 5)
		trace("encode_xsub_message(msg:{%02x..%02x%02x%02x%02x})",
		*(const uint8_t*)(msg->xsub.hashptr + 0),
		*(const uint8_t*)(msg->xsub.hashptr + msg->xsub.hashlen - 4),
		*(const uint8_t*)(msg->xsub.hashptr + msg->xsub.hashlen - 3),
		*(const uint8_t*)(msg->xsub.hashptr + msg->xsub.hashlen - 2),
		*(const uint8_t*)(msg->xsub.hashptr + msg->xsub.hashlen - 1));
	else
		trace("encode_xsub_message(msg:{hashlen:%u})",
			(unsigned int) msg->xsub.hashlen);
	
	if (msg->xsub.hashptr != NULL && msg->xsub.hashlen > 0) {
		iov[1].iov_base = (void*) msg->xsub.hashptr;
		iov[1].iov_len = msg->xsub.hashlen;
		return 2;
	} else
		return 1;
}

int encode_xstart_message (
	const struct pktlab_message * msg, struct iovec * iov)
{	
	void * ptr = iov[0].iov_base + iov[0].iov_len;
	
	if (msg->xstart.hashlen > 5)
		trace("encode_xinit_message(" \
		"msg:{time:%.6f, prio:%u, %02x..%02x%02x%02x%02x})",
		(double) msg->xstart.time / PKTLAB_TICKS_PER_SECOND,
		(unsigned int) msg->xstart.prio,
		*(const uint8_t*)(msg->xstart.hashptr + 0),
		*(const uint8_t*)(msg->xstart.hashptr + msg->xstart.hashlen - 4),
		*(const uint8_t*)(msg->xstart.hashptr + msg->xstart.hashlen - 3),
		*(const uint8_t*)(msg->xstart.hashptr + msg->xstart.hashlen - 2),
		*(const uint8_t*)(msg->xstart.hashptr + msg->xstart.hashlen - 1));
	else
		trace("encode_xinit_message(msg:{time:%.6f, prio:%u, hashlen:%u})",
		(double) msg->xstart.time / PKTLAB_TICKS_PER_SECOND,
		(unsigned int) msg->xstart.prio,
		(unsigned int) msg->xstart.hashlen);

	set64n(ptr+0, msg->xstart.time);
	set16n(ptr+8, msg->xstart.prio);
	iov[0].iov_len += 10;

	if (msg->xstart.hashptr != NULL && msg->xstart.hashlen > 0) {
		iov[1].iov_base = (void*) msg->xstart.hashptr;
		iov[1].iov_len = msg->xstart.hashlen;
		return 2;
	} else
		return 1;
}

int encode_xyield_message (
	const struct pktlab_message * msg, struct iovec * iov)
{	
	trace("encode_xyield_message(msg:{})");
	return 1;
}

int encode_xend_message (
	const struct pktlab_message * msg, struct iovec * iov)
{	
	trace("encode_xend_message(msg:{})");
	return 1;
}

int encode_xdescr_message (
	const struct pktlab_message * msg, struct iovec * iov)
{	
	trace("encode_xdescr_message(msg:{len:%u})",
		(unsigned int) msg->xdescr.len);
	
	if (msg->xdescr.ptr != NULL && msg->xdescr.len > 0) {
		iov[1].iov_base = (void*) msg->xdescr.ptr;
		iov[1].iov_len = msg->xdescr.len;
		return 2;
	} else
		return 1;
}

int encode_xfilt_message (
	const struct pktlab_message * msg, struct iovec * iov)
{	
	trace("encode_xfilt_message(msg:{len:%u})",
		(unsigned int) msg->xdescr.len);
	
	if (msg->xfilt.ptr != NULL && msg->xfilt.len > 0) {
		iov[1].iov_base = (void*) msg->xfilt.ptr;
		iov[1].iov_len = msg->xfilt.len;
		return 2;
	} else
		return 1;
}

int encode_xkey_message (
	const struct pktlab_message * msg, struct iovec * iov)
{	
	trace("encode_xkey_message(msg:{...})");
	debug("encode_xkey_message not implemented");
	return 0;
}

int encode_xcert_message (
	const struct pktlab_message * msg, struct iovec * iov)
{	
	trace("encode_xcert_message(msg:{...})");
	debug("encode_xcert_message not implemented");
	return 0;
}

