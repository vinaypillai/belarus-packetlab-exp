// pktlab/reader.c
// 

#include "pktlab.h"

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/uio.h>

#include "private.h"

// 
// INTERNAL CONSTANTS
// 

#define BUFSZ	64

// 
// INTERNAL TYPE DEFINITIONS
// 

struct pktlab_reader {
	int fd;
	int8_t state;
	struct pktlab_message * msg;
	uint32_t bytecnt, msglen;
	void * rawptr;
	char buf[BUFSZ];
};

// 
// INTERNAL FUNCTION DECLARATIONS
// 

static int read_header(struct pktlab_reader * r);
static int read_data(struct pktlab_reader * r);
static int start_message(struct pktlab_reader * r);
static int resolve_error(struct pktlab_reader * r);
static int resolve_eof(struct pktlab_reader * r);

// 
// INTERNAL STATE CONSTANTS
// 

#define READING_HEADER	-1
#define READING_DATA	0
#define MESSAGE_READY	1
#define READ_ERROR		2
#define READER_START	READING_HEADER

// PKTLAB_READER BUFFER
// 
// The internal pktlab_reader read buffer has the following structure:
// 
// +----------------------------------------------+
// |XXXXXXXXXXXXXXXXXXXXXXXXX|                    |
// +----------------------------------------------+
// ^                         ^                    ^
// 0                         bytecnt              sizeof(buf)
// 
// In the states READING_HEADER and MESSAGE_READY, bytecnt indicates the
// number of valid data bytes in the read buffer. In the READING_DATA
// state, the read buffer is empty and bytecnt denotes the number of bytes
// of the message that have been read.
// 

// 
// EXPORTED FUNCTION DEFINITIONS
// 

struct pktlab_reader * pktlab_create_reader(int fd) {
	struct pktlab_reader * r;
	
	if (fd < 0) {
		errno = EINVAL;
		return NULL;
	}
	
	r = safe_malloc(sizeof(struct pktlab_reader));
	memset(r, 0, offsetof(struct pktlab_reader, buf));
	r->state = READER_START;
	r->fd = fd;
	
	return r;
}

void pktlab_close_reader(struct pktlab_reader * r) {
	if (r->msg != NULL)
		free(r->msg);
	
	free(r);
}

int pktlab_reader_fileno(const struct pktlab_reader * r) {
	return r->fd;
}

int pktlab_read_message (
	struct pktlab_reader * r, struct pktlab_message ** msgptr)
{
	int result;
	
	trace("%s(r:{fd:%d, state:%d, bytecnt:%zu, msglen:%zu})", __func__, 
		r->fd, (int) r->state, (size_t) r->bytecnt, (size_t) r->msglen);
	
	// If msgptr is NULL, we're being polled to see if a mesage is ready.
	// An EOF condition always indicates message ready.
	
	if (msgptr == NULL) {
		if (r->state < MESSAGE_READY)
			return 0;
		if (r->state == MESSAGE_READY)
			return 1;
		if (r->state > MESSAGE_READY)
			return -1;
	}
	
	// Keep reading until we get an error, would block, or get an error.
	
	while (r->state < MESSAGE_READY) {
		if (r->state <= READING_HEADER)
			result = read_header(r);
		else
			result = read_data(r);
	
		if (result <= 0)
			return result;
	}
	
	// At this point, r->state == MESSAGE_READY. If r->msg is NULL, then
	// we've read EOF, which we signal by returning *msgptr == NULL.
	
	if (r->msg) {
		pktlab_decode_message(r->msg, r->rawptr, r->msglen);
		*msgptr = r->msg;
		r->msg = NULL;
		
		r->state = READING_HEADER;
		if (r->bytecnt >= PKTLAB_HLEN)
			start_message(r);
	} else
		*msgptr = NULL;
	
	return 1;		
}

// 
// INTERNAL FUNCTION DEFINITIONS
// 

// The read_header function attempts to read and return a message when
// r->state == READING_HEADER. Note that this implies r->msg == NULL.

int read_header(struct pktlab_reader * r) {
	ssize_t result;
	
	trace("read_header(r:{fd:%d, state:%d, bytecnt:%u})",
		r->fd, (int) r->state, (unsigned int) r->bytecnt);

	// Read from descriptor into remaining buffer space.
	// 
	
	result = read(r->fd, r->buf + r->bytecnt, sizeof(r->buf) - r->bytecnt);
	
	debug("r:{fd:%d, bytecnt:%d}: read(len:%d) returned %d",
		r->fd, (int) r->bytecnt, sizeof(r->buf) - r->bytecnt, result);

	if (result <= 0)
		return (result < 0) ? resolve_error(r) : resolve_eof(r);
	
	r->bytecnt += result;
	
	// If we have at least a header's worth of data, start new message.
	
	if (PKTLAB_HLEN <= r->bytecnt)
		start_message(r);
	
	return result;
}

// The read_payload function attempts to read and return a message when
// r->state == READING_DATA.

int read_data(struct pktlab_reader * r) {
	struct iovec iov[2];
	ssize_t result;

	debug("read_data(r:{fd:%d, state:%d, bytecnt:%zu, msglen:%zu})",
		r->fd, (int) r->state, (size_t) r->bytecnt, (size_t) r->msglen);

	iov[0].iov_base = r->rawptr + r->bytecnt;
	iov[0].iov_len = r->msglen - r->bytecnt;
	iov[1].iov_base = r->buf;
	iov[1].iov_len = sizeof(r->buf);
	
	result = readv(r->fd, iov, 2);
	
	if (result <= 0)
		return (result < 0) ? resolve_error(r) : resolve_eof(r);
	
	r->bytecnt += result;
	
	if (r->bytecnt >= r->msglen) {
		r->bytecnt -= r->msglen;
		r->state = MESSAGE_READY;
	}
	
	return result;
}

// The start_message attempts to create a message from the contents of the
// buffer. It assumes r->bytecnt >= PKTLAB_HLEN. On return, r->state is 
// either READING_DATA or MESSAGE_READY.

int start_message(struct pktlab_reader * r) {
	trace("start_message(r:{fd:%d, state:%d, bytecnt:%d})",
		r->fd, (int) r->state, (int) r->bytecnt);
	
	if (r->bytecnt < PKTLAB_HLEN)
		return -1;
	
	// Parse 32-bit message header. First byte is message type. Next 24 bits
	// encode length of data that follows header. 
	
	r->msglen = PKTLAB_HLEN + get24n(r->buf + 1);
	
	r->msg = safe_malloc(sizeof(struct pktlab_message) + r->msglen);
	r->rawptr = r->msg + 1;
	
	debug("r:{fd:%d, bytecnt:%d}: malloc'd %d bytes for %d-byte message",
		r->fd, (int) r->bytecnt, sizeof(struct pktlab_message) + r->msglen,
		(int) r->msglen);
	
	if (r->bytecnt < r->msglen) {
		memcpy(r->rawptr, r->buf, r->bytecnt);
		// r->bytecnt becomes number of message bytes available
		r->state = READING_DATA;
		return 0;
	} else {
		memcpy(r->rawptr, r->buf, r->msglen);
		memmove(r->buf, r->buf + r->msglen, r->bytecnt - r->msglen);
		r->bytecnt -= r->msglen;
		r->state = MESSAGE_READY;
		return 1;
	}
}

// The resolve_error function is called by read_header or read_data when
// read returns -1, indicating that either the call would block (errno is
// EWOULDBLOCK), that the call was interrupted (errno is EINTR), or that a
// serious error occured. In the first two cases, we return 0, indicate no
// message available and remain in the same state. If a serious error
// occurs, we return -1 and change the state to READ_ERROR.

int resolve_error(struct pktlab_reader * r) {
	if (errno == EWOULDBLOCK || errno == EINTR)
		return 0;
	
	if (r->msg != NULL) {
		free(r->msg);
		r->msg = NULL;
	}
	
	r->state = READ_ERROR;
	return -1;
		
}

// The resolve_eof function is called by read_header or read_data when read
// return 0, indicating an end-of-file condition. If this happens
// mid-message (r->bytecnt > 0), we consider it an error and return EPIPE.
// Otherwise, it's a normal end-of-file, which we signal by returning a
// NULL message.

int resolve_eof(struct pktlab_reader * r) {
	if (r->bytecnt == 0) {
		r->state = MESSAGE_READY;
		return 1;
	}

	if (r->msg != NULL) {
		free(r->msg);
		r->msg = NULL;
	}
	
	r->state = READ_ERROR;
	errno = EPIPE;
	return -1;
}
