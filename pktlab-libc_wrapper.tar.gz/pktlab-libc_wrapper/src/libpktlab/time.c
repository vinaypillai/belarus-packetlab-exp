// pktlab/time.c
// 

#include <pktlab.h>

pktlab_time_t pktlab_time_now(void) {
	struct timeval tv;
	
	gettimeofday(&tv, NULL);
	return pktlab_timeval_to_time(&tv);
}
