// pktlab/writer.c
// 

#include "pktlab.h"

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/uio.h>

#include "private.h"

// 
// INTERNAL TYPE DEFINITIONS
// 

struct pktlab_writer {
	void * buf;
	int fd;
	uint32_t bufsz;
	uint32_t bufoff;
	uint32_t bufcnt;
};

// 
// INTERNAL FUNCTION DECLARATIONS
// 

static void buffer_message (
	struct pktlab_writer * restrict w, uint_fast32_t skipcnt,
	const struct iovec * restrict iov, int iovcnt);

// 
// INTERNAL CONSTANTS
// 

// ...
// 
// EXPORTED FUNCTION DEFINITIONS
// 

struct pktlab_writer * pktlab_create_writer(int fd) {
	struct pktlab_writer * w;
	
	if (fd < 0) {
		errno = EINVAL;
		return NULL;
	}
	
	w = safe_malloc(sizeof(struct pktlab_writer));
	memset(w, 0, sizeof(struct pktlab_writer));
	
	w->fd = fd;
	return w;
}

void pktlab_close_writer(struct pktlab_writer * w) {
	if (w->buf != NULL)
		free(w->buf);
	free(w);
}

int pktlab_flush_writer(struct pktlab_writer * w) {
	uint_fast32_t sentcnt = 0; // bytes sent during this call
	ssize_t result;
	
	trace("pktlab_flush_writer(w:{fd:%d, offset:%u, bytecnt:%u})",
		w->fd, (unsigned int) w->bufoff, (unsigned int) w->bufcnt);

	while (w->bufcnt > 0) {
		result = write(w->fd, w->buf + w->bufoff, w->bufcnt);
		
		if (result < 0) {
			if (errno == EWOULDBLOCK)
				return sentcnt;
			else
				return result;
		}
		
		w->bufoff += result;
		w->bufcnt -= result;
		sentcnt += result;
	}
	
	// We get here only if w->bufcnt == 0, so reset w->bufoff to 0.
	//
	
	w->bufoff = 0;
	return sentcnt;
}

int pktlab_write_message (
	struct pktlab_writer * w,
	const struct pktlab_message * msg)
{
	char enc_buf[PKTLAB_ENCODE_BUFSZ];
	struct iovec msg_iov[PKTLAB_ENCODE_IOVCNT];
	int msg_iovcnt;
	
	struct iovec iov[1+PKTLAB_ENCODE_IOVCNT];
	uint_fast32_t sentcnt;
	uint_fast32_t skipcnt;
	int i, iovcnt;
	ssize_t result;
	
	trace("pktlab_write_message(w:{fd:%d, bufcnt:%d}, msg:{type:%d})",
		w->fd, (int) w->bufcnt, (int) msg->type);
	
	msg_iovcnt = pktlab_encode_message(msg, enc_buf, msg_iov);
	
	if (msg_iovcnt < 0)
		return msg_iovcnt;
	
	// Set up iovec structure to write previously buffered data (if any),
	// followed by the current nessage contents. When writev returns,
	// figure out which parts got written and attempt the write again until
	// we succeed or an error occurs. At the top of the loop, we assume 
	// that sentcnt have been sent in all.
	
	sentcnt = 0;

	while (true) {
		iovcnt = 0;
		
		// Subtract sentcnt from count of bytes in buffer (w->bufcnt), so
		// that sentcnt is the nuber of bytes of the new message we've sent
		// so far.
		
		if (sentcnt < w->bufcnt) {
			w->bufcnt -= sentcnt;
			w->bufoff += sentcnt;
			iov[iovcnt].iov_base = w->buf + w->bufoff;
			iov[iovcnt].iov_len = w->bufcnt;
			iovcnt += 1;
			sentcnt = 0;
		} else {
			sentcnt -= w->bufcnt;
			w->bufcnt = 0;
			w->bufoff = 0;
		}
		
		// skipcnt is the number of bytes we need to skip, and starts as
		// the number of bytes of the message we've sent so far. We
		// decrement skipcnt by the size of each part until we get to a
		// part that has not been sent completely.
		
		skipcnt = sentcnt;

		for (i = 0; i < msg_iovcnt; i++) {
			if (skipcnt < msg_iov[i].iov_len) {
				iov[iovcnt].iov_base = msg_iov[i].iov_base + skipcnt;
				iov[iovcnt].iov_len = msg_iov[i].iov_len - skipcnt;
				iovcnt += 1;
				skipcnt = 0;
			} else
				skipcnt -= msg_iov[i].iov_len;
		}
		
		if (iovcnt == 0)
			return 1;
				
		result = writev(w->fd, iov, iovcnt);
		
		debug("writev(fd:%d) returned %d with errno %d", w->fd, result, errno);
		
		if (result < 0) {
			if (errno != EWOULDBLOCK)
				return result;
			else
				break;
		}
		
		sentcnt += result;
	}
	
	// We get to this point if errno == EWOULDBLOCK. In non-blocking mode,
	// we need to either accept the message or reject it as a whole. Thus,
	// if errno == EWOULDBLOCK, there are two cases to consider.
	// 
	// CASE 1. No part of the message was written. Reject the message by
	// returning 0.
	// 
	// CASE 2. A part of the message was written. Accept the message by
	// returning 1 and buffer and remaining contents.
	
	if (sentcnt > 0) {
		buffer_message(w, sentcnt, msg_iov, msg_iovcnt);
		return 1;
	}
	
	return 0;
}

size_t pktlab_writer_unsent(const struct pktlab_writer * w) {
	return w->bufcnt;
}

int pktlab_writer_fileno(const struct pktlab_writer * w) {
	return w->fd;
}

// 
// INTERNAL FUNCTION DEFINITIONS
// 

// The buffer_message function saves the unsent portion of a message to the
// internal write buffer. On entry, iov must point to iovcnt elements of
// struct iovec that together describe the message. The skipcnt argument
// indicates the number of bytes of the message that have already been
// sent. The remainder of the message will be saved to the write buffer;
// w->bufoff  will set to 0 and w->byecnt to the number of bytes in the
// buffer. Only called if buffer is empty.

void buffer_message (
	struct pktlab_writer * w, uint_fast32_t skipcnt,
	const struct iovec * iov, int iovcnt)
{
	uint_fast32_t skipcnt_save = skipcnt;
	uint_fast32_t bytecnt = 0;
	uint_fast32_t len;
	void * ptr;
	int i;
	
	trace("buffer_message(w:{fd:%d, bufcnt:%u},skipcnt:%u)",
		w->fd, (unsigned int) w->bufcnt, (unsigned int) skipcnt);
	
	// Count the number of bytes we need to send.
	
	for (i = 0; i < iovcnt; i++) {
		len = iov[i].iov_len;
		if (skipcnt < len) {
			bytecnt += len - skipcnt;
			skipcnt = 0;
		} else
			skipcnt -= len;
	}
	
	// Allocate a larger send buffer, if necessary.
	
	if (bytecnt > w->bufsz) {
		if (w->buf != NULL)
			free(w->buf);
		
		w->buf = safe_malloc(bytecnt);
		w->bufsz = bytecnt;
	}
	
	// Copy remaining data to buffer.
	
	skipcnt = skipcnt_save;
	for (i = 0; i < iovcnt; i++) {
		ptr = iov[i].iov_base;
		len = iov[i].iov_len;
		if (skipcnt < len) {
			memcpy(w->buf + w->bufcnt, ptr + skipcnt, len - skipcnt);
			w->bufcnt += len - skipcnt;
			skipcnt = 0;
		} else
			skipcnt -= len;
	}
}
