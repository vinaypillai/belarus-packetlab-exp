// pktlab/xattr.c
//

#include "pktlab.h"

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "private.h"

// 
// INTERNAL TYPE DEFINITIONS
// 

// ...

// * ADDING A NEW XATTR TYPE
//
// Adding a new xattr type requires the following:
// 
// 1. Add the type to enum pktlab_xattr_type in xattr.h.
// 2. Add data fields to struct pktlab_xattr.
// 3. Declare a pktlab_create_ATTRNAME_xattr function to xattr.h.
// 4. Define a pktlab_create_ATTRNAME_xattr function in xattr.c.
// 5. Create a decoder function (decode_ATTRNAME) in xattr.c.
// 6. Add call to call above function to switch in decoder().
// 7. Create an encoder function (encode_ATTRNAME) in xattr.c.
// 8. Add call to call above function to switch in encoder().
// 9. Create an encoded length formula to switch in encoded_length().

// 
// INTERNAL FUNCTION DEFINITIONS
// 

static struct pktlab_xattr * decode (
	uint_fast8_t type, uint_fast8_t len, const void * ptr);

static void encode (
	const struct pktlab_xattr * restrict attr, void * restrict buf);

static struct pktlab_xattr * create_unknown (
	uint_fast8_t type, uint_fast8_t len);

// 
// INTERNAL DECODER FUNCTION DECLARATIONS
// 

static struct pktlab_xattr * decode_name (
	uint_fast8_t type, uint_fast8_t len, const void * ptr);

static struct pktlab_xattr * decode_seqno (
	uint_fast8_t type, uint_fast8_t len, const void * ptr);

static struct pktlab_xattr * decode_time (
	uint_fast8_t type, uint_fast8_t len, const void * ptr);

static struct pktlab_xattr * decode_server_host (
	uint_fast8_t type, uint_fast8_t len, const void * ptr);

static struct pktlab_xattr * decode_server_port (
	uint_fast8_t type, uint_fast8_t len, const void * ptr);

static struct pktlab_xattr * decode_filter_hash (
	uint_fast8_t type, uint_fast8_t len, const void * ptr);

// 
// INTERNAL ENCODER FUNCTION DECLARATIONS
// 

static void encode_unknown (
	const struct pktlab_xattr * restrict attr, void * restrict ptr);

static void encode_name (
	const struct pktlab_xattr * restrict attr, void * restrict ptr);

static void encode_seqno (
	const struct pktlab_xattr * restrict attr, void * restrict ptr);

static void encode_time (
	const struct pktlab_xattr * restrict attr, void * restrict ptr);

static void encode_server_host (
	const struct pktlab_xattr * restrict attr, void * restrict ptr);

static void encode_server_port (
	const struct pktlab_xattr * restrict attr, void * restrict ptr);

static void encode_filter_hash (
	const struct pktlab_xattr * restrict attr, void * restrict ptr);

// 
// EXPORTED FUNCTION DEFINITIONS
// 

struct pktlab_xattr * pktlab_xattrlist_decode (
	const void * ptr, uint_fast32_t len)
{
	struct pktlab_xattr * head = NULL;
	struct pktlab_xattr ** nptr = & head;
	struct pktlab_xattr * attr;
	uint8_t attr_type;
	uint8_t attr_len;
	
	while (len > 0) {
		GOTO_IF(len < 2, tooshort);
		attr_type = *(const uint8_t*)(ptr+0);
		attr_len = *(const uint8_t*)(ptr+1);
		ptr += 2;
		len -= 2;
		
		GOTO_IF(len < attr_len, tooshort);
		
		attr = decode(attr_type, attr_len, ptr);
		GOTO_IF(attr == NULL, malformed);
		
		*nptr = attr;
		nptr = & attr->next;
		
		ptr += attr_len;
		len -= attr_len;
	}
	
	return head;

tooshort:
	errno = EINVAL;
	return NULL;

malformed:
	errno = EBADMSG;
	return NULL;
}

size_t pktlab_xattrlist_encode (
	const struct pktlab_xattr * list, void * buf, size_t bufsz)
{
	const struct pktlab_xattr * attr;
	uint_fast16_t encodedlen;
	uint_fast16_t len = 0;
	
	if (buf == NULL)
		bufsz = 0;
	
	for (attr = list; attr != NULL; attr = attr->next) {
		encodedlen = 2 + attr->len;
		len += encodedlen;
		
		if (encodedlen < bufsz) {
			*(uint8_t*)(buf+0) = attr->type;
			*(uint8_t*)(buf+1) = attr->len;
			encode(attr, buf+2);
			buf += encodedlen;
			bufsz -= encodedlen;
		} else {
			buf += bufsz;
			bufsz = 0;
		}
	}
	
	return len;
}

void pktlab_xattrlist_free(struct pktlab_xattr * list) {
	struct pktlab_xattr * next;
	
	while (list != NULL) {
		next = list->next;
		free(list);
		list = next;
	}
}

struct pktlab_xattr * pktlab_xattrlist_find (
	struct pktlab_xattr * list, enum pktlab_xattr_type type)
{
	struct pktlab_xattr * elt;
	
	for (elt = list; elt != NULL && elt->type <= type; elt = elt->next)
		if (elt->type == type)
			return elt;
	
	return NULL;
}

struct pktlab_xattr * pktlab_xattrlist_insert (
	struct pktlab_xattr * list, struct pktlab_xattr * elt)
{
	struct pktlab_xattr * head = list;
	
	if (head == NULL || head->type > elt->type) {
		elt->next = head;
		return elt;
	}
	
	while (list->next != NULL && list->next->type <= elt->type)
		list = list->next;
	
	elt->next = list->next;
	list->next = elt;
	return head;
}

struct pktlab_xattr * pktlab_xattrlist_remove_first (
	struct pktlab_xattr * list)
{
	struct pktlab_xattr * next;
	
	if (list != NULL) {
		next = list->next;
		list->next = NULL;
		return next;
	} else
		return NULL;
}

uint_fast32_t pktlab_xattrlist_count(const struct pktlab_xattr * list) {
	const struct pktlab_xattr * elt;
	uint_fast32_t count = 0;
	
	for (elt = list; elt != NULL; elt = elt->next)
		count += 1;
	
	return count;
}

struct pktlab_xattr * pktlab_create_name_xattr (
	const char * name)
{
	struct pktlab_xattr * attr;
	char * nameptr;
	size_t len;
	
	len = strlen(name);
	RETURN_IF(len > 255, NULL);
	
	attr = safe_malloc(sizeof(struct pktlab_xattr) + len + 1);
	memset(attr, 0, sizeof(struct pktlab_xattr));
	attr->type = PKTLAB_NAME_XATTR;
	nameptr = (void*)(attr + 1);
	memcpy(nameptr, name, len);
	nameptr[len] = '\0';
	attr->name = nameptr;
	attr->len = len;
	return attr;
}

struct pktlab_xattr * pktlab_create_period_xattr (
	pktlab_time_t after, pktlab_time_t before)
{
	// ...
	return NULL;
}

struct pktlab_xattr * pktlab_create_server_host_xattr (
	const char * name)
{
	struct pktlab_xattr * attr;
	char * nameptr;
	size_t len;
	
	trace("pktlab_create_server_host_xattr(name:\"%s\")", name);
	
	len = strlen(name);
	RETURN_IF(len > 255, NULL);
	
	attr = safe_malloc(sizeof(struct pktlab_xattr) + len + 1);
	memset(attr, 0, sizeof(struct pktlab_xattr));
	attr->type = PKTLAB_SERVER_HOST_XATTR;
	nameptr = (void*)(attr + 1);
	memcpy(nameptr, name, len);
	nameptr[len] = '\0';
	attr->server_host = nameptr;
	attr->len = len;

	return attr;
}
struct pktlab_xattr * pktlab_create_server_port_xattr (
	uint_fast16_t port)
{
	struct pktlab_xattr * attr;
	
	attr = safe_calloc(1, sizeof(struct pktlab_xattr));
	attr->type = PKTLAB_SERVER_PORT_XATTR;
	attr->server_port = port;
	attr->len = 2;

	return attr;
}

// 
// INTERNAL FUNCTION DEFINITIONS
// 

struct pktlab_xattr * decode (
	uint_fast8_t type, uint_fast8_t len, const void * ptr)
{
	switch (type) {
	case PKTLAB_NAME_XATTR:
		return decode_name(type, len, ptr);
	case PKTLAB_SEQNO_XATTR:
		return decode_seqno(type, len, ptr);
	case PKTLAB_TIME_VALID_XATTR:
		return decode_time(type, len, ptr);
	case PKTLAB_SERVER_HOST_XATTR:
		return decode_server_host(type, len, ptr);
	case PKTLAB_SERVER_PORT_XATTR:
		return decode_server_port(type, len, ptr);
	case PKTLAB_FILTER_HASH_XATTR:
		return decode_filter_hash(type, len, ptr);
	default:
		return create_unknown(type, len);
	}
}

void encode(const struct pktlab_xattr * attr, void * buf) {
	switch (attr->type) {
	case PKTLAB_NAME_XATTR:
		encode_name(attr, buf);
		break;
	case PKTLAB_SEQNO_XATTR:
		encode_seqno(attr, buf); 
		break;
	case PKTLAB_TIME_VALID_XATTR:
		encode_time(attr, buf);
		break;
	case PKTLAB_SERVER_HOST_XATTR:
		encode_server_host(attr, buf);
		break;
	case PKTLAB_SERVER_PORT_XATTR:
		encode_server_port(attr, buf);
		break;
	case PKTLAB_FILTER_HASH_XATTR:
		encode_filter_hash(attr, buf);
		break;
	case PKTLAB_UNKNOWN_XATTR:
		encode_unknown(attr, buf);
		break;
	}
}

struct pktlab_xattr * create_unknown (
	uint_fast8_t type, uint_fast8_t len)
{
	struct pktlab_xattr * attr;
	
	attr = safe_calloc(1, sizeof(struct pktlab_xattr));
	attr->type = PKTLAB_UNKNOWN_XATTR;
	attr->len = 2;
	attr->raw.type = type;
	attr->raw.len = len;
	return attr;
}

// 
// INTERNAL DECODER FUNCTION DEFINITIONS
// 

struct pktlab_xattr * decode_name (
	uint_fast8_t type, uint_fast8_t len, const void * ptr)
{
	struct pktlab_xattr * attr;
	const char * str = ptr;
	char * nameptr;
	uint_fast16_t i;
	
	// Check name. Names should only contain ASCII characters between space
	// and '~' (0x7e) inclusive, excluding the backslash character.
	
	for (i = 0; i < len; i++) {
		RETURN_IF(str[i] == '\\', NULL);
		RETURN_IF(str[i] < ' '|| '\x7f' <= str[i], NULL);
	}	
	
	// Create and initialize attribute structure. We allocate exactly the
	// space we need to store the name string plus null terminator.

	attr = safe_malloc(sizeof(struct pktlab_xattr) + len + 1);
	memset(attr, 0, sizeof(struct pktlab_xattr));
	attr->type = PKTLAB_NAME_XATTR;
	nameptr = (void*)(attr + 1);
	memcpy(nameptr, str, len);
	nameptr[len] = '\0';
	attr->name = nameptr;
	attr->len = len;
	return attr;
}

struct pktlab_xattr * decode_seqno (
	uint_fast8_t type, uint_fast8_t len, const void * ptr)
{
	struct pktlab_xattr * attr;

	attr = safe_calloc(1, sizeof(struct pktlab_xattr));
	attr->type = PKTLAB_SEQNO_XATTR;
	attr->seqno = get32n(ptr);
	return attr;
}

struct pktlab_xattr * decode_time (
	uint_fast8_t type, uint_fast8_t len, const void * ptr)
{
	struct pktlab_xattr * attr;

	attr = safe_calloc(1, sizeof(struct pktlab_xattr));
	attr->type = PKTLAB_TIME_VALID_XATTR;
	attr->time_valid.start = get64n(ptr);
	attr->time_valid.end = get64n(ptr+8);
	return attr;
}

struct pktlab_xattr * decode_server_host (
	uint_fast8_t type, uint_fast8_t len, const void * ptr)
{
	struct pktlab_xattr * attr;
	const char * str = ptr;
	char * nameptr;
	uint_fast16_t i;
	
	// Check host name. Host names must contain only letters, digits, 
	// periods, colons and hyphens.
	
	for (i = 0; i < len; i++) {
		CONTINUE_IF('A' <= str[i] && str[i] <= 'Z');
		CONTINUE_IF('a' <= str[i] && str[i] <= 'z');
		CONTINUE_IF('0' <= str[i] && str[i] <= '9');
		CONTINUE_IF(str[i] == '.');
		CONTINUE_IF(str[i] == ':');
		CONTINUE_IF(str[i] == '-');
		return NULL;
	}
	
	// Create and initialize attribute structure. We allocate exactly the
	// space we need to store the name string plus null terminator.

	attr = safe_malloc(sizeof(struct pktlab_xattr) + len + 1);
	memset(attr, 0, sizeof(struct pktlab_xattr));
	attr->type = PKTLAB_SERVER_HOST_XATTR;
	nameptr = (void*)(attr + 1);
	memcpy(nameptr, str, len);
	nameptr[len] = '\0';
	attr->server_host = nameptr;
	attr->len = len;
	return attr;
}

struct pktlab_xattr * decode_server_port (
	uint_fast8_t type, uint_fast8_t len, const void * ptr)
{
	struct pktlab_xattr * attr;

	attr = safe_calloc(1, sizeof(struct pktlab_xattr));
	
	attr->type = PKTLAB_SERVER_PORT_XATTR;
	// Port is stored in network byte order!
	memcpy(&attr->server_port, ptr, 2);
	return attr;
}

struct pktlab_xattr * decode_filter_hash (
	uint_fast8_t type, uint_fast8_t len, const void * ptr)
{
	struct pktlab_xattr * attr;
	void * hashptr;
	
	// Create and initialize attribute structure. We allocate exactly the
	// space we need to store the hash value.

	attr = safe_malloc(sizeof(struct pktlab_xattr) + len);
	memset(attr, 0, sizeof(struct pktlab_xattr));
	attr->type = PKTLAB_FILTER_HASH_XATTR;
	hashptr = (void*)(attr + 1);
	memcpy(hashptr, ptr, len);
	attr->filter_hash.ptr = hashptr;
	attr->filter_hash.len = len;
	attr->len = len;
	return attr;
}

// 
// INTERNAL ENCODER FUNCTION DEFINITIONS
// 

void encode_unknown(const struct pktlab_xattr * attr, void * ptr) {
	set8(ptr+0, attr->raw.type);
	set8(ptr+1, attr->raw.len);
}

void encode_name(const struct pktlab_xattr * attr, void * ptr) {
	memcpy(ptr, attr->name, strlen(attr->name));
}

void encode_seqno(const struct pktlab_xattr * attr, void * ptr) {
	set32n(ptr, attr->seqno);
}

void encode_time(const struct pktlab_xattr * attr, void * ptr) {
	set64n(ptr, attr->time_valid.start);
	set64n(ptr+8, attr->time_valid.end);
}

void encode_server_host(const struct pktlab_xattr * attr, void * ptr) {
	memcpy(ptr, attr->server_host, attr->len);
}

void encode_server_port(const struct pktlab_xattr * attr, void * ptr) {
	// Port is always in network byte order
	memcpy(ptr, &attr->server_port, 2);
}

void encode_filter_hash(const struct pktlab_xattr * attr, void * ptr) {
	memcpy(ptr, attr->filter_hash.ptr, attr->len);
}
