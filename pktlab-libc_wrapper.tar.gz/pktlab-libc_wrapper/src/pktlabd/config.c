// config.c
//

#include "config.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "console.h"
#include "util.h"

#define BUF_SIZ 1024

//
// INTERNAL TYPE DEFINITIONS
//

enum me_init_keys {
    NETWORK_BUFMAX,
    VMEM_LADDR_STR_V4,
    VMEM_LADDR_STR_V6,
    VMEM_LDNSADDR_STR_V4,
    VMEM_LDNSADDR_STR_V6,
    HOST_ID,
    UKN
};

struct key_dict_entry{
    const char * const keyname;
    const enum me_init_keys key;
};

//
// INTERNAL GLOBAL VARIABLES
//

static const struct key_dict_entry _key_dict[] = {
    {"BufMax", NETWORK_BUFMAX},
    {"VMemLocalAddrStrIPv4", VMEM_LADDR_STR_V4},
    {"VMemLocalAddrStrIPv6", VMEM_LADDR_STR_V6},
    {"VMemLocalDNSAddrStrIPv4", VMEM_LDNSADDR_STR_V4},
    {"VMemLocalDNSAddrStrIPv6", VMEM_LDNSADDR_STR_V6},
    {"HostID", HOST_ID},
    {NULL, UKN}
};

//
// EXPORTED GLOBAL VARIABLES
//

struct config _config;

//
// INTERNAL FUNCTION DECLARATIONS
//

static enum me_init_keys check_dict(const char * keyname);
static bool read_config_line(char * line);

//
// EXPORTED FUNCTION DEFINITIONS
//

void config_initialize(void) {
    trace("%s()", __func__);

    memset(&_config, 0, sizeof(_config));
    _config.network_bufmax = -1;
}

bool config_read(const char * path) {
    FILE * fp;
    char buf[BUF_SIZ] = {};

    trace("%s(path:%s)", __func__, safe_str(path));


    if (path == NULL)
        return true;

    fp = fopen(path, "r");
    if (fp == NULL)
        return true;

    while (!feof(fp)) {
        if (fgets(buf, BUF_SIZ, fp) == NULL)
            break;
        if (read_config_line(buf)) {
            fclose(fp);
            return true;
        }
    }

    debug("config.BufMax:\t%lld", _config.network_bufmax);
    debug("config.VMemLocalAddrStrIPv4:\t%s", safe_str(_config.vmem_laddr_str_v4));
    debug("config.VMemLocalAddrStrIPv6:\t%s", safe_str(_config.vmem_laddr_str_v6));
    debug("config.VMemLocalDNSAddrStrIPv4:\t%s", safe_str(_config.vmem_ldnsaddr_str_v4));
    debug("config.VMemLocalDNSAddrStrIPv6:\t%s", safe_str(_config.vmem_ldnsaddr_str_v6));
    debug("config.HostID:\t%s", safe_str(_config.host_id));

    fclose(fp);
    return false;
}

//
// INTERNAL FUNCTION DEFINITIONS
//

enum me_init_keys check_dict(const char * keyname) {
    uint_fast32_t i;

    for (i = 0; _key_dict[i].keyname != NULL; ++i)
        if (strcmp(keyname, _key_dict[i].keyname) == 0)
            return _key_dict[i].key;

    return UKN;
}

bool read_config_line(char * line) {
    char * setting;
    char * option;
    enum me_init_keys key;
    size_t optlen;
    long long bufmax;
    char * buf;

    setting = strtok(line, " \t\n");
    if (setting == NULL || *setting == '#' || *setting == '\n')
        goto success;

    key = check_dict(setting);
    assert(
        key == NETWORK_BUFMAX ||
        key == VMEM_LADDR_STR_V4 ||
        key == VMEM_LADDR_STR_V6 ||
        key == VMEM_LDNSADDR_STR_V4 ||
        key == VMEM_LDNSADDR_STR_V6 ||
        key == HOST_ID ||
        key == UKN);

    option = strtok(NULL, " \t\n");
    if (option == NULL || (optlen = strlen(option)) == 0)
        goto fail;

    if (key == NETWORK_BUFMAX) {
        bufmax = strtoll(option, NULL, 10);
        if (bufmax > UINT32_MAX) {
            debug("%s: bufmax too large", __func__);
            goto fail;
        } else if (bufmax < 0) {
            debug("%s: bufmax negative", __func__);
            goto fail;
        }
        
        _config.network_bufmax = bufmax;
        goto success;
    }


    buf = safe_malloc(optlen+1);
    strncpy(buf, option, optlen+1);

    switch (key) {
    case UKN:
        goto fail;
    case VMEM_LADDR_STR_V4:
        _config.vmem_laddr_str_v4 = buf;
        break;
    case VMEM_LADDR_STR_V6:
        _config.vmem_laddr_str_v6 = buf;
        break;
    case VMEM_LDNSADDR_STR_V4:
        _config.vmem_ldnsaddr_str_v4 = buf;
        break;
    case VMEM_LDNSADDR_STR_V6:
        _config.vmem_ldnsaddr_str_v6 = buf;
        break;
    case HOST_ID:
        _config.host_id = buf;
        break;
    default:
        debug("%s: Unexpected key value %d", __func__, key);
    }

success:
    return false;
fail:
    return true;
}