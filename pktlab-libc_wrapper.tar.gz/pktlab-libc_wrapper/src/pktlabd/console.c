// console.c
//

#include "console.h"

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

// 
// EXPORTED FUNCTION DEFINITIONS
// 
void pktlabme_print_ (
	const char * filename, int lineno, const char * label, const char * fmt, ...)
{
	static char buf[256];
	va_list args;
	
	va_start(args, fmt);
	vsnprintf(buf, sizeof(buf), fmt, args);
	va_end(args);
	
	fprintf(stderr, "%s (%s:%d): %s\n", label, filename, lineno, buf);
}