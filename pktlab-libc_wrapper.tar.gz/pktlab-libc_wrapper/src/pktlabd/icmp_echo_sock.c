// icmp_echo_sock.c
//

#include "icmp_echo_sock.h"

#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include <fcntl.h>
#include <linux/errqueue.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netinet/icmp6.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>

#include <pktlab.h>

#include "console.h"
#include "network_util.h"

#define ICMP_HLEN 8

#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

#define ICMP_BUF_SIZ (ICMP_HLEN+ICMP_DATA_LEN_MAX)
#define RECV_BUF_SIZ 0x10000
#define CMSG_BUF_SIZ RECV_BUF_SIZ
#define ORG_DST_BUF_SIZ (sizeof(struct sockaddr_storage))

//
// INTERNAL TYPE DEFINITION
//

typedef size_t (*icmp_pkt_creator_t) (
    const void * idptr, const void * seqptr, 
    const void * data, size_t datalen, void * dst);

//
// INTERNAL GLOBAL VARIABLES
//

static uint8_t _default_ttl;

//
// INTERNAL FUNCTION DECLARATIONS
//

static size_t mkicmppkt (
    const void * idptr, const void * seqptr, 
    const void * data, size_t datalen, void * dst);

static size_t mkicmpv6pkt (
    const void * idptr, const void * seqptr, 
    const void * data, size_t datalen, void * dst);

static ssize_t icmp_sock_recv_msg(int fd, void * dst, size_t cnt);

static ssize_t icmp_sock_recv_err(int fd, void * dst, size_t cnt);

//
// EXPORTED FUNCTION DEFINITIONS
//

int icmp_echo_sock_open (
    uint_fast8_t netproto, void * locaddrptr)
{
    int sockfd;
    int pf;
    int proto;
    int icmp_proto;
    int recverr_opt;
    int recvttl_opt;
    int ttl_opt;
    int on;
    uint_fast8_t addrlen;
    socklen_t optlen;
    socklen_t sa_len;
    struct sockaddr_storage sa_mem = {};

    assert(netproto == PKTLAB_IP4_PROTO ||
        netproto == PKTLAB_IP6_PROTO);

    switch (netproto) {
    case PKTLAB_IP4_PROTO:
        pf = PF_INET;
        icmp_proto = IPPROTO_ICMP;
        addrlen = PKTLAB_IPV4_WO_MSK_ADDR_LEN;
        proto = IPPROTO_IP;
        recverr_opt = IP_RECVERR;
        recvttl_opt = IP_RECVTTL;
        ttl_opt = IP_TTL;
        break;
    case PKTLAB_IP6_PROTO:
        warn("IPv6 ICMPv6 echo socket not tested");
        pf = PF_INET6;
        icmp_proto = IPPROTO_ICMPV6;
        addrlen = PKTLAB_IPV6_ADDR_LEN;
        proto = IPPROTO_IPV6;
        recverr_opt = IPV6_RECVERR;
        recvttl_opt = IP_RECVTTL; // can't find equivalent for ipv6
        ttl_opt = IPV6_HOPLIMIT;
        break;
    default:
        debug("Unknown netproto 0x%X", netproto);
        break;
    }

    if ((sockfd = socket(pf, SOCK_DGRAM, icmp_proto)) == -1) {
        debug("socket(AF_INET%s,SOCK_DGRAM,IPPROTO_ICMP%s): %s",
            (pf == PF_INET) ? "" : "6",
            (icmp_proto == IPPROTO_ICMP) ? "" : "V6",
            strerror(errno));
        goto fail0;
    }

    on = 1;

    if (setsockopt(sockfd, proto, recverr_opt, &on, sizeof(int))) {
        debug("setsockopt(%d,IPPROTO_IP%s,IP%s_RECVERR,1): %s",
            sockfd,
            (proto == IPPROTO_IP) ? "" : "V6",
            (recverr_opt == IP_RECVERR) ? "" : "V6",
            strerror(errno));
        goto fail1;
    }

    if (setsockopt(sockfd, proto, recvttl_opt, &on, sizeof(int))) {
        debug("setsockopt(%d,IPPROTO_IP%s,IP_RECVTTL,1): %s",
            sockfd,
            (proto == IPPROTO_IP) ? "" : "V6",
            strerror(errno));
        goto fail1;
    }

    optlen = sizeof(_default_ttl);

    if (_default_ttl == 0 && getsockopt(sockfd, proto, ttl_opt, &_default_ttl, &optlen)) {
        debug("getsockopt(%d,IPPROTO_IP%s,%s): %s",
            sockfd,
            (proto == IPPROTO_IP) ? "" : "V6",
            (ttl_opt == IP_TTL) ? "IP_TTL" : "IPV6_HOPLIMIT",
            strerror(errno));
        goto fail1;
    }

    assert(_default_ttl != 0);

    sa_len = mksockaddr((void*)&sa_mem, 0, locaddrptr, addrlen);

    if (bind(sockfd, (void*)&sa_mem, sa_len)) {
        debug("bind(loc_addr): %s", strerror(errno));
        goto fail1;
    }

    fcntl(sockfd, F_SETFL, fcntl(sockfd, F_GETFL) | O_NONBLOCK);

    return sockfd;

fail1:
    close(sockfd);
fail0:
    return -1;
}

ssize_t icmp_echo_sock_send (
    int fd, uint_fast8_t netproto,
    uint_fast8_t ttl, uint_fast16_t seq,
    const void * addrptr, uint_fast8_t addrlen,
    const void * dataptr, uint_fast32_t datalen)
{
    struct sockaddr_in * sin;
    struct sockaddr_in6 * sin6;
    struct sockaddr_storage sa_mem = {};
    socklen_t socklen;
    icmp_pkt_creator_t icmp_creator;
    uint16_t id;
    uint8_t buf[ICMP_BUF_SIZ] = {};
    int proto;
    int ttl_opt;
    size_t sendlen;
    ssize_t rst;

    assert(netproto == PKTLAB_IP4_PROTO ||
        netproto == PKTLAB_IP6_PROTO);

    switch (netproto) {
    case PKTLAB_IP4_PROTO:
        assert(netproto == PKTLAB_IP4_PROTO &&
            addrlen == PKTLAB_IPV4_WO_MSK_ADDR_LEN);
        sin = (struct sockaddr_in *) &sa_mem;
        sin->sin_family = AF_INET;
        memcpy(&sin->sin_addr.s_addr, addrptr, addrlen);
        socklen = sizeof(struct sockaddr_in);
        icmp_creator = &mkicmppkt;
        proto = IPPROTO_IP;
        ttl_opt = IP_TTL;
        break;
    case PKTLAB_IP6_PROTO:
        assert(netproto == PKTLAB_IP6_PROTO &&
            addrlen == PKTLAB_IPV6_ADDR_LEN);
        sin6 = (struct sockaddr_in6 *) &sa_mem;
        sin6->sin6_family = AF_INET6;
        memcpy(&sin6->sin6_addr.s6_addr, addrptr, addrlen);
        socklen = sizeof(struct sockaddr_in6);
        icmp_creator = &mkicmpv6pkt;
        proto = IPPROTO_IPV6;
        ttl_opt = IPV6_HOPLIMIT;
        break;
    default:
        debug("Unknown netproto 0x%X", netproto);
        break;
    }

    id = 0;
    seq = pktlab_hton16(seq);

    sendlen = icmp_creator(&id, &seq, dataptr,
        MIN(datalen,ICMP_DATA_LEN_MAX), buf); // intentional limit icmp datalen

    if (ttl == 0) // ttl = 0 signals use of default TTL value
        ttl = _default_ttl;

    if (setsockopt(fd, proto, ttl_opt, &ttl, sizeof(uint8_t))) {
        debug("setsockopt(%d,IPPROTO_IP%s,%s,ttl: %u): %s",
            fd,
            (proto == IPPROTO_IP) ? "" : "V6",
            (ttl_opt == IP_TTL) ? "IP_TTL" : "IPV6_HOPLIMIT",
            ttl,
            strerror(errno));
        return -1;
    }

    rst = sendto(fd, buf, sendlen, 0, (struct sockaddr *) &sa_mem, socklen);
    if (rst != (ssize_t) sendlen) {
        debug("sendto(%d,length: %ld): sent %ld bytes; %s",
            fd, sendlen, rst, strerror(errno));
        errno = ECOMM; // ECOMM to signal send failure
        return -1;
    }

    return 0;
}

ssize_t icmp_echo_sock_recv (
    int fd, uint_fast8_t netproto,
    void * buf, size_t count)
{
    ssize_t ret;
    
    assert(netproto != PKTLAB_IP6_PROTO); // ipv6 not yet implemented

    if ((ret = icmp_sock_recv_err(fd, buf, count)) >= 0)
        goto done;

    if (errno != EAGAIN)
        goto done;

    if ((ret = icmp_sock_recv_msg(fd, buf, count)) >= 0)
        goto done;

done:
    return ret;
}

//
// INTERNAL FUNCTION DEFINITIONS
//

size_t mkicmppkt (
    const void * idptr, const void * seqptr, 
    const void * data, size_t datalen, void * dst)
{
    struct icmphdr * pkt;

    pkt = dst;
    pkt->type = ICMP_ECHO;
    pkt->code = 0;
    pkt->checksum = 0;
    memcpy(&pkt->un.echo.id, idptr, sizeof(uint16_t));
    memcpy(&pkt->un.echo.sequence, seqptr, sizeof(uint16_t));
    memcpy(pkt+1, data, datalen);

    return sizeof(struct icmphdr)+datalen;
}

size_t mkicmpv6pkt (
    const void * idptr, const void * seqptr, 
    const void * data, size_t datalen, void * dst)
{
    struct icmp6_hdr * pkt;

    pkt = dst;
    pkt->icmp6_type = ICMP6_ECHO_REQUEST;
    pkt->icmp6_code = 0;
    pkt->icmp6_cksum = 0;
    memcpy(&pkt->icmp6_id, idptr, sizeof(uint16_t));
    memcpy(&pkt->icmp6_seq, seqptr, sizeof(uint16_t));
    memcpy(pkt+1, data, datalen);

    return sizeof(struct icmp6_hdr)+datalen;
}

ssize_t icmp_sock_recv_msg(int fd, void * dst, size_t cnt){
    struct iovec iov;
    struct msghdr msg = {};
    uint8_t rbuf[RECV_BUF_SIZ] = {};
    uint8_t org_dstbuf[ORG_DST_BUF_SIZ] = {};
    uint8_t cbuf[CMSG_BUF_SIZ] = {};
    ssize_t recvcnt;
    struct cmsghdr * cmsg;
    bool ttl_flag;
    uint8_t ttl;
    int tmp_ttl;
    int af;
    size_t addrlen;
    void * src;
    uint8_t * ptr;
    size_t total_len;

    // ICMP socket ndata off len description
    // ---- --- -----------
    //    0   1 type (uint8_t)
    //    1   1 code (uint8_t)
    //    2   1 ttl of received msg (uint8_t)
    //    3   2 ID (uint16_t)
    //    5   2 seq (uint16_t)
    //    7   n src addr (0 < n)
    //  7+n   m data field in seq (0 <= m)

    iov.iov_base = rbuf;
    iov.iov_len = RECV_BUF_SIZ;
    msg.msg_name = org_dstbuf;
    msg.msg_namelen = ORG_DST_BUF_SIZ;
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    msg.msg_flags = 0;
    msg.msg_control = cbuf;
    msg.msg_controllen = CMSG_BUF_SIZ;

    if ((recvcnt = recvmsg(fd, &msg, 0)) < 0) {
        debug("recvmsg(%d,msg,0): %s",
            fd, strerror(errno));
        return -1;
    }

    assert(recvcnt >= ICMP_HLEN);


    ttl_flag = false;

    for (cmsg = CMSG_FIRSTHDR(&msg); cmsg; cmsg = CMSG_NXTHDR(&msg, cmsg)) {
        if (cmsg->cmsg_level == IPPROTO_IP) { // v6 yet to be implemented
            switch (cmsg->cmsg_type) {
            case IP_TTL:
                if (!ttl_flag) {
                    ttl_flag = true;
                    tmp_ttl = *((int *) CMSG_DATA(cmsg));
                    
                    assert(256 > tmp_ttl && tmp_ttl >= 0);
                    ttl = tmp_ttl;
                }
                break;
            default:
                debug("Unknown cmsg type: %d\n", cmsg->cmsg_type);
                break;
            }
        }
    }

    assert(ttl_flag);


    af = ((struct sockaddr *) msg.msg_name)->sa_family;
    assert(af == AF_INET || af == AF_INET6);

    switch (af) {
    case AF_INET:
        addrlen = PKTLAB_IPV4_WO_MSK_ADDR_LEN;
        src = &(((struct sockaddr_in *) msg.msg_name)->sin_addr);
        break;
    case AF_INET6:
        addrlen = PKTLAB_IPV6_ADDR_LEN;
        src = &(((struct sockaddr_in6 *) msg.msg_name)->sin6_addr);
        break;
    default:
        debug("Unknown address family 0x%X", af);
        break;
    }


    total_len = 7+addrlen+recvcnt-ICMP_HLEN;

    if (cnt < total_len) {
        debug("Buffer space too small. Expect %ld, only got %ld",
            total_len, cnt);
        errno = ENOMEM;
        return -1;
    }

    // ICMP echo reply format
    // |<-     1B    ->|<-     1B    ->|<-     1B    -><-     1B    ->|
    // +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
    // |     Type      |     Code      |          Checksum            |
    // +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
    // |           Identifier          |        Sequence Number       |
    // +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
    // | Data  ...
    // +-+-+-+-+-+-+- 

    ptr = dst;
    memcpy(ptr, rbuf, 2*sizeof(uint8_t));
    *(ptr+2) = ttl;
    memcpy(ptr+3, rbuf+4, sizeof(uint16_t));
    memcpy(ptr+5, rbuf+6, sizeof(uint16_t));
    memcpy(ptr+7, src, addrlen);
    memcpy(ptr+addrlen+7, rbuf+ICMP_HLEN, recvcnt-ICMP_HLEN);

    return total_len;
}

ssize_t icmp_sock_recv_err(int fd, void * dst, size_t cnt){
    struct iovec iov;
    struct msghdr msg = {};
    uint8_t rbuf[RECV_BUF_SIZ] = {};
    uint8_t org_dstbuf[ORG_DST_BUF_SIZ] = {};
    uint8_t cbuf[CMSG_BUF_SIZ] = {};
    ssize_t recvcnt;
    struct cmsghdr * cmsg;
    struct sock_extended_err * err;
    struct sockaddr * err_src;
    bool ttl_flag;
    bool err_flag;
    uint8_t type;
    uint8_t code;
    uint8_t ttl;
    int tmp_ttl;
    int af;
    int addrlen;
    void * org_dst_addr; // org dst as in the targeted host for the original echo req
    void * err_src_addr; // err src as in the host that sent back the ICMP error msg
    uint8_t * ptr;
    size_t total_len;

    // ICMP socket ndata off len description
    // ---- --- -----------
    //    0   1 type (uint8_t)
    //    1   1 code (uint8_t)
    //    2   1 ttl of received msg (uint8_t)
    //    3   n org dst addr (0 < n)
    //  n+3   n error msg src (0 < n)
    // 2n+3   8 error msg data (first 8 octets of org datagram) 

    iov.iov_base = rbuf;
    iov.iov_len = RECV_BUF_SIZ;
    msg.msg_name = org_dstbuf;
    msg.msg_namelen = ORG_DST_BUF_SIZ;
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    msg.msg_flags = 0;
    msg.msg_control = cbuf;
    msg.msg_controllen = CMSG_BUF_SIZ;

    if ((recvcnt = recvmsg(fd, &msg, MSG_ERRQUEUE)) < 0) {
        debug("recvmsg(%d,msg,MSG_ERRQUEUE): %s",
            fd, strerror(errno));
        return -1;
    }

    assert(recvcnt >= ICMP_HLEN); // router may return longer than icmp msg header


    ttl_flag = false;
    err_flag = false;

    for (cmsg = CMSG_FIRSTHDR(&msg); cmsg; cmsg = CMSG_NXTHDR(&msg, cmsg)) {
        if (cmsg->cmsg_level == IPPROTO_IP) { // v6 not yet done
            switch (cmsg->cmsg_type) {
            case IP_TTL:
                if (!ttl_flag) {
                    ttl_flag = true;
                    tmp_ttl = *((int *) CMSG_DATA(cmsg));

                    assert(256 > tmp_ttl && tmp_ttl >= 0);
                    ttl = tmp_ttl;
                }
                break;
            case IP_RECVERR:
                if (!err_flag) {
                    err = (struct sock_extended_err *) CMSG_DATA(cmsg);
                    if (err->ee_origin == SO_EE_ORIGIN_ICMP) {
                        err_flag = true;
                        type = err->ee_type;
                        code = err->ee_code;
                        err_src = SO_EE_OFFENDER(err);

                        assert(err_src->sa_family ==
                            ((struct sockaddr *) msg.msg_name)->sa_family);
                    }
                }
                break;
            default:
                debug("Unknown cmsg type: %d\n", cmsg->cmsg_type);
                break;
            }
        }
    }

    assert(err_flag && ttl_flag);


    af = err_src->sa_family;
    assert(af == AF_INET || af == AF_INET6);

    switch (af) {
    case AF_INET:
        addrlen = PKTLAB_IPV4_WO_MSK_ADDR_LEN;
        org_dst_addr = &(((struct sockaddr_in *) msg.msg_name)->sin_addr);
        err_src_addr = &(((struct sockaddr_in *) err_src)->sin_addr);
        break;
    case AF_INET6:
        addrlen = PKTLAB_IPV6_ADDR_LEN;
        org_dst_addr = &(((struct sockaddr_in6 *) msg.msg_name)->sin6_addr);
        err_src_addr = &(((struct sockaddr_in6 *) err_src)->sin6_addr);
        break;
    default:
        debug("Unknown address family 0x%X", af);
        break;
    }


    total_len = 2*addrlen+recvcnt+3;

    if (cnt < total_len) {
        debug("Buffer space too small. Expect %ld, only got %ld",
            total_len, cnt);
        errno = ENOMEM;
        return -1;
    }


    ptr = dst;
    *ptr = type;
    *(ptr+1) = code;
    *(ptr+2) = ttl;
    memcpy(ptr+3, org_dst_addr, addrlen);
    memcpy(ptr+3+addrlen, err_src_addr, addrlen);
    memcpy(ptr+3+2*addrlen, rbuf, recvcnt);

    return total_len;
}