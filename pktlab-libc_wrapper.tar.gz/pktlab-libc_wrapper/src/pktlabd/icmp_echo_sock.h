// icmp_echo_sock.h
// 

#ifndef _ICMP_ECHO_SOCK_H_
#define _ICMP_ECHO_SOCK_H_

#include <stddef.h>
#include <stdint.h>

#include <sys/types.h>

#define ICMP_DATA_LEN_MAX 16

// 
// EXPORTED FUNCTION DECLARATIONS
// 

extern int icmp_echo_sock_open (
    uint_fast8_t netproto, void * locaddrptr);


extern ssize_t icmp_echo_sock_send (
    int fd, uint_fast8_t netproto,
    uint_fast8_t ttl, uint_fast16_t seq,
    const void * addrptr, uint_fast8_t addrlen,
    const void * dataptr, uint_fast32_t datalen);

extern ssize_t icmp_echo_sock_recv (
    int fd, uint_fast8_t netproto,
    void * src, size_t count);

#endif
