// main.c (pktlabd)
// 

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

#include <sys/time.h>
#include <sys/select.h>
#include <sys/socket.h>

#include <arpa/inet.h>
#include <netdb.h>

#include <pktlab.h>

#include "control.h"
#include "network.h"
#include "memory.h"
#include "main.h"

#include "console.h"
#include "util.h"

#define USAGE "pktlabd [-w|-x] [-c CONF] [ADDR[,PORT]]"

// 
// TYPE DEFINITIONS
//

// ...

// 
// RUN-TIME PARAMETERS
// 

static const char * _confpath = NULL;
static const char * _ctrlspec = PKTLAB_DEFAULT_SPEC_STR;

// 
// GLOBAL VARIABLES
// 

pktlab_time_t _time_now;
enum role _role;


// 
// INTERNAL FUNCTION DECLARATIONS
// 

static void initialize(int argc, char * const argv[]);

#ifdef DEBUG
static char * strfdset(char * buf, size_t bufsz, const fd_set * fdset);
#endif

// 
// INTERNAL FUNCTION DEFINITIONS
// 

#if 0
int main(int argc, char * const argv[]) {	
	initialize(argc, argv);
	
	switch (_role) {
	case ROLE_MAIN:
		main_start();
		break;
	case ROLE_MANAGER:
		manager_start();
		break;
	case ROLE_WORKER:
		worker_start();
		break;
	}
	
	exit(EXIT_SUCCESS);
	return 0; // unreach
}
#endif		


int main(int argc, char * const argv[]) {	
#ifdef DEBUG
	char rstrbuf[40], wstrbuf[40];
#endif
	pktlab_time_t timeout;
	struct timeval timeout_timeval;
	fd_set rset, wset;
	int nfds, nsel;
	int result;

	initialize(argc, argv);
	
	network_start();
	control_start();
	
	fprintf(stderr, "argv[0] = \"%s\"\n", argv[0]);
	
	_time_now = pktlab_time_now();

	while (true) {
		timeout = _time_now + pktlab_time_sec(60);
		memset(&rset, 0, sizeof(rset));
		memset(&wset, 0, sizeof(wset));
		nfds = 0;
		
		result = control_prepare_select(&rset, &wset, &timeout);
		nfds = MAX(nfds, result);
		
		result = network_prepare_select(&rset, &wset, &timeout);
		nfds = MAX(nfds, result);
		
		pktlab_time_to_timeval(timeout - _time_now, &timeout_timeval);
				
		debug("Calling select(%d, %s, %s, %d sec) ...", nfds,
		strfdset(rstrbuf, sizeof(rstrbuf) ,&rset),
		strfdset(wstrbuf, sizeof(wstrbuf), &wset),
		(unsigned int) timeout_timeval.tv_sec);
	
		nsel = select(nfds, &rset, &wset, NULL, &timeout_timeval);
	
		_time_now = pktlab_time_now();

		debug("=> nsel:%d, rset:%s, wset:%s", nsel,
		strfdset(rstrbuf, sizeof(rstrbuf) ,&rset),
		strfdset(wstrbuf, sizeof(wstrbuf), &wset));

		nsel -= control_process_select(nsel, &rset, &wset);
		nsel -= network_process_select(nsel, &rset, &wset);
	}
	
	exit(EXIT_SUCCESS);
	return 0;
}

void initialize(int argc, char * const argv[]) {
	struct sigaction action;
	int c;
	
	while ((c = getopt(argc, argv, "mwc:")) != -1) {
		switch (c) {
		case 'm':
			if (_role != ROLE_MAIN || _role != ROLE_MANAGER)
				goto role_error;			
			_role = ROLE_MANAGER;
			break;
		case 'w':
			if (_role != ROLE_MAIN || _role != ROLE_WORKER)
				goto role_error;			
			_role = ROLE_WORKER;
			break;
		case 'c':
			_confpath = optarg;
			break;
		default:
			goto usage_error;
		}
	}
	
	argc -= optind;
	argv += optind;
	
	// Parse address and port arguments.
	
	if (argc > 0)
		_ctrlspec = argv[0];
	
	if (argc > 1)
		fprintf(stderr, "Arguments after \"%s\" ignored.\n", argv[1]);

	// Disable SIGPIPE signal; handle broken pipe error on write.
	
	memset(&action, 0, sizeof(action));
	action.sa_handler = SIG_IGN;
	sigaction(SIGPIPE, &action, NULL);
	
	// Initialize control and network.
	
	control_initialize(_ctrlspec);
	network_initialize();
	memory_initialize();
	return;
	
role_error:
	fprintf(stderr, "Only one of -m or -w may be given.\n");
	// fall through to usage error
	
usage_error:
	fprintf(stderr, "USAGE: " USAGE "\n");
	exit(EXIT_FAILURE);
	return;
}
