// network_util.c
//

#include "network_util.h"

#include <limits.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <pktlab.h>

#include "console.h"

//
// INTERNAL CONSTANTS
//

# define BUF_SIZ 1024

//
// INTERNAL FUNCTION DECLARATIONs
//

static int convert_subnet_num (
	int subnet_num, char * subnet_str, size_t len);
static int convert_subnet_str (
	const char * subnet_num_str,
	char * subnet_str, size_t len);

//
// EXPORTED FUNCTION DEFINITIONS
//

socklen_t mksockaddr (
	struct sockaddr * sa, uint_fast16_t port,
	const void * addrptr, uint_fast32_t addrlen)
{
	struct sockaddr_in * sin = (void*)sa;
	struct sockaddr_in6 * sin6 = (void*)sa;
	
	if (addrlen == 4) {
		memset(sin, 0, sizeof(struct sockaddr_in));
		sin->sin_family = AF_INET;
		sin->sin_port = port;
		if (addrptr != NULL)
			memcpy(&sin->sin_addr, addrptr, addrlen);
		else
			sin->sin_addr.s_addr = INADDR_ANY;
		return sizeof(struct sockaddr_in);
	} else if (addrlen == 16) {
		memset(sin6, 0, sizeof(struct sockaddr_in6));
		sin6->sin6_family = AF_INET6;
		sin6->sin6_port = port;
		if (addrptr != NULL)
			memcpy(&sin6->sin6_addr, addrptr, addrlen);
		else
			memcpy(&sin6->sin6_addr, &in6addr_any, addrlen);
		return sizeof(struct sockaddr_in6);
	} else
		return 0;
}

ssize_t netproto2len(uint8_t netproto) {
	ssize_t addrlen = -1;

	switch (netproto) {
	case PKTLAB_IP4_PROTO:
		addrlen = PKTLAB_IPV4_WO_MSK_ADDR_LEN;
		break;
	case PKTLAB_IP6_PROTO:
		addrlen = PKTLAB_IPV6_ADDR_LEN;
		break;
	default:
		break;
	}

	return addrlen;
}

int set_keepalive(int sktfd) {
	int optval;

	debug("fd(%d) set keepalive", sktfd);

	optval = 1;
	return setsockopt(sktfd, SOL_SOCKET, SO_KEEPALIVE,
		(void *) &optval, (socklen_t) sizeof(optval));
}

int parse_addr_n_store (
	uint8_t netproto, int hasmask,
	const char * restrict addrstr,
	void * dst, uint_fast32_t dstlen)
{
	// Parse text address from string and store them into designated area
	// hasmask
	//   0: No mask in addrstr
	//   1: Mask in addrstr (only for v4, expect to be in form X.X.X.X/X)

	int af;
	uint_fast32_t addrlen;
	char * subnet_slash = NULL;
	char addr[BUF_SIZ] = {}, maskstr[BUF_SIZ] = {};

	strncpy(addr, addrstr, BUF_SIZ-1);

	switch(netproto) {
	case PKTLAB_IP4_PROTO:
		af = AF_INET;
		addrlen = hasmask ?
			PKTLAB_IPV4_W_MSK_ADDR_LEN:
			PKTLAB_IPV4_WO_MSK_ADDR_LEN;
		if (hasmask) {
			if ((subnet_slash = strchr(addr, '/')) == NULL)
				return -1;
			*subnet_slash = '\0';
		}
		break;
	case PKTLAB_IP6_PROTO:
		af = AF_INET6;
		addrlen = PKTLAB_IPV6_ADDR_LEN;
		break;
	default:
		return -1;
	}

	if (addrlen > dstlen || inet_pton(af, addr, dst) != 1)
		return -1;

	if (hasmask == 0 || netproto == PKTLAB_IP6_PROTO)
		return 0;

	// IPv4 and hasmask set has to deal with subnet mask
	if (convert_subnet_str(subnet_slash+1, maskstr, BUF_SIZ) == -1)
		return -1;

	if (inet_pton(af, maskstr,
			(char *) dst+PKTLAB_IPV4_WO_MSK_ADDR_LEN) != 1)
		return -1;

	return 0;
}

//
// INTERNAL FUNCTION DEFINITIONS
//

int convert_subnet_num (
	int subnet_num, char * subnet_str, size_t len)
{
	int subnet_arr[4] = {};
	int arr_indx;
	size_t subnet_str_len = 4+3; // at least 4 '0', 3 '.'

	if (subnet_num < 0 || subnet_num > 32)
		return -1;

	for (arr_indx = 0; subnet_num >= 8; ++arr_indx) {
		subnet_arr[arr_indx] = 255;
		subnet_num -= 8;
		subnet_str_len += 2;
	}
	for (int i = 1; i <= subnet_num; ++i)
		subnet_arr[arr_indx] += 1 << (8-i);

	if (subnet_arr[arr_indx] >= 10)
		++subnet_str_len;
	if (subnet_arr[arr_indx] >= 100)
		++subnet_str_len;

	if (subnet_str_len+1 > len)
		return -1;

	if (sprintf(
			subnet_str, "%d.%d.%d.%d",
			subnet_arr[0], subnet_arr[1],
			subnet_arr[2], subnet_arr[3]) != subnet_str_len)
		return -1;

	return subnet_str_len;
}

int convert_subnet_str (
	const char * subnet_num_str,
	char * subnet_str, size_t len)
{
	long subnet_num = strtol(subnet_num_str, NULL, 0);
	if (subnet_num < INT_MIN || subnet_num > INT_MAX)
		return -1;

	return convert_subnet_num(subnet_num, subnet_str, len);
}