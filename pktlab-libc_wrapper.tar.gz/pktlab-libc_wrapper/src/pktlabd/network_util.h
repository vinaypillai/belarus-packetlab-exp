// network_util.h
// 

#ifndef _NETWORK_UTIL_H_
#define _NETWORK_UTIL_H_

#include <stdint.h>

#include <sys/types.h>
#include <sys/socket.h>

// 
// EXPORTED FUNCTION DECLARATIONS
// 

extern socklen_t mksockaddr (
	struct sockaddr * sa, uint_fast16_t port,
	const void * addrptr, uint_fast32_t addrlen);

extern ssize_t netproto2len(uint8_t netproto);

extern int set_keepalive(int sktfd);

// address string to binary format and store
extern int parse_addr_n_store (
	uint8_t netproto, int hasmask,
	const char * restrict addrstr,
	void * dst, uint_fast32_t dstlen);

#endif
