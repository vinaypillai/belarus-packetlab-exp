// nqueue.c
//

#include "nqueue.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "util.h"

void nqput(struct nqueue * q, void * elt) {
	struct nqnode * node = q->free;
	
	if (node != NULL) {
		q->free = node->next;
		node->next = NULL;
	} else
		node = safe_calloc(1, sizeof(struct nqnode));
	
	node->elt = elt;

	if (q->tail != NULL)
		q->tail->next = node;
	else
		q->head = node;
	q->tail = node;
}

size_t nqlen(const struct nqueue * q) {
	struct nqnode * node;
	size_t cnt = 0;
		
	for (node = q->head; node != NULL; node = node->next)
		cnt += 1;
	
	return cnt;
}

void nqvacuum(struct nqueue * q) {
	struct nqnode * node;
	
	while (q->free != NULL) {
		node = q->free;
		q->free = node->next;
		free(node);
	}
}

void nqfilter(struct nqueue * q,
	bool (*filt)(void * elt, uintptr_t aux), uintptr_t aux)
{
	struct nqnode ** nptr = &q->head;
	struct nqnode * node = q->head;
	
	while (node != NULL) {
		if (filt(node->elt, aux)) {
			nptr = &node->next;
			node = node->next;
		} else {
			*nptr = node->next;
			node->next = q->free;
			q->free = node;
			node = *nptr;
		}
	}
}
