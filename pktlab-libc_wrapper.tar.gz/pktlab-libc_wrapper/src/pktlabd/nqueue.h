// nqueue.h
// 

#ifndef _NQUEUE_H_
#define _NQUEUE_H_

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

// 
// EXPORTED TYPE DEFINITION
// 

struct nqnode {
	struct nqnode * next;
	void * elt;
};

struct nqueue {
	struct nqnode * head;
	struct nqnode * tail;
	struct nqnode * free;
};

// 
// EXPORTED FUNCTION DECLARATION
// 

static inline void nqinit(struct nqueue * q);
static inline bool nqempty(const struct nqueue * q);
static inline void * nqpeek(const struct nqueue * q);
static inline void * nqget(struct nqueue * q);
static inline void nqdrop(struct nqueue * q);
extern void nqput(struct nqueue * q, void * elt);
extern size_t nqlen(const struct nqueue * q);
extern void nqvacuum(struct nqueue * q);

extern void nqfilter(struct nqueue * q,
	bool (*filt)(void * elt, uintptr_t aux), uintptr_t aux);

// 
// INLINE FUNCTION DEFINITION
// 

static inline void nqinit(struct nqueue * q) {
	memset(q, 0, sizeof(struct nqueue));
}

static inline bool nqempty(const struct nqueue * q) {
	return (q->head == NULL);
}

static inline void * nqpeek(const struct nqueue * q) {
	return (q->head != NULL) ? q->head->elt : NULL;
}

static inline void * nqget(struct nqueue * q) {
	struct nqnode * const node = q->head;
	void * elt = NULL;
	
	if (node != NULL) {
		elt = node->elt;
		q->head = node->next;
		if (q->head == NULL)
			q->tail = NULL;
		node->next = q->free;
		q->free = node;
	}
	
	return elt;
}

static inline void nqdrop(struct nqueue * q) {
	nqget(q);
}
	
#endif
