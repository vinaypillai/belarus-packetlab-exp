// raw.h
// General raw socket module interface
//

#ifndef _RAW_H_
#define _RAW_H_

#include <sys/types.h>

//
// EXPORTED ERROR DEFINITIONS
//

enum raw_error  {
    RAW_SUCCESS         = 0,
    RAW_INVAL           = 1,
    RAW_PERM            = 2,
    RAW_TRYAGAIN        = 3,
    RAW_BADPKT          = 4,
    RAW_BADFILT         = 5,
    RAW_AFNOSUPPORT     = 6,
    RAW_NORES           = 7,
    RAW_UNKFAULT        = 127
};

//
// EXPORTED FUNCTION DECLARATIONS
//

// All functions return -1 for error notification, actual error stored in "err" var.
// If function call successful, err should be set to RAW_SUCCESS.
//

// Initialize raw socket module, must be called before raw_start
// Return:
//      0 for success
// Error:
//      RAW_UNKFAULT for unknown error (need stop and reinit)
extern int raw_init(enum raw_error *err);

// Start raw socket module, called after raw_init
// Parameters:
//      af: raw socket address family
//      fds[0]: recvfd
//      fds[1]: sendfd
// Return:
//      0 for success
// Error:
//      RAW_INVAL for bad address family
//      RAW_AFNOSUPPORT for system not supporting the specified address family
//          (need stop and reinit)
//      RAW_PERM for not having the permission to open raw sockets (need stop and reinit)
//      RAW_NORES for not enough system resources to start module (need stop and reinit)
//      RAW_UNKFAULT for unknown error (need stop and reinit)
extern int raw_start(int af, int fds[2], enum raw_error *err);

// Raw socket send traffic
// Parameters:
//      buf: packet content
//      len: packet length in bytes
//      flags: flags for sendto function call
// Return:
//      >= 0 sent bytes when successful
// Error:
//      RAW_TRYAGAIN for non-blocking send not possible or interrupted
//      RAW_BADPKT for bad packets (rejected by system)
//      RAW_INVAL for invalid argument including flags
//      RAW_NORES for machine resources not available (need stop and reinit)
//      RAW_UNKFAULT for unknown error (need stop and reinit)
extern ssize_t raw_send(const void * buf, size_t len, int flags, enum raw_error *err);

// Raw socket recv traffic
// Parameters:
//      buf: buffer for packet content
//      len: buffer length in bytes
//      flags: flags for recvfrom function call
// Return:
//      >= 0 received bytes when successful
// Error:
//      RAW_TRYAGAIN for non-blocking recv not possible or interrupted
//      RAW_INVAL for invalid argument including flags
//      RAW_NORES for machine resources not available (need stop and reinit)
//      RAW_UNKFAULT for unknown error (need stop and reinit)
extern ssize_t raw_recv(void * buf, size_t len, int flags, enum raw_error *err);

// Stop raw socket module
// Return:
//      0 for success
// Error:
//      RAW_UNKFAULT for unknown error (need stop and reinit)
extern int raw_stop(enum raw_error *err);

// Set raw recv filter, set all drop filter if filter is NULL
// Parameters:
//      filter: pointer to bpf filter code
//      len: bpf filter byte length
// Return:
//      0 for success
// Error:
//      RAW_BADFILT for bad supplied bpf filter
//      RAW_UNKFAULT for unknown error (need stop and reinit)
extern int raw_setfilter(void * filter, size_t len, enum raw_error *err);

// Raw error to string utiliy
extern const char * raw_strerror(enum raw_error err);

#endif