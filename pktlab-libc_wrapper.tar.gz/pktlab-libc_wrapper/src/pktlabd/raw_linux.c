// raw_linux.c
// pktlab raw socket module linux platform impl.
//

//
// POSIX-compatible include headers
//

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include "console.h"
#include "pktlab.h"
#include "raw.h"

//
// Linux dependent headers
//

#include <ifaddrs.h>
#include <linux/if_packet.h>
#include <linux/filter.h>
#include <net/ethernet.h>
#include <net/if.h>
#include <netinet/in.h>
#include <sys/ioctl.h>

//
// INTERNAL MACRO DEFINITION
//

#define IP4_ALEN PKTLAB_IPV4_WO_MSK_ADDR_LEN
#define IP6_ALEN PKTLAB_IPV6_ADDR_LEN
#define MAX_PKTSZ 0x10000

#define SET_ST_RET(state, errval, retval) \
    do { _state = (state); *err = (errval); return (retval); } while (0)
#define try_again(en) ((en) == EAGAIN || (en) == EWOULDBLOCK)

//
// INTERNAL TYPE DEFINITIONS
//

enum raw_state {
    ST_RAWPREINIT,
    ST_RAWINIT,
    ST_RAWIDLE,
    ST_RAWERROR,
    ST_RAWUNKNOWN
};

//
// INTERNAL GLOBAL VARIABLES
//

static int _rawaf;
static int _recvsock;
static int _sendsock;

static enum raw_state _state;


//
// INTERNAL FUNCTION DECLARATIONS
//

/*
static int iptomac (
    const void * ip, size_t iplen,
    const void * mac, size_t maclen);

static char * find_intfname (
    const void * ip, size_t iplen,
    char * ifnamebuf, size_t buflen);
static int find_intfindx(int sockfd, const void * intfname);

static int bind_intf(int sockfd, int intfindx);
*/

static int safe_socket (
    int af, int type, int protocol,
    enum raw_error *err);
static int safe_close(int sockfd);
static int setblocking(int sockfd, int val);
static int clean_recvbuf(int sockfd, enum raw_error *err);

const char * state_name(enum raw_state state);

//
// EXPORTED FUNCTION DEFINITIONS
//

int raw_init(enum raw_error *err) {
    trace("raw:%s()", __func__);

    assert(_state < ST_RAWIDLE);

    _rawaf = -1;
    _recvsock = -1;
    _sendsock = -1;

    SET_ST_RET(ST_RAWINIT, RAW_SUCCESS, 0);
}

int raw_start(int af, int fds[2], enum raw_error *err) {
    enum raw_error reterr;

    trace("raw:%s(af:%d)", __func__, af);

    assert(_state == ST_RAWINIT);

    if (af != AF_INET && af != AF_INET6)
        SET_ST_RET(_state, RAW_INVAL, -1);

    _rawaf = af;

    // recv fd, for receiving traffic with a layer 2 dgram socket
    // SOCK_DGRAM for auto link layer header remove
    // ETH_P_ALL for capturing all traffic
    _recvsock = fds[0] = safe_socket(AF_PACKET, SOCK_DGRAM, htons(ETH_P_ALL), &reterr);
    if (_recvsock < 0)
        SET_ST_RET(ST_RAWERROR, reterr, -1);

    // send fd, for traffic sending with a layer 3 raw socket
    _sendsock = fds[1] = safe_socket(af, SOCK_RAW, IPPROTO_RAW, &reterr); // v6 not tested
    if (_sendsock < 0)
        SET_ST_RET(ST_RAWERROR, reterr, -1);

    _state = ST_RAWIDLE;

    // default filter out all packets on _recvsock
    if (raw_setfilter(NULL, 0, err))
        return -1;

    SET_ST_RET(_state, RAW_SUCCESS, 0);
}

ssize_t raw_send(const void * buf, size_t len, int flags, enum raw_error *err) {
    const uint8_t * ptr = buf;
    struct sockaddr_in sin = {};
    struct sockaddr_in6 sin6 = {};
    struct sockaddr * saddr;
    socklen_t socklen;
    ssize_t ret;
    enum raw_state state = _state;
    enum raw_error reterr = RAW_SUCCESS;

    trace("raw:%s(len:%zu,flags:%d)",
        __func__, len, flags);

    assert(_state == ST_RAWIDLE);

    switch (_rawaf) {
    case AF_INET:
        sin.sin_family = _rawaf;
        memcpy(&sin.sin_addr.s_addr, ptr+16, IP4_ALEN);
        saddr = (struct sockaddr *) &sin;
        socklen = sizeof(sin);
        break;
    case AF_INET6:
        sin6.sin6_family = _rawaf;
        memcpy(&sin6.sin6_addr.s6_addr, ptr+8, IP6_ALEN);
        saddr = (struct sockaddr *) &sin6;
        socklen = sizeof(sin6);
        break;
    default:
        SET_ST_RET(ST_RAWERROR, RAW_UNKFAULT, -1);
    }

    ret = sendto(_sendsock, buf, len, flags, saddr, socklen);
    if (ret < 0) {
        if (try_again(errno)) {
            reterr = RAW_TRYAGAIN;
        } else {
            switch(errno) {
            case EACCES:
            case EINVAL:
            case EMSGSIZE:
                reterr = RAW_BADPKT;
                break;
            case EINTR:
                reterr = RAW_TRYAGAIN;
                break;
            case EFAULT:
            case EOPNOTSUPP:
                reterr = RAW_INVAL;
                break;
            case ENOBUFS:
            case ENOMEM:
                state = ST_RAWERROR;
                reterr = RAW_NORES;
                break;
            default:
                state = ST_RAWERROR;
                reterr = RAW_UNKFAULT;
            }
        }
    }

    SET_ST_RET(state, reterr, ret);
}

ssize_t raw_recv(void * buf, size_t len, int flags, enum raw_error *err) {
    struct sockaddr_ll sll;
    socklen_t socklen;
    ssize_t ret;
    enum raw_state state = _state;
    enum raw_error reterr = RAW_SUCCESS;

    trace("raw:%s(len:%zu,flags:%d)",
        __func__, len, flags);

    assert(_state == ST_RAWIDLE);

    ret = recvfrom(_recvsock, buf, len, flags,
        (struct sockaddr *) &sll, &socklen);
    if (ret < 0) {
        if (try_again(errno)) {
            reterr = RAW_TRYAGAIN;
        } else {
            switch(errno) {
            case EINTR:
                reterr = RAW_TRYAGAIN;
                break;
            case EFAULT:
            case EINVAL:
                reterr = RAW_INVAL;
                break;
            case ENOMEM:
                state = ST_RAWERROR;
                reterr = RAW_NORES;
                break;
            default:
                state = ST_RAWERROR;
                reterr = RAW_UNKFAULT;
            }
        }
    }

    SET_ST_RET(state, reterr, ret);
}

int raw_stop(enum raw_error *err) {
    enum raw_error reterr = RAW_SUCCESS;
    int ret = 0;

    trace("raw:%s()", __func__);

    if (safe_close(_recvsock) < 0 && errno == EBADF) {
        reterr = RAW_UNKFAULT;
        ret = -1;
    }

    if (safe_close(_sendsock) < 0 && errno == EBADF) {
        reterr = RAW_UNKFAULT;
        ret = -1;
    }

    SET_ST_RET(ST_RAWPREINIT, reterr, ret);
}


int raw_setfilter(void * filter, size_t len, enum raw_error *err) {
    struct sock_fprog filtprog;
    int rst;

    trace("raw:%s(filterlen:%zu)", __func__, len);

    assert(_state == ST_RAWIDLE);

    if (clean_recvbuf(_recvsock, err) < 0)
        SET_ST_RET(ST_RAWERROR, *err, -1);

    if (filter != NULL) {
        if (len % 8 != 0)
            SET_ST_RET(_state, RAW_BADFILT, -1);

        filtprog.filter = filter;
        filtprog.len = len / 8;

        rst = setsockopt(_recvsock, SOL_SOCKET,
            SO_ATTACH_FILTER, &filtprog, sizeof(filtprog));
        if (rst < 0) {
            if (errno == EINVAL)
                SET_ST_RET(_state, RAW_BADFILT, -1);
            SET_ST_RET(ST_RAWERROR, RAW_UNKFAULT, -1);
        }
    }

    SET_ST_RET(_state, RAW_SUCCESS, 0);
}

const char * raw_strerror(enum raw_error err) {
    static const char * const errmsgs[] = {
        [RAW_SUCCESS] = "Operation successful",
        [RAW_INVAL] = "Bad function arguments",
        [RAW_PERM] = "No permission for this operation",
        [RAW_TRYAGAIN] = "Temporarily cannot perform operation",
        [RAW_BADPKT] = "Bad packet supplied",
        [RAW_BADFILT] = "Bad filter supplied",
        [RAW_AFNOSUPPORT] = "Address family not supported",
        [RAW_NORES] = "System out of resources",
        [RAW_UNKFAULT] = "Unknown error"
    };

    const char * errmsg = NULL;
    switch(err) {
    case RAW_SUCCESS:
    case RAW_INVAL:
    case RAW_PERM:
    case RAW_TRYAGAIN:
    case RAW_BADPKT:
    case RAW_BADFILT:
    case RAW_AFNOSUPPORT:
    case RAW_NORES:
        errmsg = errmsgs[err];
        break;
    default:
        errmsg = errmsgs[RAW_UNKFAULT];
    }

    return errmsg;
}

//
// INTERNAL FUNCTION DEFINITIONS
//

/*
// Find intfname with ip address
char * find_intfname (
    const void * ip, size_t iplen,
    char * ifnamebuf, size_t buflen)
{
    struct ifaddrs * ifap, * ptr;
    struct sockaddr_in * sin;
    struct sockaddr_in6 * sin6;
    void * intfip;
    char * ret = NULL;

    if (getifaddrs(&ifap))
        goto end;

    for (ptr = ifap; ptr; ptr = ptr->ifa_next) {
        switch (ptr->ifa_addr->sa_family) {
            case AF_INET:
                sin = (struct sockaddr_in *) ptr->ifa_addr;
                intfip = sin->sin_addr.s_addr;
                if (iplen != PKTLAB_IPV4_WO_MSK_ADDR_LEN)
                    continue;
                break;
            case AF_INET6: // IPv6 part untested
                sin6 = (struct sockaddr_in6 *) ptr->ifa_addr;
                intfip = sin6->sin6_addr.s6_addr;
                if (iplen != PKTLAB_IPV6_ADDR_LEN)
                    continue;
                break;
            default: // ignore if not AF_INET or AF_INET6
                continue;
        }

        if (memcmp(intfip, ip, iplen) != 0)
            continue;

        // found intf, store intf name if possible
        if (strlen(ptr->ifa_name)+1 <= buflen) {
            strcpy(ifnamebuf, ptr->ifa_name);
            ret = ifnamebuf;
        }

        break;
    }

    debug("%s(iplen:%zu): ret %s",
        __func__, iplen, (ret) ? ret : "NULL");

    freeifaddrs(ifap);
end:
    return ret;
}

// Find intfindx with intfname
int find_intfindx(int sockfd, const void * intfname) {
    struct ifreq ifr = {};

    strncpy(ifr.ifr_name, intfname, IFNAMSIZ-1);
    if (ioctl(sockfd, SIOCGIFINDEX, &ifr) == -1)
        return -1;

    return ifr.ifr_ifindex;
}

// Bind layer 2 socket to intf
int bind_intf(int sockfd, int intfindx) {
    struct sockaddr_ll sll = {
        .sll_family=AF_PACKET,
        .sll_protocol=htons(ETH_P_ALL),
        .sll_ifindex=intfindx
    };

    return bind(sockfd, (struct sockaddr *) &sll, sizeof(sll));
}
*/

int safe_socket (
    int af, int type, int protocol,
    enum raw_error *err)
{
    int sockfd;
    enum raw_error reterr = RAW_SUCCESS;

    sockfd = socket(af, type, protocol);
    if (sockfd < 0) {
        switch(errno) {
        case EAFNOSUPPORT:  /* af not supported */
            reterr = RAW_AFNOSUPPORT;
            break;
        case EPERM:         /* permission errors */
        case EACCES:
            reterr = RAW_PERM;
            break;
        case EMFILE:        /* resource errors */
        case ENFILE:
        case ENOBUFS:
        case ENOMEM:
            reterr = RAW_NORES;
            break;
        default:            /* all others should not happen  */
            reterr = RAW_UNKFAULT;
        }

        *err = reterr;
        return -1;
    }

    if (setblocking(sockfd, 0) < 0) {
        close(sockfd);
        reterr = RAW_UNKFAULT;
        sockfd = -1;
    }

    *err = reterr;
    return sockfd;
}

int safe_close(int sockfd) {
    if (sockfd >= 0)
        return close(sockfd);
    return 0;
}

int setblocking(int sockfd, int val) {
    int flags;

    debug("%s(fd:%d)", __func__, sockfd);

    flags = fcntl(sockfd, F_GETFL);
    if (flags < 0)
        return -1;

    flags = (val) ? (flags & ~O_NONBLOCK) : (flags | O_NONBLOCK);
    return fcntl(sockfd, F_SETFL, flags);
}

// libpcap style cleaning socket recv buf content
int clean_recvbuf(int sockfd, enum raw_error *err) {
    struct sock_filter ret0instr = BPF_STMT(BPF_RET | BPF_K, 0);
    struct sock_fprog ret0prog = { 1, &ret0instr};
    uint8_t buf[MAX_PKTSZ];
    ssize_t rst;
    enum raw_error reterr;

    if (setsockopt(
            sockfd, SOL_SOCKET, SO_ATTACH_FILTER,
            (void *) &ret0prog, (socklen_t) sizeof(ret0prog)) < 0) {
        *err = RAW_UNKFAULT;
        return -1;
    }

    while (1) {
        rst = raw_recv(buf, sizeof(buf), 0, &reterr);
        if (rst >= 0 || errno == EINTR) // ugly hack
            continue;

        if (reterr == RAW_TRYAGAIN)
            break; // cleanup done

        *err = RAW_UNKFAULT; // treating nores also as unknown
        return -1;
    }

    *err = RAW_SUCCESS;
    return 0;
}

const char * state_name(enum raw_state state) {
	static const char * const names[] = {
		[ST_RAWPREINIT] = "RAWPREINIT",
		[ST_RAWINIT] = "RAWINIT",
		[ST_RAWIDLE] = "RAWIDLE",
        [ST_RAWERROR] = "RAWERROR",
        [ST_RAWUNKNOWN] = "RAWUNKNOWN"
	};

	const char * name = NULL;

	if (state < sizeof(names) / sizeof(names[0]))
		name = names[state];

	return (name != NULL) ? name : names[ST_RAWUNKNOWN];
}