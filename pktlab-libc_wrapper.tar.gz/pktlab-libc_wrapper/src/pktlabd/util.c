// util.c
//

#include "util.h"

#include <stdarg.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

// 
// EXPORTED FUNCTION DEFINITIONS
// 

void * pktlabme_safe_malloc_(size_t size) {
	void * ptr;
	
	ptr = malloc(size);
	
	if (ptr == NULL) {
		perror(NULL);
		exit(EXIT_FAILURE);
		return NULL;
	} else
		return ptr;
}

void * pktlabme_safe_calloc_(size_t nelts, size_t eltsz) {
	void * ptr;
	
	ptr = calloc(nelts, eltsz);
	
	if (ptr == NULL) {
		perror(NULL);
		exit(EXIT_FAILURE);
		return NULL;
	} else
		return ptr;
}

void * pktlabme_safe_realloc_(void * ptr, size_t size) {
	
	ptr = realloc(ptr, size);
	
	if (ptr == NULL && size > 0) {
		perror(NULL);
		exit(EXIT_FAILURE);
		return NULL;
	} else
		return ptr;
}