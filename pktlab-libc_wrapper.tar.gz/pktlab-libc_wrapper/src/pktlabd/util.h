// util.h
// 

#ifndef _UTIL_H_
#define _UTIL_H_

#include <stddef.h>

#include <pktlab.h>

// 
// EXPORTED MACRO DEFINITIONS
// 

#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

// 
// EXPORTED FUNCTION DECLARATIONS
//

#define perror_exit_if(cond,error_msg) if (cond) perror(error_msg)

extern void * pktlabme_safe_malloc_(size_t size);
extern void * pktlabme_safe_calloc_(size_t nelts, size_t eltsz);
extern void * pktlabme_safe_realloc_(void * ptr, size_t size);

//
// SHORTER NAME MACROS
//

#define safe_malloc pktlabme_safe_malloc_
#define safe_calloc pktlabme_safe_calloc_
#define safe_realloc pktlabme_safe_realloc_
#define safe_strdup pktlabme_safe_strdup_

#endif
