// vmem.c
//

#include "vmem.h"

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"
#include "control.h"
#include "network.h"
#include "vmem_local_addr.h"
#include "vmem_local_dns_addr.h"

#include "console.h"
#include "util.h"

//
// INTERNAL CONSTANTS
// 

#define DEFAULT_ADDR_CONF_PATH "/etc/pktlabme/laddr.conf"
#define DEFAULT_RESOLV_CONF_PATH "/etc/resolv.conf"
#define DEFAULT_HOSTID_STR "pktlabme"

#define HOSTID_LEN 256
// #define SCRATCH_MEM_SIZE 0x10000000

//
// INTERNAL GLOBAL VARIABLE
//

static char _hostID[HOSTID_LEN];
// static char _scratch_mem[SCRATCH_MEM_SIZE];

// 
// ENDPOINT VIRTUAL MEMORY ACCESS DECLARATIONS
// 

static void time_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf);

static void hostID_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf);

/* TODO scratch memory part
static void scratch_mem_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf);

static void scratch_mem_write (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, const void * restrict src);
*/

// 
// MEMORY MAP (INTERNAL USE)
// 

static struct pktlab_vmem_region _rgns[] = {
	// Current pkt data and info
	// TODO

	// System parameters
	{ 0x10000000, 0x10000002, &vmem_laddr_cnt_read },
	{ 0x10000100, 0x10000900, &vmem_laddr_v4_read },
	{ 0x10001000, 0x10002000, &vmem_laddr_v6_read },
	{ 0x10002000, 0x10002008, &time_read },
	{ 0x10002010, 0x10002014, &network_bufmax_read },
	{ 0x10002014, 0x10002018, &network_bufused_read },
	{ 0x10002020, 0x10002022, &vmem_ldnsaddr_cnt_read },
	{ 0x10002030, 0x10002100, &vmem_ldnsaddr_v4_read },
	{ 0x10002100, 0x10002200, &vmem_ldnsaddr_v6_read },
	{ 0x10002200, 0x10002300, &hostID_read },
	// omitting longitude & latitude, and OS name ver. & kernel ver.

	// Socket info
	{ 0x20000000, 0x20040000, &network_skt_read, &network_skt_write },

	// tidx
	{ 0x30000000, 0x30080000, &network_tstp_read }

	// Monitor scratch memory
	// TODO { 0x40000000, 0x50000000, &scratch_mem_read, &scratch_mem_write },

	// Monitor persistent storage
	// TODO { 0x50000000, 0x60000000, &persist_store_read, &persist_store_write }
};

static const uint32_t _rgncnt =
	sizeof(_rgns) / sizeof(struct pktlab_vmem_region);

// 
// INTERNAL FUNCTION DECLARATION
// 

typedef void (*addr_extractor_t) (uint8_t indx, void * buf);

// 
// EXPORTED FUNCTION DEFINITIONS
// 

void vmem_initialize(void) {

	vmem_laddr_initialize_str (
		_config.vmem_laddr_str_v4,
		_config.vmem_laddr_str_v6);

	vmem_ldnsaddr_initialize_str (
		_config.vmem_ldnsaddr_str_v4,
		_config.vmem_ldnsaddr_str_v6);

	if (_config.host_id != NULL) {
		strncpy(_hostID, _config.host_id, HOSTID_LEN-1);
		_hostID[HOSTID_LEN-1] = '\0';
	}
	info("Exporting host ID: %s", _hostID);

	// memset(_scratch_mem, 0, SCRATCH_MEM_SIZE);
}

void vmem_handle_mread(struct pktlab_message * msg) {
	struct pktlab_message * outmsg;
	uint_fast32_t addr, len;
	void * bufptr;
	
	addr = msg->mread.addr;
	len = msg->mread.len;

	trace ("vmem_handle_mread(msg:{addr:%u,len:%u})",
		(unsigned int) addr, (unsigned int) len);
	
	// Free received message.
	
	free(msg);
	
	// Check fixed length limits.
	
	if (len == 0 || PKTLAB_MREAD_MAX < len)
		goto invalid_request;
	
	// Make sure addr+len does not exceed than 2^32. What we'd like to do is
	// fail if (msg->mem_read.len + msg->mem_read.addr > 2^32). We can avoid
	// 64-bit arithmetic this way (so long as len > 0):

	if (addr > (uint32_t)-len)
		goto invalid_request;
	
	outmsg = safe_malloc(sizeof(struct pktlab_message) + len);
	memset(outmsg, 0, sizeof(struct pktlab_message) + len);
	bufptr = outmsg + 1; // points to end of struct
	
	debug("malloc'd %zu bytes for %u-byte response",
		sizeof(struct pktlab_message) + len, (unsigned int) len);
	
	outmsg->type = PKTLAB_MDATA_MESSAGE;
	outmsg->mdata.addr = addr;
	outmsg->mdata.len = len;
	outmsg->mdata.ptr = bufptr;
	
	pktlab_vmem_read(_rgns, _rgncnt, addr, len, bufptr);
	control_send(outmsg);
	return;

invalid_request:
	outmsg = pktlab_create_status_message(PKTLAB_BADMSG, NULL);
	control_send(outmsg);
	return;
}

void vmem_handle_mwrite(struct pktlab_message * msg) {
	struct pktlab_message * outmsg;
	uint_fast32_t addr, len;
	const void * ptr;
	
	addr = msg->mdata.addr;
	len = msg->mdata.len;
	ptr = msg->mdata.ptr;

	trace ("vmem_handle_mwrite(msg:{addr:%u,len:%u})",
		(unsigned int) addr, (unsigned int) len);
	
	// Make sure addr+len does not exceed than 2^32. What we'd like to do is
	// fail if (msg->mem_read.len + msg->mem_read.addr > 2^32). We can avoid
	// 64-bit arithmetic this way (so long as len > 0):

	if (len == 0 || addr <= (uint32_t)-len) {
		pktlab_vmem_write(_rgns, _rgncnt, addr, len, ptr);
		outmsg = pktlab_create_status_message(PKTLAB_SUCCESS, NULL);
	} else
		outmsg = pktlab_create_status_message(PKTLAB_BADMSG, NULL);
	
	control_send(outmsg);
	free(msg);
}

bool vmem_indx_get_laddr (
    uint8_t netproto, uint8_t indx, void * buf)
{
	addr_extractor_t extractor;
	uint8_t addr_cnt;

	switch (netproto) {
		case PKTLAB_IP4_PROTO:
			extractor = &vmem_util_laddr_v4_read;
			break;
		case PKTLAB_IP6_PROTO:
			extractor = &vmem_util_laddr_v6_read;
			break;
		default:
			warn("Unknown netproto value %u", netproto);
			return true;
	}
	
	addr_cnt = vmem_util_laddr_cnt_read(netproto);

	if (indx >= addr_cnt)
		return true;

	extractor(indx, buf);

	return false;
}

bool vmem_indx_get_ldnsaddr (
    uint8_t netproto, uint8_t indx, void * buf)
{
	addr_extractor_t extractor;
	uint8_t addr_cnt;

	switch (netproto) {
		case PKTLAB_IP4_PROTO:
			extractor = &vmem_util_ldnsaddr_v4_read;
			break;
		case PKTLAB_IP6_PROTO:
			extractor = &vmem_util_ldnsaddr_v6_read;
			break;
		default:
			warn("Unknown netproto value %u", netproto);
			return true;
	}
	
	addr_cnt = vmem_util_ldnsaddr_cnt_read(netproto);

	if (indx >= addr_cnt)
		return true;

	extractor(indx, buf);

	return false;
}

// 
//  MEMORY READER/WRITER DEFINITIONS
// 

void time_read (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	uint64_t time_now;
	
	time_now = pktlab_hton64(pktlab_time_now());
	memcpy(buf, (void *) &time_now + off, len);
}

void hostID_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	memcpy(buf, _hostID + off, len);
}

/*
void scratch_mem_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	memcpy(buf, _scratch_mem + off, len);
}

void scratch_mem_write (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, const void * restrict src)
{
	memcpy(_scratch_mem + off, src, len);
}
*/