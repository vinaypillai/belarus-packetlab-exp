// vmem_local_addr.c
//

#include <assert.h>
#include <errno.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>

#include <pktlab.h>

#include "console.h"
#include "network_util.h"
#include "vmem_local_addr.h"

//
// INTERNAL CONSTANTS
//

#define ADDR_CNT 256

#define BUF_SIZ 0x4000

// 
// INTERNAL TYPE DEFINITIONS
// 

struct local_addr {
    uint8_t v4cnt;
    uint8_t v6cnt;
    uint8_t v4addrls[ADDR_CNT][PKTLAB_IPV4_W_MSK_ADDR_LEN];
    uint8_t v6addrls[ADDR_CNT][PKTLAB_IPV6_ADDR_LEN];
};

//
// INTERNAL GLOBAL VARIABLE
//

static struct local_addr _loc_addr_ls;

//
// INTERNAL FUNCTION DECLARATION
//

static bool read_config(const char * config_path, struct local_addr * store);

//
// EXPORTED FUNCTION DEFINITION
//

void vmem_laddr_initialize_str (
    const char * restrict v4_addr_str,
    const char * restrict v6_addr_str)
{
    char v4_addrs[BUF_SIZ] = {};
    char v6_addrs[BUF_SIZ] = {};
    char * ptr;

    trace("%s(v4addr:%s,v6addr:%s)", __func__,
        safe_str(v4_addr_str), safe_str(v6_addr_str));

    if (v4_addr_str != NULL) {
        strncpy(v4_addrs, v4_addr_str, BUF_SIZ-1);
        ptr = strtok(v4_addrs, ",");
        while (ptr != NULL) {
            if (parse_addr_n_store (
                    PKTLAB_IP4_PROTO, 1, ptr,
                    _loc_addr_ls.v4addrls[_loc_addr_ls.v4cnt],
                    PKTLAB_IPV4_W_MSK_ADDR_LEN) == 0) {
                info("Exporting entry %" PRIu8 " IPv4 laddr: %s",
                    _loc_addr_ls.v4cnt, ptr);
                ++_loc_addr_ls.v4cnt;
            } else
                warn("Cannot understand IPv4 laddr: %s, omitting", ptr);
            ptr = strtok(NULL, ",");
        }
    }

    if (v6_addr_str != NULL) {
        strncpy(v6_addrs, v6_addr_str, BUF_SIZ-1);
        ptr = strtok(v6_addrs, ",");
        while (ptr != NULL) {
            if (parse_addr_n_store (
                    PKTLAB_IP6_PROTO, 0, ptr,
                    _loc_addr_ls.v6addrls[_loc_addr_ls.v6cnt],
                    PKTLAB_IPV6_ADDR_LEN) == 0) {
                info("Exporting entry %" PRIu8 " IPv6 laddr: %s",
                    _loc_addr_ls.v6cnt, ptr);
                ++_loc_addr_ls.v6cnt;
            } else
                warn("Cannot understand IPv6 laddr: %s, omitting", ptr);
            ptr = strtok(NULL, ",");
        }
    }
}

void vmem_laddr_initialize_conf(const char * restrict config_path) {

    trace("%s(config_path:%s)", __func__, safe_str(config_path));
    warn("Setting up endpoint virtual memory local address via local address config only.");

    memset(&_loc_addr_ls, 0, sizeof(struct local_addr));
    if (config_path == NULL) {
        fatal("No local address config file provided.");
    } else if (read_config(config_path, &_loc_addr_ls)) {
        fatal("Read local address config file failed.");
    }

    debug("%s:{v4cnt:%u; v6cnt:%u}",
		__func__, _loc_addr_ls.v4cnt, _loc_addr_ls.v6cnt);
}

void vmem_laddr_cnt_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf)
{
    char * ptr = buf;
    
    if (len == 0)
        return;

    if (off == 0x0) {
        *ptr = _loc_addr_ls.v4cnt;
        off += 1;
        len -= 1;
        ptr += sizeof(uint8_t);
    
        if (len == 0)
            return;
    }

    if (off == 0x1) {
        *ptr = _loc_addr_ls.v6cnt;
        off += 1;
        len -= 1;
        ptr += sizeof(uint8_t);
    
        if (len == 0)
            return;
    }
}

void vmem_laddr_v4_read (
    const struct pktlab_vmem_region * rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf)
{
    memcpy(buf, (char *) _loc_addr_ls.v4addrls + off, len);
}

void vmem_laddr_v6_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf)
{
    memcpy(buf, (char *) _loc_addr_ls.v6addrls + off, len);
}

uint8_t vmem_util_laddr_cnt_read(uint8_t net_proto) {
    assert(net_proto == PKTLAB_IP4_PROTO || net_proto == PKTLAB_IP6_PROTO);
    return (net_proto == PKTLAB_IP4_PROTO) ? _loc_addr_ls.v4cnt : _loc_addr_ls.v6cnt;
}

void vmem_util_laddr_v4_read(uint8_t indx, void * buf) {
    assert(indx < _loc_addr_ls.v4cnt);
    assert(buf != NULL);
    memcpy(buf, _loc_addr_ls.v4addrls[indx], PKTLAB_IPV4_W_MSK_ADDR_LEN);
}

void vmem_util_laddr_v6_read(uint8_t indx, void * buf) {
    assert(indx < _loc_addr_ls.v6cnt);
    assert(buf != NULL);
    memcpy(buf, _loc_addr_ls.v6addrls[indx], PKTLAB_IPV6_ADDR_LEN);
}

//
// INTERNAL FUNCTION DEFINITION
//

bool read_config(const char * config_path, struct local_addr * store) {
    // config file lists one non-duplicate newline terminated IP address (v4 or v6) per line, 
    // in the order of decreasing preference (the first address is preferred the most ... etc.)
    // e.g.
    //  192.168.0.1
    //  2001:4860:4860::8888
    //  172.16.0.1
    //  ...

    FILE * fp;
    char line[BUF_SIZ], * ptr;
    int af;
    void * dst;
    uint8_t * cnt;

    fp = fopen(config_path, "r");
    if (fp == NULL)
        return true;

    while (!feof(fp)) {
        if (fgets(line, BUF_SIZ, fp) == NULL)
            break;
        
        ptr = strtok(line, " \t\n");

        if (ptr != NULL) {
            if (!strchr(ptr, ':')) {
                af = AF_INET;
                dst = store->v4addrls[store->v4cnt];
                cnt = &(store->v4cnt);
            } else {
                af = AF_INET6;
                dst = store->v6addrls[store->v6cnt];
                cnt = &(store->v6cnt);
            }

            if (inet_pton(af, ptr, dst))
                *cnt += 1;
        }
    }

    fclose(fp);
    return false;
}
