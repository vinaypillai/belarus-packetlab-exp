// vmem_local_addr.c
//

#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <arpa/inet.h>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>

#include <pktlab.h>

#include "console.h"
#include "vmem_local_addr.h"

//
// INTERNAL CONSTANTS
//

#define ADDR_CNT 256

#define BUF_SIZ 4096

// 
// INTERNAL TYPE DEFINITIONS
// 

struct local_addr {
    uint8_t v4cnt;
    uint8_t v6cnt;
    uint8_t v4addrls[ADDR_CNT][PKTLAB_IPV4_W_MSK_ADDR_LEN];
    uint8_t v6addrls[ADDR_CNT][PKTLAB_IPV6_ADDR_LEN];
};

//
// INTERNAL GLOBAL VARIABLE
//

static struct local_addr _loc_addr_ls;

//
// INTERNAL FUNCTION DECLARATION
//

static bool get_local_addr_ifaddrs(struct local_addr * store);
static bool read_config(const char * config_path, struct local_addr * store);
static void match_addr (
    struct local_addr * local, struct local_addr * config, 
    struct local_addr * rst);

//
// EXPORTED FUNCTION DEFINITION
//

void vmem_laddr_initialize(const char * restrict config_path) {
    struct local_addr config, local;
    bool get_rst, config_rst;

    debug("vmem_laddr_initialize(config_path:%s)", 
		(config_path == NULL) ? "NULL" : config_path);

    // if can get address from interface and address config file => cross check (match)
    // if only can get address from interface => directly use interface addresses
    // fail otherwise
    memset(&_loc_addr_ls, 0, sizeof(struct local_addr));
    if (config_path == NULL) {
        get_local_addr_ifaddrs(&_loc_addr_ls);
    } else {
        get_rst = get_local_addr_ifaddrs(&local);
        config_rst = read_config(config_path, &config);
        if (!get_rst && !config_rst) {
            match_addr(&local, &config, &_loc_addr_ls);
        } else if (!get_rst) {
            warn("Read local address config failed.");
            memcpy(&_loc_addr_ls, &local, sizeof(struct local_addr));
        } else {
            fatal("Read local address failed.");
        }
    }

    debug("vmem_laddr_initialize:{v4cnt:%u; v6cnt:%u}", 
		_loc_addr_ls.v4cnt, _loc_addr_ls.v6cnt);
}

// directly read local ip addresses from file. does not cross check
void vmem_laddr_initialize_conf(const char * restrict config_path) {

    debug("vmem_laddr_initialize_conf(config_path:%s)", 
		(config_path == NULL) ? "NULL" : config_path);
    warn("Setting up endpoint virtual memory local address via local address config only.");

    memset(&_loc_addr_ls, 0, sizeof(struct local_addr));
    if (config_path == NULL) {
        fatal("No local address config file provided.");
    } else if (read_config(config_path, &_loc_addr_ls)) {
        fatal("Read local address config file failed.");
    }

    debug("vmem_laddr_initialize_conf:{v4cnt:%u; v6cnt:%u}", 
		_loc_addr_ls.v4cnt, _loc_addr_ls.v6cnt);
}

void vmem_laddr_cnt_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf)
{
    char * ptr = buf;
    
    if (len == 0)
        return;

    if (off == 0x0) {
        *ptr = _loc_addr_ls.v4cnt;
        off += 1;
        len -= 1;
        ptr += sizeof(uint8_t);
    
        if (len == 0)
            return;
    }

    if (off == 0x1) {
        *ptr = _loc_addr_ls.v6cnt;
        off += 1;
        len -= 1;
        ptr += sizeof(uint8_t);
    
        if (len == 0)
            return;
    }
}

void vmem_laddr_v4_read (
    const struct pktlab_vmem_region * rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf)
{
    memcpy(buf, (char *) _loc_addr_ls.v4addrls + off, len);
}

void vmem_laddr_v6_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf)
{
    memcpy(buf, (char *) _loc_addr_ls.v6addrls + off, len);
}

uint8_t vmem_util_laddr_cnt_read(uint8_t net_proto) {
    assert(net_proto == PKTLAB_IP4_PROTO || net_proto == PKTLAB_IP6_PROTO);
    return (net_proto == PKTLAB_IP4_PROTO) ? _loc_addr_ls.v4cnt : _loc_addr_ls.v6cnt;
}

void vmem_util_laddr_v4_read(uint8_t indx, void * buf) {
    assert(indx < _loc_addr_ls.v4cnt);
    assert(buf != NULL);
    memcpy(buf, _loc_addr_ls.v4addrls[indx], PKTLAB_IPV4_W_MSK_ADDR_LEN);
}

void vmem_util_laddr_v6_read(uint8_t indx, void * buf) {
    assert(indx < _loc_addr_ls.v6cnt);
    assert(buf != NULL);
    memcpy(buf, _loc_addr_ls.v6addrls[indx], PKTLAB_IPV6_ADDR_LEN);
}

//
// INTERNAL FUNCTION DEFINITION
//

bool get_local_addr_ifaddrs(struct local_addr * store) {
    struct ifaddrs * ifap;
    struct sockaddr_in * sin;
    struct sockaddr_in6 * sin6;
    char * addr_storage;

    if (getifaddrs(&ifap)) {
        warn("%s", strerror(errno));
        return true;
    }

    for (struct ifaddrs * ptr = ifap; ptr != NULL; ptr = ptr->ifa_next) {

        switch (ptr->ifa_addr->sa_family) {
            case AF_INET:
                if (store->v4cnt >= ADDR_CNT)
                    break;

                addr_storage = (char *) (store->v4addrls)[store->v4cnt];

                sin = (struct sockaddr_in *) ptr->ifa_addr;
                memcpy(addr_storage, &(sin->sin_addr), PKTLAB_IPV4_WO_MSK_ADDR_LEN);

                sin = (struct sockaddr_in *) ptr->ifa_netmask;
                memcpy(addr_storage + PKTLAB_IPV4_WO_MSK_ADDR_LEN,
                    &(sin->sin_addr), PKTLAB_IPV4_WO_MSK_ADDR_LEN);
                
                store->v4cnt += 1;
                
                break;
            case AF_INET6:
                debug("IPv6 part untested");

                if (store->v6cnt >= ADDR_CNT)
                    break;

                addr_storage = (char *) store->v6addrls[store->v6cnt];

                sin6 = (struct sockaddr_in6 *) ptr->ifa_addr;
                memcpy(addr_storage, &(sin6->sin6_addr), PKTLAB_IPV6_ADDR_LEN);
                    
                store->v6cnt += 1;
                                
                break;
            default:
                // ignore if not AF_INET or AF_INET6
                break;
        }
    }

    freeifaddrs(ifap);
    return false;
}

bool read_config(const char * config_path, struct local_addr * store) {
    // config file lists one non-duplicate newline terminated IP address (v4 or v6) per line, 
    // in the order of decreasing preference (the first address is preferred the most ... etc.)
    // e.g.
    //  192.168.0.1
    //  2001:4860:4860::8888
    //  172.16.0.1
    //  ...

    FILE * fp;
    char line[BUF_SIZ], * ptr;
    int af;
    void * dst;
    uint8_t * cnt;

    fp = fopen(config_path, "r");
    if (fp == NULL)
        return true;

    while (!feof(fp)) {
        if (fgets(line, BUF_SIZ, fp) == NULL)
            break;
        
        ptr = strtok(line, " \t\n");

        if (ptr != NULL) {
            if (!strchr(ptr, ':')) {
                af = AF_INET;
                dst = store->v4addrls[store->v4cnt];
                cnt = &(store->v4cnt);
            } else {
                af = AF_INET6;
                dst = store->v6addrls[store->v6cnt];
                cnt = &(store->v6cnt);
            }

            if (inet_pton(af, ptr, dst))
                *cnt += 1;
        }
    }

    fclose(fp);
    return false;
}

void match_addr (
    struct local_addr * local, struct local_addr * config, 
    struct local_addr * rst)
{
    unsigned int c_indx, l_indx;

    for (c_indx = 0; c_indx < config->v4cnt; ++c_indx) {
        for (l_indx = 0; l_indx < local->v4cnt; ++l_indx) {
            if (memcmp(local->v4addrls[l_indx], 
                    config->v4addrls[c_indx], 
                    PKTLAB_IPV4_WO_MSK_ADDR_LEN) == 0) {
                memcpy(rst->v4addrls[rst->v4cnt], local->v4addrls[l_indx], 
                    PKTLAB_IPV4_W_MSK_ADDR_LEN);
                rst->v4cnt += 1;
                break;
            }
        }
    }

    for (c_indx = 0; c_indx < config->v6cnt; ++c_indx) {
        for (l_indx = 0; l_indx < local->v6cnt; ++l_indx) {
            if (memcmp(local->v6addrls[l_indx], 
                    config->v6addrls[c_indx], 
                    PKTLAB_IPV6_ADDR_LEN) == 0) {
                memcpy(rst->v6addrls[rst->v6cnt], local->v6addrls[l_indx], 
                    PKTLAB_IPV6_ADDR_LEN);
                rst->v6cnt += 1;
                break;
            }
        }
    }

    return;
}