// vmem_local_addr.h
// 

#ifndef _VMEM_LOCAL_ADDR_H_
#define _VMEM_LOCAL_ADDR_H_

#include <pktlab.h>

// 
// EXPORTED FUNCTION DECLARATIONS
// 

extern void vmem_laddr_initialize(const char * restrict config_path);
extern void vmem_laddr_initialize_conf(const char * restrict config_path);

// Memory request handlers.

extern void vmem_laddr_cnt_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf);

extern void vmem_laddr_v4_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf);

extern void vmem_laddr_v6_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf);

// vmem access utilities

extern uint8_t vmem_util_laddr_cnt_read(uint8_t net_proto);
extern void vmem_util_laddr_v4_read(uint8_t indx, void * buf);
extern void vmem_util_laddr_v6_read(uint8_t indx, void * buf);

#endif

