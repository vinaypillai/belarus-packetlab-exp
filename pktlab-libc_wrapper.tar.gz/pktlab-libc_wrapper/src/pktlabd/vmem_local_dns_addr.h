// vmem_local_dns_addr.h
// 

#ifndef _VMEM_LOCAL_DNS_ADDR_H_
#define _VMEM_LOCAL_DNS_ADDR_H_

#include <stdint.h>

#include <pktlab.h>

// 
// EXPORTED FUNCTION DECLARATIONS
// 

extern void vmem_ldnsaddr_initialize_str (
    const char * restrict v4_dnsaddr_str,
    const char * restrict v6_dnsaddr_str);

extern void vmem_ldnsaddr_initialize_resolv_conf (
    const char * restrict resolv_path);

// Memory request handlers.

extern void vmem_ldnsaddr_cnt_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf);

extern void vmem_ldnsaddr_v4_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf);

extern void vmem_ldnsaddr_v6_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf);

// vmem access utilities

extern uint8_t vmem_util_ldnsaddr_cnt_read(uint8_t net_proto);
extern void vmem_util_ldnsaddr_v4_read(uint8_t indx, void * buf);
extern void vmem_util_ldnsaddr_v6_read(uint8_t indx, void * buf);

#endif

