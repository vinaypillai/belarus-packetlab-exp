// worker.c
// 

#include "worker.h"

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/select.h>

#include "vmem.h"
#include "network.h"
#include "control.h"
#include "console.h"
#include "util.h"

// 
// EXPORTED GLOBAL VARIABLES
// 

pktlab_time_t _time_now;

// 
// INTERNAL FUNCTION DECLARATIONS
// 

#if DEBUG
static char * strfdset(char * buf, size_t bufsz, const fd_set * fdset);
static char * rfdsetstr(const fd_set * fdset);
static char * wfdsetstr(const fd_set * fdset);
#endif

void worker_initialize(void) {
	trace("%s()", __func__);

	vmem_initialize();
	network_initialize();
	control_initialize();
}

void worker_main(int mgrfd, const char * spec) {
	pktlab_time_t timeout;
	struct timeval timeout_timeval;
	fd_set rset, wset;
	int nfds, nsel;
	int result;
	
	trace("%s(mgrfd:%d,spec:\"%s\")", __func__, mgrfd, spec);

	_time_now = pktlab_time_now();

	network_start();
	control_start(spec, 0);
	
	while (true) {
		timeout = _time_now + pktlab_time_sec(60);
		memset(&rset, 0, sizeof(rset));
		memset(&wset, 0, sizeof(wset));
		nfds = 0;

		result = control_prepare_select(&rset, &wset, &timeout);
		nfds = MAX(nfds, result);
		
		result = network_prepare_select(&rset, &wset, &timeout);
		nfds = MAX(nfds, result);
		
		pktlab_time_to_timeval(
			(timeout>_time_now)?(timeout-_time_now):0,
			&timeout_timeval);
				
		debug("Calling select(%d, %s, %s, %u sec) ...",
			nfds, rfdsetstr(&rset), wfdsetstr(&wset),
			(unsigned int) timeout_timeval.tv_sec);

		nsel = select(nfds, &rset, &wset, NULL, &timeout_timeval);
	
		_time_now = pktlab_time_now();

		debug("=> nsel:%d, rset:%s, wset:%s",
			nsel, rfdsetstr(&rset), wfdsetstr(&wset));

		nsel -= control_process_select(nsel, &rset, &wset);
		if (!control_running())
			break;

		nsel -= network_process_select(nsel, &rset, &wset);
	}
	
	exit(EXIT_SUCCESS);
	return;
}

// 
// INTERNAL FUNCTION DEFINITIONS
// 

#ifdef DEBUG

char * strfdset(char * buf, size_t bufsz, const fd_set * fdset) {
	char * start = buf;
	size_t full_len = 0;
	int result;
	int i;
	
	for (i = 0; i < FD_SETSIZE; i++) {
		if (!FD_ISSET(i, fdset))
			continue;
		result = snprintf(buf, bufsz, ",%d", i);
		full_len += result;
		buf += result;
		bufsz -= result;			
	}
	
	*start = '{';
	if (full_len == 0) {
		full_len += 1;
		buf += 1;
		bufsz -= 1;	
	}
	
	*buf = '}';
	full_len += 1;
	buf += 1;
	bufsz -= 1;	

	*buf = '\0';
	buf += 1;
	bufsz -= 1;
	
	
	return start;
}

char * rfdsetstr(const fd_set * fdset) {
	static char buf[64];
	return strfdset(buf, sizeof(buf), fdset);
}

char * wfdsetstr(const fd_set * fdset) {
	static char buf[64];
	return strfdset(buf, sizeof(buf), fdset);
}

#endif
