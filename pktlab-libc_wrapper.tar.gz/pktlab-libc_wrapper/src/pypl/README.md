# PyPL documentation
> Version 0.0.1-pre_alpha
> Last updated: 2019/12/25, by TB Yan

## Introduction
The ```pypl``` module is a wrapper for the ```libpktlab``` library to ease the use for the library. In current version, only parts related to the operation of experiment controllers (EC) are implemented.

## APIs
### Messages Related
#### encode_nopen_msg
```
encode_nopen_msg(sktid, proto, rbufsize, remoteaddr="", localport=0, remoteport=0)
```
Encode pktlab _nopen_ message based on provided parameters; returns encoded message in ```bytes```. _nopen_ message for requesting measurement endpoint (ME) to open a socket.

##### Required fields
```sktid```: ```int```, available target socket ID on ME, must be in \[0, 256). 
```proto```: ```int```, socket type, value constructed using 1) IP protocol version and 2) Transport layer type via bitwise-OR. Availble IP protocol: ```PKTLAB_IP4_PROTO```, ```PKTLAB_IP6_PROTO```; available transport layer type: ```PKTLAB_RAW_PROTO``` (for raw socket operations), ```PKTLAB_TCP_PROTO```, ```PKTLAB_UDP_PROTO```.
```rbufsize```: ```int```, socket receive buffer size, must be in \[0, 4294967296)

##### Optional fields
> Optional fields are only optional when ```PKTLAB_RAW_PROTO``` is used in ```proto```.

```remoteaddr```: ```str```, IP address for remote target to which ME will send pkts to, must be a valid IP address (e.g. "8.8.8.8").
```localport```: ```int```, local port which the ME will try to use for this socket, must be in \[0, 65536).
```remoteport```: ```int```, remote port which the ME will try to connect/send to for this socket, must be in \[1, 65536).

#### encode_nsend_msg
```
encode_nsend_msg(sktid, tidx, time, data)
```
Encode pktlab _nsend_ message based on provided parameters; returns encoded message in ```bytes```. _nsend_ message for requesting ME to send data using an opened socket.

##### Required fields
```sktid```: ```int```, target socket ID on ME, must be in \[0, 256). 
```tidx```: ```int```, location in tidx array to store the actual send time of sending operation corresponding to the _nsend_ request, must be \[0, 65536).
```time```: ```int```, scheduled sending time for this _nsend_ request, time precision in nanosecond based on ME local clock, must be in range \[0, 18446744073709551616). Specify 0 for immediate sending by ME.
```data```: ```bytes```, target sending data, must have length no larger than 16777204.

#### encode_nclose_msg
```
encode_nclose_msg(sktid)
```
Encode pktlab _nclose_ message based on provided parameters; returns encoded message in ```bytes```. _nclose_ message for requesting ME to close an opened socket.

##### Required fields
```sktid```: ```int```, target socket ID on ME, must be in \[0, 256).

#### decode_msg
```
decode_msg(msg)
```
Decode pktlab message based on provided bytes; returns decoded message as a dictionary containg fields such as "type", "memaddr", "data" ... etc (check protocol for detail about fields). Currently only the decoding of _status_, _mdata_, _ndata_ and _ndrop_ messages are implemented.

##### Required fields
```msg```: ```bytes```, target pktlab message.

### Utilities
#### pktlab_time_sec
```
pktlab_time_sec(real_world_sec)
```
Convert real word time in seconds to pktlab time unit (in nanosecond).

##### Required fields
```real_world_sec```: ```int```, target real word time, must be in \[0, 18446744074).

#### pktlab_time_to_unix_time
```
pktlab_time_to_unix_time(pktlab_time_unit)
```
Convert pktlab time unit (in nanosecond) to real word time in seconds.

##### Required fields
```pktlab_time_unit```: ```int```, target pktlab time unit, must be in \[0, 18446744073709551616).

## List of constants
### MISC
```
    PKTLAB_TICKS_PER_SECOND
    PKTLAB_MREAD_MAX
```

### Message type
```
    PKTLAB_UNDEF_MESSAGE

    PKTLAB_STATUS_MESSAGE

    PKTLAB_MREAD_MESSAGE
    PKTLAB_MWRITE_MESSAGE
    PKTLAB_MDATA_MESSAGE
    
    PKTLAB_NOPEN_MESSAGE
    PKTLAB_NCLOSE_MESSAGE
    PKTLAB_NPOLL_MESSAGE
    PKTLAB_NSEND_MESSAGE
    PKTLAB_NDATA_MESSAGE
    PKTLAB_NDROP_MESSAGE
    PKTLAB_NCAP_MESSAGE

    PKTLAB_XSUB_MESSAGE
    PKTLAB_XSTART_MESSAGE
    PKTLAB_XYIELD_MESSAGE
    PKTLAB_XEND_MESSAGE
    PKTLAB_XDESCR_MESSAGE
    PKTLAB_XFILT_MESSAGE
    PKTLAB_XKEY_MESSAGE
    PKTLAB_XCERT_MESSAGE
```

### Operation status
```
    PKTLAB_SUCCESS

    PKTLAB_INTR
    PKTLAB_BUSY
    PKTLAB_PORTINUSE
    PKTLAB_PKT2BIG
    PKTLAB_BUF2BIG
    PKTLAB_SKTERR 
    PKTLAB_UNIMPL 

    PKTLAB_UNKMSG 
    PKTLAB_BADMSG 
    PKTLAB_UNXPMSG
    PKTLAB_SKTINUSE
    PKTLAB_BADSKT 
    PKTLAB_BADPROTO
    PKTLAB_BADADDR
    PKTLAB_BADPORT
    PKTLAB_UNKFAULT
```

### Proto value and masks
```
    PKTLAB_IP4_PROTO
    PKTLAB_IP6_PROTO
    PKTLAB_RAW_PROTO
    PKTLAB_TCP_PROTO
    PKTLAB_UDP_PROTO
    PKTLAB_NETPROTO_MASK
    PKTLAB_TRANSPORT_MASK
```

### Socket status
```
    PKTLAB_SKTST_FREE
    PKTLAB_SKTST_OPENING
    PKTLAB_SKTST_OPEN
    PKTLAB_SKTST_EOF
    PKTLAB_SKTST_REFUSED
    PKTLAB_SKTST_RESET
    PKTLAB_SKTST_TIMEDOUT
    PKTLAB_SKTST_UNREACH
    PKTLAB_SKTST_UNKFAULT
```
