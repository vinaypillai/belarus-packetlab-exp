import setuptools

with open("README.md", "r") as fp:
    long_description = fp.read()

module = setuptools.Extension('pypl',
                    include_dirs = ["../include"],
                    libraries = ['pktlab'],
                    library_dirs = [".."],
                    sources = ['pypl.c'])

setuptools.setup(
    name = 'pypl',
    version = '0.0.1',
    author = 'TB Yan',
    author_email = "tzubinyan@gmail.com",
    description = 'Python wrapper for libpktlab',
	long_description = long_description,
	long_description_content_type = "text/markdown",
    packages=setuptools.find_packages(),
    ext_modules = [module],
    classifiers = [
        "Development Status :: 2 - Pre-Alpha",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: C",
        "Topic :: Software Development :: Libraries"],
    python_requires='>=3.6'
    )
