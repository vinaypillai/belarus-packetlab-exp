#!/bin/bash

while true
do
	psrst="$(ps | grep pktlabme)"
	if [ -z "$psrst" ]; then
		../pktlabme 127.0.0.1,5567
	fi
	sleep 1
done
