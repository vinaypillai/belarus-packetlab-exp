# libpktlab API
> Version 0.0.0
> Last updated: 2020/02/06, by TB Yan
> (An ongoing work \_(:з」∠)\_)

## Introduction
The libpktlab C library is a utility library to facilitate the creation of measurement endpoints, experiment controllers and rendezvous servers running the PacketLab protocol.

## Data types
1. `enum pktlab_message_type`: Type code specifying what per pktlab message is.
2. `enum pktlab_status`: Status codes that can be returned by pktlab measurement endpoint in `status` messages.
Status code `PKTLAB_SUCCESS` indicates success; status code > `PKTLAB_SUCCESS` indicates none fatal error; status code < `PKTLAB_SUCCESS` indicates fatal error.
3. `struct pktlab_message`: pktlab message in decoded form. There exist different fields for different pktlab messages. Refer to the pktlab protocol documents for the specific meaning of each field.
4. `enum pktlab_socket_state`: status codes for socket states of sockets. Sockets with status code < `PKTLAB_SKTST_FREE` must be closed and reopened for it to be utilized.
> Status code = `PKTLAB_SKTST_FREE` indicates socket is free.
> Status code > `PKTLAB_SKTST_FREE`:
>> `PKTLAB_SKTST_OPENING`: The socket is currently being opened. One can send request using to the socket, where `nsend` requests will be processed after the socket has completed opening.
>> `PKTLAB_SKTST_OPEN`: The socket is opened and available to all requests.
>> `PKTLAB_SKTST_EOF`: The socket has reached EOF. `nsend` requests will not be fulfilled
> 
> Status code < `PKTLAB_SKTST_FREE`:
>> `PKTLAB_SKTST_REFUSED`: Equivalent to `ECONNREFUSED` in BSD sockets. Found no one listening on the remote address.
>> `PKTLAB_SKTST_RESET`: Equivalent to `ECONNRESET`. Connection reset by peer
>> `PKTLAB_SKTST_TIMEDOUT`: Equivalent to `ETIMEDOUT`. Connection timed out
>> `PKTLAB_SKTST_UNREACH`: Eqivalent to `ENETUNREACH` or `EHOSTUNREACH`. Network is unreachable or No route to host, respectively.
>> `PKTLAB_SKTST_UNKFAULT`: Faults other than the above mentioned errors occurred.
5. `struct pktlab_reader`: Opaque structure for pktlab reader functions.
6. `struct pktlab_writer`: Opaque structure for pktlab writer functions.

## APIs
### Time Related
> Note that one real world second equals `PKTLAB_TICKS_PER_SECOND` ticks in `pktlab_time_t`.
1. `pktlab_time_now`
```C
extern pktlab_time_t pktlab_time_now(void)
```
Return current time (local clock) in `pktlab_time_t` format.

2. `pktlab_time_sec`
```C
static inline pktlab_time_t pktlab_time_sec(uint_fast32_t sec)
```
Convert `sec` in real world seconds to pktlab time ticks.
3. `pktlab_timeval_to_time`
```C
static inline pktlab_time_t pktlab_timeval_to_time(const struct timeval * tv)
```
Convert linux `struct timeval` in `tv` to pktlab time ticks.

4. `pktlab_time_to_timeval`
```C
static inline void pktlab_time_to_timeval(pktlab_time_t t, struct timeval * tv)
```
Convert pktlab time ticks in `t` to linux `struct timeval` and store in `tv` (must be allocated).

5. `pktlab_time_to_unix_time`
```C
static inline uint_fast32_t pktlab_time_to_unix_time(pktlab_time_t t)
```
Convert pktlab time ticks in `t` to real world seconds.

### Message Related
1. `pktlab_decode_message`
```C
extern size_t pktlab_decode_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, size_t len)
```
The `pktlab_decode_message` function decodes a raw message in bytes. On entry, `msg` points to an allocated but not initialized `struct pktlab_message`, `ptr` points to the raw message data in bytes and `len` specifies the length of raw message data. On return, `msg` is initialized with the decoded message and number of bytes in `ptr` used is returned

2. `pktlab_encode_message`
```C
extern int pktlab_encode_message (
	const struct pktlab_message * restrict msg,
	void * restrict buf, struct iovec * restrict iov)
```
The `pktlab_encode_message` function encodes a message into a form suitable for transmission (i.e. to bytes). On entry, `msg` should be a pointer to a properly initialized `struct pktlab_message`, `buf` a pointer to a buffer of at least `PKTLAB_ENCODE_BUFSZ` bytes, and `iov` a pointer to an array of at least `PKTLAB_ENCODE_IOVCNT` `struct iovec` elements (on Linux, see `readv(2)` manual page). On return, the iov array is filled and the number of `iov` elements used is returned. (The number of elements used may be less than `PKTLAB_ENCODE_IOVCNT`.) A negative return value indicates an error.

### Reader & Writer Related
#### Reader
> A set of utilities related to `struct pktlab_reader` to facilitate reading of pktlab messages.
1. `pktlab_create_reader`
```C
extern struct pktlab_reader * pktlab_create_reader(int fd)
```
Accepts an opened and connected TCP socket file descriptor (`fd`) and create a `struct pktlab_reader` from it, with which one can call other reader functions. Returns NULL and sets errno appropriately when error happens.
2. `pktlab_close_reader`
```C
extern void pktlab_close_reader(struct pktlab_reader * r)
```
Accepts a pointer to an initialized `struct pktlab_reader` and destroys it, freeing all resources allocated. Note that the `fd` passed to `pktlab_create_reader` w.r.t. `r` is not closed by this function.
3. `pktlab_reader_fileno`
```C
extern int pktlab_reader_fileno(const struct pktlab_reader * r)
```
Accepts a pointer to an initialized `struct pktlab_reader` and returns the corresponding file descriptor of the `struct pktlab_reader`.
4. `pktlab_read_message`
```C
extern int pktlab_read_message (
	struct pktlab_reader * restrict r,
	struct pktlab_message ** restrict msgptr)
```
Tries to read a pktlab message from the file descriptor of `r`. If success, stores an address of an allocated initialized `struct pktlab_message` in `msgptr`. Returns 1 if read is successful (including EOF, signaled by `*msgptr` being NULL); returns 0 if no message is available; return -1 if an error occurred. Note that one should free the allocated  `struct pktlab_message` in `msgptr` after finish using it to prevent memory leaks.

#### Writer
> A set of utilities related to `struct pktlab_writer` to facilitate sending of pktlab messages.
1. `pktlab_create_writer`
```C
extern struct pktlab_writer * pktlab_create_writer(int fd)
```
Accepts an opened and connected TCP socket file descriptor (`fd`) and creates a `struct pktlab_writer` from it, with which one can call other writer functions. Returns NULL and sets errno appropriately when error happens.
2. `pktlab_close_writer`
```C
extern void pktlab_close_writer(struct pktlab_writer * w)
```
Accepts a pointer to an initialized `struct pktlab_writer` and destroys it, freeing all resources allocated. Note that the `fd` passed to `pktlab_create_writer` w.r.t. `w` is not closed by this function.
3. `pktlab_flush_writer`
```C
extern int pktlab_flush_writer(struct pktlab_writer * w)
```
Accepts a pointer to an initialized `struct pktlab_writer` and tries to flush all unwritten data in the buffer of `w`. Returns the number of written bytes if success or -1 if failed.
4. `pktlab_writer_unsent`
```C
extern size_t pktlab_writer_unsent(const struct pktlab_writer * w)
```
Accepts a pointer to an initialized `struct pktlab_writer` and returns the number of unwritten bytes in the buffer of `w`.
5. `pktlab_writer_fileno`
```C
extern int pktlab_writer_fileno(const struct pktlab_writer * w)
```
Returns the file descriptor of an initialized `struct pktlab_writer`.
6. `pktlab_write_message`
```C
extern int pktlab_write_message (
	struct pktlab_writer * restrict w,
	const struct pktlab_message * restrict msg);
```
Encodes raw pktlab message based on contents of the structure pointed to by `msg` and tries to write the encoded raw message to the corresponding file descriptor of `w`. Returns 1 if the write is successful (may only write partial data with the remainder buffered); returns 0 if write is rejected due to `EWOULDBLOCK`; return -1 if an error occurred.

### Byte Order Related Utilities
#### Get Related
Get related libpktlab utils are named as `pktlab_get[BIT_NUM]["l","b","n",""]`.
What they do is that given a pointer to a byte array, they extract the first `BIT_NUM/8` number of bytes, interpret them based on the given byte order (`l`: little endian, `b`: big endian, `n`: network byte order, which is the same as `b`), and return the intrepreted value.

#### Set Related
Set related libpktlab utils are named as `pktlab_set[BIT_NUM]["l","b","n",""]`.
What they do is that given a pointer to a byte array and a value, they store the value at the space pointed to by the provided pointer under the specifed endian (`l`: little endian, `b`: big endian, `n`: network byte order, which is the same as `b`) (writing `BIT_NUM/8` number of bytes in the process).

#### hton, ntoh Related
Such libpktlab utils are named as `pktlab_hton[BIT_NUM]` or `pktlab_ntoh[BIT_NUM]`.
They perform the same host and network byte order translation (e.g. `htons`, `ntohl` etc.) as provided in Linux.
