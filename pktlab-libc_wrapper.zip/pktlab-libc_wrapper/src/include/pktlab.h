// pktlab.h
//

#ifndef _PKTLAB_H_
#define _PKTLAB_H_

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include <sys/time.h>
#include <arpa/inet.h>

// 
// EXPORTED CONSTANTS
//

#define PKTLAB_HLEN	4

#define PKTLAB_TICKS_PER_SECOND	UINT64_C(1000000000)
#define PKTLAB_TIME_MAX UINT64_MAX

#define PKTLAB_MREAD_MAX UINT32_C(0x10000)
#define PKTLAB_NDATA_MAX UINT32_C(0x10000)

#define PKTLAB_IPV4_W_MSK_ADDR_LEN 8
#define PKTLAB_IPV4_WO_MSK_ADDR_LEN 4
#define PKTLAB_IPV6_ADDR_LEN 16

#define PKTLAB_ADDRLEN_MAX PKTLAB_IPV6_ADDR_LEN
#define PKTLAB_PORTLEN_MAX 4

#define PKTLAB_STATLIST_SIZE 8

#define PKTLAB_DEFAULT_ADDR_STR "127.0.0.1"
#define PKTLAB_DEFAULT_PORT_STR "20556"

#define PKTLAB_DEFAULT_SPEC_STR \
	PKTLAB_DEFAULT_ADDR_STR "," PKTLAB_DEFAULT_PORT_STR

// 
// EXPORTED TYPE DEFINITIONS
// 

typedef uint64_t pktlab_time_t;

enum pktlab_message_type {
	PKTLAB_UNDEF_MESSAGE		= 0,
	PKTLAB_STATUS_MESSAGE		= '=',
	
	PKTLAB_MREAD_MESSAGE		= 'R',
	PKTLAB_MWRITE_MESSAGE		= 'W',
	PKTLAB_MDATA_MESSAGE		= 'M',
	
	PKTLAB_NOPEN_MESSAGE		= 'N',
	PKTLAB_NCLOSE_MESSAGE		= 'Z',
	PKTLAB_NPOLL_MESSAGE		= 'P',
	PKTLAB_NSEND_MESSAGE		= 'S',
	PKTLAB_NDATA_MESSAGE		= 'B',
	PKTLAB_NSTAT_MESSAGE		= 'T',
	PKTLAB_NCAP_MESSAGE			= 'J',
	
	PKTLAB_XSUB_MESSAGE			= 'Q',
	PKTLAB_XSTART_MESSAGE		= 'G',
	PKTLAB_XYIELD_MESSAGE		= 'Y',
	PKTLAB_XEND_MESSAGE			= 'E',
	PKTLAB_XDESCR_MESSAGE		= 'X',
	PKTLAB_XFILT_MESSAGE		= 'F',
	PKTLAB_XKEY_MESSAGE			= 'K',
	PKTLAB_XCERT_MESSAGE		= 'C'
};

enum pktlab_status {
	PKTLAB_SUCCESS			= 0,
	
	PKTLAB_INTR				= 1,
	PKTLAB_BUSY				= 2,
	PKTLAB_PORTINUSE		= 3,
	PKTLAB_PKT2BIG			= 4,
	PKTLAB_BUF2BIG			= 5,
	PKTLAB_SKTERR			= 6,
	PKTLAB_NOBUFS			= 7,
	PKTLAB_UNIMPL			= 127,
	
	PKTLAB_UNKMSG			= -1,
	PKTLAB_BADMSG			= -2,
	PKTLAB_UNXPMSG			= -3,
	PKTLAB_SKTINUSE			= -4,
	PKTLAB_BADSKT			= -5,
	PKTLAB_BADPROTO			= -6,
	PKTLAB_BADADDR			= -7,
	PKTLAB_BADPORT			= -8,
	PKTLAB_BADINTF			= -9,
	PKTLAB_UNKFAULT			= -128
};

#define PKTLAB_IP4_PROTO        0x4
#define PKTLAB_IP6_PROTO        0x6
#define PKTLAB_RAW_PROTO        0x0
#define PKTLAB_TCP_PROTO        0x08
#define PKTLAB_UDP_PROTO        0x10
#define PKTLAB_ICMP_ECHO_PROTO  0x18

#define PKTLAB_NETPROTO_MASK    0x7
#define PKTLAB_TRANSPORT_MASK   0xf8

struct pktlab_message {
	enum pktlab_message_type type;
	
	union {
		struct {
			const void * ptr;
			uint32_t len;
			bool malformed;
		} raw;
		
		struct {
			int8_t id;
			const char * textptr;
			uint32_t textlen;
		} status;
		
		struct {
			uint32_t addr, len;
		} mread;
		
		struct {
			uint32_t addr, len;
			const void * ptr;
		} mwrite;
		
		struct {
			uint32_t addr, len;
			const void * ptr;
		} mdata;
		
		struct {
			uint8_t sktid;
			uint8_t proto;
			uint8_t intf;
			uint8_t addrlen;
			uint8_t portlen;
			uint32_t rbufsz;
			const void * addrptr;
			const void * portptr;
		} nopen;
		
		struct {
			uint8_t sktid;
		} nclose;
		
		struct {
			pktlab_time_t time;
		} npoll;
		
		struct {
			uint8_t sktid;
			uint8_t proto;
			uint16_t tidx;
			pktlab_time_t time;
			union {
				struct {
					uint32_t len;
					const void * ptr;
				} raw;

				struct {
					uint32_t len;
					const void * ptr;
				} tcp;

				struct {
					uint32_t len;
					const void * ptr;
				} udp;

				struct {
					uint8_t ttl;
					uint8_t addrlen;
					uint16_t seq;
					uint32_t datalen;
					const void * addrptr;
					const void * dataptr;
				} icmp;
			};
		} nsend;
		
		struct {
			pktlab_time_t time;
			const void * ptr;
			uint32_t len;
			uint8_t sktid;
			uint8_t proto;
		} ndata;
		
		struct {
			const void * ptr;
			uint32_t len;
		} nstat;
		
		struct {
			pktlab_time_t time;
			const void * filtptr;
			uint32_t filtlen;
		} ncap;
		
		struct {
			const void * hashptr;
			uint32_t hashlen;
		} xsub;
				
		struct {
			const void * hashptr;
			uint32_t hashlen;
			pktlab_time_t time;
			uint16_t prio;
		} xstart;
		
		struct {
			/* no args */
		} xyield;
		
		struct {
			/* no args */
		} xend;
		
		struct {
			const void * ptr;
			uint32_t len;
		} xdescr;
		
		struct {
			const void * ptr;
			uint32_t len;
		} xfilt;

		struct {
			// ... not finished
		} xkey;

		struct {
			// ... not finished
		} xcert;
	};
};

enum pktlab_xattr_type {
	PKTLAB_UNKNOWN_XATTR		= 0,
	PKTLAB_NAME_XATTR			= 'N',
	PKTLAB_SEQNO_XATTR			= 'O',
	PKTLAB_TIME_VALID_XATTR		= 'T',
	PKTLAB_SERVER_HOST_XATTR	= 'A',
	PKTLAB_SERVER_PORT_XATTR	= 'B',
	PKTLAB_FILTER_HASH_XATTR	= 'F'
};

struct pktlab_xattr {
	struct pktlab_xattr * next;
	enum pktlab_xattr_type type;
	uint8_t len;
	
	union {
		const char * name;
		uint32_t seqno;
		struct { pktlab_time_t start, end; } time_valid;
		const char * server_host;
		uint16_t server_port;
		struct { const void * ptr; uint8_t len; } filter_hash;
		struct { uint8_t type, len; } raw;
	};
};

struct pktlab_vmem_region; // forward decl.

typedef void (*pktlab_vmem_reader_t) (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict dst);

typedef void (*pktlab_vmem_writer_t) (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, const void * restrict src);

struct pktlab_vmem_region {
	uint32_t start, end;
	pktlab_vmem_reader_t read;
	pktlab_vmem_writer_t write;
	uintptr_t aux;
};

enum pktlab_socket_state {
	PKTLAB_SKTST_FREE		= 0,
	PKTLAB_SKTST_OPENING	= 1,
	PKTLAB_SKTST_OPEN		= 2,
	PKTLAB_SKTST_EOF		= 3,
	PKTLAB_SKTST_REFUSED	= -1,
	PKTLAB_SKTST_RESET		= -2,
	PKTLAB_SKTST_TIMEDOUT	= -3,
	PKTLAB_SKTST_UNREACH	= -4,
	PKTLAB_SKTST_UNKFAULT	= -128
};

// 
// TIME FUNCTION DECLARATIONS
// 

extern pktlab_time_t pktlab_time_now(void);
static inline pktlab_time_t pktlab_time_sec(uint_fast32_t sec);
static inline pktlab_time_t pktlab_timeval_to_time(const struct timeval * tv);
static inline void pktlab_time_to_timeval(pktlab_time_t t, struct timeval * tv);
static inline uint_fast32_t pktlab_time_to_unix_time(pktlab_time_t t);

// The pktlab_decode_message function decodes a message. On entry, msg
// points to an allocated but not initialized message, msgtype and datalen
// are valid for the current message and dataptr points to the message
// data. On return, msg is initialized with the decoded message and number
// of bytes used is returned.

extern size_t pktlab_decode_message (
	struct pktlab_message * restrict msg,
	const void * restrict ptr, size_t len);

// The pktlab_encode_message function encodes a message into a form
// suitable for transmission. On entry, msg should be a pointer to a
// properly initialized message, buf a pointer to a buffer of at least
// PKTLAB_ENCODE_BUFSZ bytes, and iov a pointer to an array of least
// PKTLAB_ENCODE_IOVCNT elements. On return, the iov array is filled and
// the number of iov elements used is returned. (The number of elements
// used may be less than PKTLAB_ENCODE_IOVCNT.) A negative return value
// indicates an error.

#define PKTLAB_ENCODE_IOVCNT	3
#define PKTLAB_ENCODE_BUFSZ 	(PKTLAB_HLEN+16)

struct iovec; // forward decl.

extern int pktlab_encode_message (
	const struct pktlab_message * restrict msg,
	void * restrict buf, struct iovec * restrict iov);

// Functions of the form create_XXX_message create a message of the given
// type with the given parameters. They combine memory allocation and 
// pktlab_message structure initialization into one call.

extern struct pktlab_message * pktlab_create_status_message (
	enum pktlab_status status, const char * fmt, ...);

// 
// FORMATTING FUNCTION DECLARATIONS
// 

// The pktlab_format_message function formats a message as an ASCII string.
// On entry, buf must be a pointer to a buffer of size bufsz and msg much
// be a valid message. On return, buf will contain up to bufsz bytes of the
// textual representation of the message. The string is terminating with a
// '\0' character (unless bufsz == 0). The number of characters that would
// be necessary to represent the message completely (excluding the
// terminaing '\0' character) is returned.

extern int pktlab_format_message (
	char * restrict buf, size_t bufsz,
	const struct pktlab_message * restrict msg);

extern int pktlab_parse_message (
	const char * restrict str,
	struct pktlab_message * restrict msg, void ** restrict data);

extern int pktlab_print_message (
	FILE * restrict file, const struct pktlab_message * restrict msg);

extern int pktlab_scan_message (
	FILE * restrict file,
	struct pktlab_message * restrict msg, void ** restrict data);

extern const char * pktlab_status_name(enum pktlab_status status);
extern const char * pktlab_status_descr(enum pktlab_status status);
extern const char * pktlab_msgtype_name(enum pktlab_message_type type);
extern const char * pktlab_sktstate_name(enum pktlab_socket_state state);

// 
// READER FUNCTION DECLARATIONS
// 

struct pktlab_reader; // opaque

extern struct pktlab_reader * pktlab_create_reader(int fd);
extern void pktlab_close_reader(struct pktlab_reader * r);
extern int pktlab_reader_fileno(const struct pktlab_reader * r);

extern int pktlab_read_message (
	struct pktlab_reader * restrict r,
	struct pktlab_message ** restrict msgptr);

// 
// WRITER FUNCTION DECLARATIONS
// 

struct pktlab_writer; // opaque

extern struct pktlab_writer * pktlab_create_writer(int fd);
extern void pktlab_close_writer(struct pktlab_writer * w);
extern int pktlab_flush_writer(struct pktlab_writer * w);

extern size_t pktlab_writer_unsent(const struct pktlab_writer * w);
extern int pktlab_writer_fileno(const struct pktlab_writer * w);

extern int pktlab_write_message (
	struct pktlab_writer * restrict w,
	const struct pktlab_message * restrict msg);

//
// XATTR FUNCTION DECLARATIONS
// 

// Functions to encode and decode xattrs.
// 

extern struct pktlab_xattr * pktlab_xattr_decode (
	const void * ptr, uint_fast32_t len);

extern uint_fast32_t pktlab_xattrlist_encoded_size (
	const struct pktlab_xattr * attr);

extern size_t pktlab_xattrlist_encode (
	const struct pktlab_xattr * restrict list,
	void * restrict buf, size_t bufsz);

// Functions for working with xattr lists.
// 

extern void pktlab_xattrlist_free(struct pktlab_xattr * list);

extern struct pktlab_xattr * pktlab_xattrlist_find (
	struct pktlab_xattr * list, enum pktlab_xattr_type type);

extern struct pktlab_xattr * pktlab_xattrlist_insert (
	struct pktlab_xattr * restrict list, struct pktlab_xattr * restrict elt);

extern struct pktlab_xattr * pktlab_xattrlist_remove_first (
	struct pktlab_xattr * list);

extern uint_fast32_t pktlab_xattrlist_count (
	const struct pktlab_xattr * list);

// Functions to create attributes of a specific type.
// 

extern struct pktlab_xattr * pktlab_create_name_xattr (
	const char * name);

extern struct pktlab_xattr * pktlab_create_period_xattr (
	pktlab_time_t after, pktlab_time_t before);

extern struct pktlab_xattr * pktlab_create_server_host_xattr (
	const char * name);

extern struct pktlab_xattr * pktlab_create_server_port_xattr (
	uint_fast16_t port);

// 
// ENDPOINT VIRTUAL MEMORY FUNCTION DECLARATIONS
// 

extern void pktlab_vmem_read (
	const struct pktlab_vmem_region * restrict rgn, uint_fast32_t rgncnt,
	uint_fast32_t addr, uint_fast32_t len,	void * restrict dst);

extern void pktlab_vmem_write (
	const struct pktlab_vmem_region * restrict rgn, uint_fast32_t rgncnt,
	uint_fast32_t addr, uint_fast32_t len, const void * restrict src);

extern void pktlab_buffer_reader (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t addr, uint_fast32_t len, void * restrict dst);

extern void pktlab_buffer_writer (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t addr, uint_fast32_t len, const void * restrict src);

// 
// BYTE ORDER INVARIANT MEMORY ACCESS FUNCTIONS
// 

static inline uint_fast8_t pktlab_get8(const void * ptr);
static inline uint_fast16_t pktlab_get16b(const void * ptr);
static inline uint_fast16_t pktlab_get16l(const void * ptr);
static inline uint_fast32_t pktlab_get24b(const void * ptr);
static inline uint_fast32_t pktlab_get24l(const void * ptr);
static inline uint_fast32_t pktlab_get32b(const void * ptr);
static inline uint_fast32_t pktlab_get32l(const void * ptr);
static inline uint_fast64_t pktlab_get64b(const void * ptr);
static inline uint_fast64_t pktlab_get64l(const void * ptr);

#define pktlab_get16n pktlab_get16b
#define pktlab_get24n pktlab_get24b
#define pktlab_get32n pktlab_get32b
#define pktlab_get64n pktlab_get64b

static inline void pktlab_set8(void * ptr, uint_fast8_t val);
static inline void pktlab_set16b(void * ptr, uint_fast16_t val);
static inline void pktlab_set16l(void * ptr, uint_fast16_t val);
static inline void pktlab_set24b(void * ptr, uint_fast32_t val);
static inline void pktlab_set24l(void * ptr, uint_fast32_t val);
static inline void pktlab_set32b(void * ptr, uint_fast32_t val);
static inline void pktlab_set32l(void * ptr, uint_fast32_t val);
static inline void pktlab_set64b(void * ptr, uint_fast64_t val);
static inline void pktlab_set64l(void * ptr, uint_fast64_t val);

#define pktlab_set16n pktlab_set16b
#define pktlab_set24n pktlab_set24b
#define pktlab_set32n pktlab_set32b
#define pktlab_set64n pktlab_set64b

// 
// BYTE ORDER CONVERSION FUNCTIONS
// 

static inline uint_fast16_t pktlab_hton16(uint_fast16_t x);
static inline uint_fast32_t pktlab_hton32(uint_fast32_t x);
static inline uint_fast64_t pktlab_hton64(uint_fast64_t x);
static inline uint_fast16_t pktlab_ntoh16(uint_fast16_t x);
static inline uint_fast32_t pktlab_ntoh32(uint_fast32_t x);
static inline uint_fast64_t pktlab_ntoh64(uint_fast64_t x);

// 
// INLINE FUNCTION DEFINITIONS
// 

static inline pktlab_time_t pktlab_time_sec(uint_fast32_t sec) {
	return (uint64_t) sec * PKTLAB_TICKS_PER_SECOND;
}

static inline pktlab_time_t pktlab_timeval_to_time(const struct timeval * tv) {
	return (uint64_t) tv->tv_sec * PKTLAB_TICKS_PER_SECOND
		+ (uint64_t) tv->tv_usec * PKTLAB_TICKS_PER_SECOND / 1000000;
}

static inline void pktlab_time_to_timeval (
	pktlab_time_t t, struct timeval * tv)
{
	const uint64_t t_us = t / (PKTLAB_TICKS_PER_SECOND / 1000000);
	tv->tv_sec = t_us / 1000000;
	tv->tv_usec = t_us % 1000000;
}

static inline uint_fast32_t pktlab_time_to_unix_time(pktlab_time_t t) {
	return t / PKTLAB_TICKS_PER_SECOND;
}

static inline uint_fast8_t pktlab_get8(const void * ptr) {
	return *(const uint8_t*)ptr;
}

static inline uint_fast16_t pktlab_get16b(const void * ptr) {
	const uint8_t * u8ptr = ptr;
	uint_fast16_t val;
	
	val = (uint_fast16_t) u8ptr[0] << 8;
	val |= u8ptr[1];
	return val;
}

static inline uint_fast16_t pktlab_get16l(const void * ptr) {
	const uint8_t * u8ptr = ptr;
	uint_fast16_t val;
	
	val = (uint_fast16_t) u8ptr[1] << 8;
	val |= u8ptr[0];
	return val;
}

static inline uint_fast32_t pktlab_get24b(const void * ptr) {
	const uint8_t * u8ptr = ptr;
	uint_fast32_t val;
	
	val = (uint_fast32_t) u8ptr[0] << 16;
	val |= (uint_fast16_t) u8ptr[1] << 8;
	val |= u8ptr[2];
	return val;
}

static inline uint_fast32_t pktlab_get24l(const void * ptr) {
	const uint8_t * u8ptr = ptr;
	uint_fast32_t val;
	
	val = (uint_fast32_t) u8ptr[2] << 16;
	val |= (uint_fast16_t) u8ptr[1] << 8;
	val |= u8ptr[0];
	return val;
}

static inline uint_fast32_t pktlab_get32b(const void * ptr) {
	uint_fast32_t val;
	
	val = (uint_fast32_t) pktlab_get16b(ptr) << 16;
	val |= pktlab_get16b(ptr+2);
	return val;
}

static inline uint_fast32_t pktlab_get32l(const void * ptr) {
	uint_fast32_t val;
	
	val = (uint_fast32_t) pktlab_get16l(ptr+2) << 16;
	val |= pktlab_get16l(ptr);
	return val;
}

static inline uint_fast64_t pktlab_get64b(const void * ptr) {
	uint_fast64_t val;
	
	val = (uint_fast64_t) pktlab_get32b(ptr) << 32;
	val |= pktlab_get32b(ptr+4);
	return val;
}

static inline uint_fast64_t pktlab_get64l(const void * ptr) {
	uint_fast64_t val;
	
	val = (uint_fast64_t) pktlab_get32l(ptr+4) << 32;
	val |= pktlab_get32l(ptr);
	return val;
}

static inline void pktlab_set8(void * ptr, uint_fast8_t val) {
	*(uint8_t*)ptr = val;
}

static inline void pktlab_set16b(void * ptr, uint_fast16_t val) {
	uint8_t * u8ptr = ptr;
	u8ptr[0] = val >> 8;
	u8ptr[1] = val >> 0;
}

static inline void pktlab_set16l(void * ptr, uint_fast16_t val) {
	uint8_t * u8ptr = ptr;
	u8ptr[1] = val >> 8;
	u8ptr[0] = val >> 0;
}

static inline void pktlab_set24b(void * ptr, uint_fast32_t val) {
	uint8_t * u8ptr = ptr;
	u8ptr[0] = val >> 16;
	u8ptr[1] = val >> 8;
	u8ptr[2] = val >> 0;
}

static inline void pktlab_set24l(void * ptr, uint_fast32_t val) {
	uint8_t * u8ptr = ptr;
	u8ptr[2] = val >> 16;
	u8ptr[1] = val >> 8;
	u8ptr[0] = val >> 0;
}

static inline void pktlab_set32b(void * ptr, uint_fast32_t val) {
	pktlab_set16b(ptr, val >> 16);
	pktlab_set16b(ptr+2, val);
}

static inline void pktlab_set32l(void * ptr, uint_fast32_t val) {
	pktlab_set16l(ptr+2, val >> 16);
	pktlab_set16l(ptr, val);
}

static inline void pktlab_set64b(void * ptr, uint_fast64_t val) {
	pktlab_set32b(ptr, val >> 32);
	pktlab_set32b(ptr+4, val);
}

static inline void pktlab_set64l(void * ptr, uint_fast64_t val) {
	pktlab_set32l(ptr+4, val >> 32);
	pktlab_set32l(ptr, val);
}

static inline uint_fast16_t pktlab_hton16(uint_fast16_t x) {
	return htons(x);
}

static inline uint_fast32_t pktlab_hton32(uint_fast32_t x) {
	return htonl(x);
}

static inline uint_fast64_t pktlab_hton64(uint_fast64_t x) {
	uint_fast32_t hi, lo;
	
	hi = x >> 32;
	lo = x & UINT32_C(0xffffffff);
	return ((uint_fast64_t) pktlab_hton32(lo) << 32) | pktlab_hton32(hi);
}

static inline uint_fast16_t pktlab_ntoh16(uint_fast16_t x) {
	return ntohs(x);
}

static inline uint_fast32_t pktlab_ntoh32(uint_fast32_t x) {
	return ntohl(x);
}

static inline uint_fast64_t pktlab_ntoh64(uint_fast64_t x) {
	uint_fast32_t hi, lo;
	
	lo = pktlab_ntoh32(x >> 32);
	hi = pktlab_ntoh32(x & UINT32_C(0xffffffff));
	return ((uint_fast64_t) hi << 32) | lo;
}

#endif
