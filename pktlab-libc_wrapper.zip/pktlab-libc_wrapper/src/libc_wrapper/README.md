## Make
Use `cmake CMakeLists.txt` to generate the make file

Use `make` to compile the library. The generated library file is `libpktlab_libc.so`.

## Use
LD_PRELOAD=\<path to libpktlab_libc.so> \<command>


## Configuration

### Through the pipe server 
The command to start the pipe server is: `python3 piped.py <me_port> <ec_port>`. In **`user_config.h`**, set `PKTLAB_PIPED` macro to `1` and configure the `PKTLAB_EC_PORT` to the desired port. The default `ec_port` on the pipe server is `10003`.

### Direct connect
In **`user_config.h`**, set `PKTLAB_PIPED` macro to `0` and configure the `PKTLAB_ME_PORT` to the desired port. The default `me_port` on the pipe server is `5567`.

## Measurement endpoint
The command to start the measurement endpoint on localhost is: `./pktlabme 127.0.0.1,<me_port>`