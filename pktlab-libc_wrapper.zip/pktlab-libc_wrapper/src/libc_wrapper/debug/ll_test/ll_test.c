#include "lib/ll.h"
#include <malloc.h>
#include <assert.h>

struct node {
    int fd;
};

static int comp(const void* a, const void* b) {
    const struct node* ap = (const struct node*)a;
    const struct node* bp = (const struct node*)b;
    if (ap->fd < bp->fd)
        return -1;
    if (ap->fd == bp->fd)
        return 0;
    if (ap->fd > bp->fd)
        return 1;
    return 0;
}



int main() {
    struct llist* l = ll_create(comp, NULL);
    assert(l);

    struct node n1 = {.fd=1};
    struct node n2 = {.fd=2};
    struct node n3 = {.fd=3};
    int rv;
    rv = ll_insert(l, &n1);
    assert(rv == 0);

    rv  = ll_insert(l, &n2);
    assert(rv == 0);

    void * p;
    p = ll_find(l, &n1);
    assert(p == &n1);

    p = ll_find(l, &n2);
    assert(p == &n2);

    p = ll_find(l, &n3);
    assert(p == NULL);

    rv = ll_insert(l, &n3);
    assert(rv == 0);

    p = ll_delete(l, &n2);
    assert(p == &n2);

    p = ll_delete(l, &n2);
    assert(p == NULL);

    p = ll_find(l, &n2);
    assert(p == NULL);

    p = ll_find(l, &n3);
    assert(p == &n3);

    p = ll_find(l, &n1);
    assert(p == &n1);

    p = ll_delete(l, &n1);
    assert(p == &n1);

    p = ll_find(l, &n3);
    assert(p == &n3);

    rv = ll_destroy(l);
    assert(rv == 0);
    
    puts("all assertion passed");
    return 0;
}