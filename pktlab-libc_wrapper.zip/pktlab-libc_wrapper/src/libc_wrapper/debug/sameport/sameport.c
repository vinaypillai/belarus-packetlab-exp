#include <stdio.h>

#include "../include/pktlab_libc.h"
#include "../pktlab_util/pktlab_ops.h"
#include "../include/socket.h"

#include <string.h>

int main() {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    pl_socket_t* pl_sock = fd_map[sock];
    pl_sock->local_port = 10001;
    char buf = 0;
    struct sockaddr_in addr_in;
    addr_in.sin_family = AF_INET;
    addr_in.sin_port = htons(10001);
    inet_pton(AF_INET, "127.0.0.1", &(addr_in.sin_addr.s_addr));

    printf("sendto %d\n",sendto(sock, &buf, 1, 0, &addr_in, sizeof(addr_in)));
    printf("recv %d\n", recv(sock, &buf, 1, 0));
    return 0;
}