#include "include/pktlab_libc.h"

#include "include/epoll.h"
#include "include/epoll_rb.h"
#include "include/file.h"
#include "include/time.h"
#include "lib/ll.h"
#include "pktlab_util/pktlab_ops.h"
#include <assert.h>

#define MAX_TIMEOUT_SEC 0
#define MAX_TIMEOUT_USEC 0
#define MILLI_PER_SEC 1000
#define MICRO_PER_MILLI 1000

// static int plsock_num = 0;

int epoll_create(int size) {
    INIT_HEADER();
    libc_epoll_create_t fn =
        handle ? LIBC_ORIG(epoll_create) : dlsym(RTLD_NEXT, "epoll_create");
    int epfd = fn(size);
    if (epfd == -1)
        return epfd;

    int rv = epoll_rbtree_create(epfd);
    if (rv == -1) {
        LIBC_ORIG(close)(epfd);
        return -1;
    }
    return epfd;
}

int epoll_ctl(int epfd, int op, int fd, struct epoll_event *event) {
    libc_epoll_ctl_t fn =
        handle ? LIBC_ORIG(epoll_ctl) : dlsym(RTLD_NEXT, "epoll_ctl");
    int rv = fn(epfd, op, fd, event);
    if (rv == -1)
        return rv;

    if (!IS_PL_SOCK(fd))
        return rv;

    switch (op) {
    case EPOLL_CTL_ADD:
        return epoll_rbtree_insert(epfd, fd, event);
    case EPOLL_CTL_MOD:
        return epoll_rbtree_replace(epfd, fd, event);
    case EPOLL_CTL_DEL:
        return epoll_rb_tree_delete(epfd, fd);
    }
    warn("control reached the end of epoll_ctl");
    return rv;
}

#define DEL_ME_SOCK()                                                          \
    do {                                                                       \
        rv = LIBC_ORIG(epoll_ctl)(epfd, EPOLL_CTL_DEL, me_socket, NULL);       \
        assert(rv == 0);                                                       \
    } while (0)

int epoll_wait(int epfd, struct epoll_event *events, int maxevents,
               int timeout) {
    // return LIBC_ORIG(epoll_wait)(epfd, events, maxevents, timeout);
    INIT_HEADER();
    int rv;
    int events_offset = 0;
    int fd_ready = 0;

    // timekeeping
    uint32_t timeout_sec, timeout_usec;
    struct timeval time_expire, time_cur, timeout_rem, timeout_tv;
    struct timeval timeout_max = {.tv_sec = MAX_TIMEOUT_SEC,
                                  .tv_usec = MAX_TIMEOUT_USEC};
    LIBC_ORIG(gettimeofday)(&time_cur, NULL);
    bool blocking = false;
    if (timeout < 0) {
        blocking = true;
        timeout_sec = MAX_TIMEOUT_SEC;
        timeout_usec = MAX_TIMEOUT_USEC;
    } else {
        millisec_to_timeval(timeout, &timeout_tv);
        timeradd(&time_cur, &timeout_tv, &time_expire);
        if (timeout < MAX_TIMEOUT_SEC * MILLI_PER_SEC +
                          MAX_TIMEOUT_USEC / MICRO_PER_MILLI) {
            timeout_sec = timeout / MILLI_PER_SEC;
            timeout_usec = timeout % MILLI_PER_SEC * MICRO_PER_MILLI;
        } else {
            timeout_sec = MAX_TIMEOUT_SEC;
            timeout_usec = MAX_TIMEOUT_USEC;
        }
    }

    // traverse the rb_tree
    // check if any pl_sock has data ready
    struct epfd_tree t_search = {.epfd = epfd};
    struct epfd_tree *t = ll_find(epfd_list, &t_search);
    assert(t);

    struct epoll_event me_sock_event = {.data = {.fd = me_socket}, .events = 0};
    if (rb_count(t->tp)) {
        struct rb_traverser trav;
        // rb_t_init(&trav, t->tp);
        for (struct tree_node *n = rb_t_first(&trav, t->tp); n != NULL;
             n = rb_t_next(&trav)) {
            me_sock_event.events |= n->event.events & EPOLL_SUP_EVENTS;
            if (n->event.events & EPOLL_IN_EVENTS) {
                pl_socket_t *pl_sock = fd_map[n->fd];
                assert(pl_sock);
                if (pl_sock->buf_len) {
                    events[events_offset].events =
                        n->event.events & EPOLL_IN_EVENTS;
                    events[events_offset].data = n->event.data;
                    ++events_offset;
                    ++fd_ready;
                    if (events_offset >= maxevents)
                        break;
                }
            }
        }
    }

    if (fd_ready)
        return fd_ready;
    assert(events_offset == 0);

    bool npoll_flag = false;
    bool epoll_me_flag = false;

    if (me_sock_event.events) {
        epoll_me_flag = true;
        rv = LIBC_ORIG(epoll_ctl)(epfd, EPOLL_CTL_ADD, me_socket,
                                  &me_sock_event);
        assert(rv == 0);
    }

    npoll_flag = !!(me_sock_event.events & (EPOLLIN | EPOLLRDNORM));

    int ctr;
    while (true) {
        if (npoll_flag) {
#ifdef PKTLAB_FIFO
            pl_send_npoll_fifo(timeout_sec, timeout_usec, &ctr);
#else
            pl_send_npoll(timeout_sec, timeout_usec);
#endif
            fd_ready = LIBC_ORIG(epoll_wait)(epfd, events, maxevents, -1);
        } else {
            fd_ready = LIBC_ORIG(epoll_wait)(epfd, events, maxevents, timeout);
        }

        if (fd_ready < 0) {
            if (epoll_me_flag)
                DEL_ME_SOCK();
            if (npoll_flag)
                pl_recv_npoll_fifo(NULL, NULL, 0, &ctr);
            return fd_ready;
        }

        struct epoll_event me_ready_event = {.data.fd = 0, .events = 0};
        if (fd_ready) {
            if (epoll_me_flag) {
                // find if there's me_socket in the events list
                for (int i = 0; i < fd_ready; ++i) {
                    if (events[i].data.fd == me_socket) {
                        me_ready_event = events[i];
                        // remove me_socket from events
                        if (i == fd_ready - 1)
                            --fd_ready;
                        else {
                            events[i] = events[fd_ready - 1];
                            --fd_ready;
                        }
                        break;
                    }
                }
            }
        }

        if (npoll_flag) {
#ifdef PKTLAB_FIFO
            fd_ready = pl_parse_npoll_epoll_fifo(
                t, events, fd_ready, maxevents,
                me_ready_event.events & EPOLL_OUT_EVENTS, &ctr);
#else
            fd_ready =
                pl_parse_npoll_epoll(t, events, fd_ready, maxevents,
                                     me_ready_event.events & EPOLL_OUT_EVENTS);
#endif
        }

        if (!npoll_flag || fd_ready) {
            if (epoll_me_flag)
                DEL_ME_SOCK();
            return fd_ready;
        }

        if (blocking)
            continue;

        LIBC_ORIG(gettimeofday)(&time_cur, NULL);
        // expired
        if (!timercmp(&time_cur, &time_expire, <)) {
            if (epoll_me_flag)
                DEL_ME_SOCK();
            return fd_ready;
        }

        timersub(&time_expire, &time_cur, &timeout_rem);
        if (timercmp(&timeout_rem, &timeout_max, <)) {
            timeout_sec = timeout_rem.tv_sec;
            timeout_usec = timeout_rem.tv_usec;
        } else {
            timeout_sec = MAX_TIMEOUT_SEC;
            timeout_usec = MAX_TIMEOUT_USEC;
        }
    }
}
