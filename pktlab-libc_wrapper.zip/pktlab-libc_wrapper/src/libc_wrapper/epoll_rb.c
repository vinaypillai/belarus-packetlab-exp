#include "include/epoll_rb.h"
#include "include/epoll.h"
#include "include/pktlab_libc.h"
#include "lib/ll.h"
#include <assert.h>
#include <errno.h>
#include <string.h>

struct llist *epfd_list = NULL;
size_t epfd_list_len = 0;

int is_epfd(int epfd) {
    if (!epfd_list || !epfd_list_len)
        return 0;

    struct epfd_tree t_search = {.epfd = epfd, .tp = NULL};
    struct epfd_tree *t = ll_find(epfd_list, &t_search);
    return (t != 0);
}

static inline int epfd_tree_comp(const void *a, const void *b) {
    const struct epfd_tree *ap = (const struct epfd_tree *)a;
    const struct epfd_tree *bp = (const struct epfd_tree *)b;
    return ap->epfd - bp->epfd;
}

static inline int tree_node_comp(const void *a, const void *b, void *param) {
    const struct tree_node *ap = (const struct tree_node *)a;
    const struct tree_node *bp = (const struct tree_node *)b;
    (void)param;
    return ap->fd - bp->fd;
}

static inline void tree_node_free(void *rb_item, void *rb_param) {
    free(rb_item);
}

int epoll_rbtree_create(int epfd) {
    if (epfd_list == NULL) {
        epfd_list = ll_create(epfd_tree_comp, free);
        if (!epfd_list) {
            errno = ENOMEM;
            return -1;
        }
    }

    struct epfd_tree *t = malloc(sizeof(t));
    if (!t) {
        errno = ENOMEM;
        return -1;
    }

    t->tp = rb_create(tree_node_comp, NULL, NULL);
    if (!t->tp) {
        free(t);
        errno = ENOMEM;
        return -1;
    }

    t->epfd = epfd;

    int rv = ll_insert(epfd_list, t);
    if (rv == -1) {
        free(t->tp);
        free(t);
        errno = ENOMEM;
        return -1;
    }
    ++epfd_list_len;

    return 0;
}

int epoll_rbtree_insert(int epfd, int fd, struct epoll_event *event) {
    struct epfd_tree t_search = {.epfd = epfd, .tp = NULL};
    struct epfd_tree *t = ll_find(epfd_list, &t_search);
    if (!t)
        return -1;

    struct tree_node *new_node = malloc(sizeof(*new_node));
    if (!new_node) {
        errno = ENOMEM;
        return -1;
    }

    new_node->fd = fd;
    memcpy(&new_node->event, event, sizeof(*event));

    struct tree_node *node = rb_insert(t->tp, new_node);
    assert(node == NULL);

    return 0;
}

int epoll_rbtree_replace(int epfd, int fd, struct epoll_event *event) {
    struct epfd_tree t_search = {.epfd = epfd, .tp = NULL};
    struct epfd_tree *t = ll_find(epfd_list, &t_search);
    if (!t)
        return -1;

    struct tree_node *new_node = malloc(sizeof(*new_node));
    if (!new_node) {
        errno = ENOMEM;
        return -1;
    }

    new_node->fd = fd;
    memcpy(&new_node->event, event, sizeof(*event));

    struct tree_node *node = rb_replace(t->tp, new_node);
    assert(node);

    free(node);
    return 0;
}

struct epoll_event *epoll_rbtree_find(int epfd, int fd) {
    struct epfd_tree t_search = {.epfd = epfd, .tp = NULL};
    struct epfd_tree *t = ll_find(epfd_list, &t_search);
    if (!t)
        return NULL;

    struct tree_node node_search = {.fd = fd};
    struct tree_node *node = rb_find(t->tp, &node_search);
    return &node->event;
}

int epoll_rb_tree_delete(int epfd, int fd) {
    struct epfd_tree t_search = {.epfd = epfd, .tp = NULL};
    struct epfd_tree *t = ll_find(epfd_list, &t_search);
    if (!t)
        return -1;

    struct tree_node node_search = {.fd = fd};
    struct tree_node *node = rb_delete(t->tp, &node_search);
    assert(node);

    free(node);

    return 0;
}

int epoll_rbtree_destroy(int epfd) {
    struct epfd_tree t_search = {.epfd = epfd, .tp = NULL};
    struct epfd_tree *t = ll_delete(epfd_list, &t_search);
    if (!t)
        return -1;

    rb_destroy(t->tp, tree_node_free);
    free(t);
    --epfd_list_len;
    return 0;
}