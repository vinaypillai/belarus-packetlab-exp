#!/bin/bash


LD_PRELOAD=$('pwd')/../pktlab_libc.so gdb ./example


