#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <arpa/inet.h>

#include <sys/time.h>

#include <stdbool.h>

#define BUFSZ 0x10000

typedef struct addrinfo addrinfo;

int main(int argc, char **argv) {
    int test_num;
    printf("Select one test: 1) simple test 2) getaddrinfo 3) custom test \n "
           "4) sendto test 5) select test 6) wrapper test");
    scanf("%d", &test_num);

    switch (test_num) {
    case 1: {
        int rv;
        struct sockaddr_in servaddr;

        int sockfd = socket(AF_INET, SOCK_STREAM, 0);
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(10001);
        if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) ==
            -1) {
            close(sockfd);
            perror("client: connect");
            exit(1);
        }
        char buf[BUFSZ];
        strncpy(buf, "HELO\n", 5);
        buf[5] = '\0';
        struct timeval t1, t2;
        gettimeofday(&t1, 0);
        if ((rv = send(sockfd, buf, 6, 0)) != 6) {
            close(sockfd);
            perror("client:send");
            exit(1);
        }
        memset(buf, 0, sizeof(buf));
        if ((rv = recv(sockfd, buf, sizeof(buf), 0)) == -1) {
            perror("client: recv");
            exit(1);
        }
        gettimeofday(&t2, 0);
        buf[rv] = '\0';
        printf("%s", buf);
        printf("send time: %ld.%06ld\n", t1.tv_sec, t1.tv_usec);
        printf("recv time: %ld.%06ld\n", t2.tv_sec, t2.tv_usec);
        close(sockfd);
    } break;

    case 2: {
        int rv;
        struct addrinfo hints, *servinfo;
        servinfo = NULL;
        memset(&hints, 0, sizeof(hints));
        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_DGRAM;
        char str[16];

        if ((rv = getaddrinfo("0.us.pool.ntp.org", "ntp", &hints, NULL)) != 0) {
            fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
            return 1;
        }
        while (servinfo) {
            inet_ntop(AF_INET,
                      &(((struct sockaddr_in *)(servinfo->ai_addr))->sin_addr),
                      str, INET_ADDRSTRLEN);
            printf("address is: %s\n", str);
            servinfo = servinfo->ai_next;
        }
    } break;

    case 3: {
        int rv;
        struct sockaddr_in servaddr;

        int sockfd = socket(AF_INET, SOCK_STREAM, 0);
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("128.174.246.14");
        servaddr.sin_port = htons(5900);
        if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) ==
            -1) {
            close(sockfd);
            perror("client: connect");
            exit(1);
        }
        char buf[BUFSZ];
        strncpy(buf, "HELO\n", 5);
        buf[5] = '\0';
        if ((rv = send(sockfd, buf, 6, 0)) != 6) {
            close(sockfd);
            perror("client:send");
            exit(1);
        }
        memset(buf, 0, sizeof(buf));
        if ((rv = recv(sockfd, buf, sizeof(buf), 0)) == -1) {
            perror("client: recv");
            exit(1);
        }
        buf[rv] = '\0';
        printf("%s", buf);

        close(sockfd);
    } break;
    case 4: {
        // sendto and recvfrom test
        int rv;
        struct sockaddr_in servaddr;

        int sockfd = socket(AF_INET, SOCK_DGRAM, 0);

        char buf[BUFSZ];
        strncpy(buf, "HELO\n", 5);
        buf[5] = '\0';

        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(10001);
        socklen_t sz = sizeof(servaddr);

        if ((rv = sendto(sockfd, buf, 5, 0, (struct sockaddr *)&servaddr,
                         sizeof(servaddr)) != 5)) {
            perror("sendto");
            return -1;
        }

        rv = recvfrom(sockfd, buf, 5, 0, (struct sockaddr *)&servaddr, &sz);
        printf("rv: %d\n", rv);
        for (int i = 0; i < rv; ++i) {
            printf("%c", buf[i]);
        }
        puts("");

        rv = recvfrom(sockfd, buf, 100, 0, (struct sockaddr *)&servaddr, &sz);
        printf("rv: %d\n", rv);
        for (int i = 0; i < rv; ++i) {
            printf("%c", buf[i]);
        }
        puts("");
        // servaddr.sin_addr.s_addr = inet_addr("127.0.0.2");
        // if ((rv = sendto(sockfd, buf, 5, 0, (struct sockaddr*)&servaddr,
        // sizeof(servaddr)) != 5)) {
        //     perror("sendto");
        //     return -1;
        // }
        return 0;
    } break;
    case 5: {
        // select test
        int rv;
        struct sockaddr_in servaddr;

        int sockfd = socket(AF_INET, SOCK_DGRAM, 0);

        char buf[BUFSZ];
        strncpy(buf, "HELO\n", 5);
        buf[5] = '\0';

        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(10001);
        socklen_t sz = sizeof(servaddr);

        if ((rv = sendto(sockfd, buf, 5, 0, (struct sockaddr *)&servaddr,
                         sizeof(servaddr)) != 5)) {
            perror("sendto");
            return -1;
        }

        fd_set fs;
        FD_ZERO(&fs);
        struct timeval time_zero;
        time_zero.tv_sec = 0;
        time_zero.tv_usec = 0;
        while (true) {
            FD_SET(sockfd, &fs);
            rv = select(sockfd + 1, &fs, NULL, NULL, NULL);
            if (rv)
                break;
        }
        rv = recvfrom(sockfd, buf, 100, 0, (struct sockaddr *)&servaddr, &sz);
        printf("rv: %d\n", rv);
        for (int i = 0; i < rv; ++i) {
            printf("%c", buf[i]);
        }
        puts("");

    } break;
    case 6: {
        // wrapper test
        int rv;
        struct sockaddr_in servaddr;

        int sockfd = socket(AF_INET, SOCK_STREAM, 0);
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(10001);
        if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) ==
            -1) {
            close(sockfd);
            perror("client: connect");
            exit(1);
        }
        break;
    }
    default: { int sockfd = socket(AF_INET, SOCK_DGRAM, 0); } break;
    }

    puts("Main ends");

    return 0;
}