#include "include/getnameinfo.h"
#include "include/getaddrinfo.h"
#include "include/pktlab_libc.h"
#include "pktlab_util/pktlab_ops.h"
#include <netdb.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <assert.h>
#include <inttypes.h>
#include <netinet/in.h>
#include <resolv.h>
#include <stdlib.h>

#define DNS_QUERY_SIZE 512
#define HOSTNAME_LEN 128

#define IPV4_PTR_POSTFIX ".in-addr.arpa"

int getnameinfo(const struct sockaddr *addr, socklen_t addrlen, char *host,
                socklen_t hostlen, char *serv, socklen_t servlen, int flags) {
    INIT_HEADER();
    if (!addr)
        return EAI_AGAIN;

    if (flags &
        ~(NI_NUMERICHOST | NI_NUMERICSERV | NI_NOFQDN | NI_NAMEREQD | NI_DGRAM))
        return EAI_BADFLAGS;
    if (addr == NULL || addrlen < sizeof(sa_family_t))
        return EAI_FAMILY;
    if ((flags & NI_NAMEREQD) && host == NULL && serv == NULL)
        return EAI_NONAME;

    if (addr->sa_family == AF_INET) {
        if (addrlen < sizeof(struct sockaddr_in))
            return EAI_FAMILY;
        const struct sockaddr_in *addr_in = (const struct sockaddr_in *)addr;
        if (serv) {
            struct servent *s = getservbyport(
                addr_in->sin_port, (flags & NI_DGRAM) ? "udp" : "tcp");
            if (s) {
                strncpy(serv, s->s_name, servlen);
                serv[servlen - 1] = '\0'; // guarantee null termination
                if (servlen < strlen(s->s_name) + 1)
                    return EAI_OVERFLOW;
            } else {
                return EAI_FAIL;
            }
        }

        if (host) {
            // construct query
            char query_name[32];
            struct in_addr reversed_in_addr = {
                .s_addr = __builtin_bswap32(addr_in->sin_addr.s_addr)};
            strcpy(query_name, inet_ntoa(reversed_in_addr));
            strcat(query_name, IPV4_PTR_POSTFIX);
            size_t buf_size = DNS_QUERY_SIZE;
            uint8_t *query_buf = malloc(buf_size);
            if (!query_buf)
                return EAI_MEMORY;
            int query_buf_sz;
            while ((query_buf_sz =
                        res_mkquery(QUERY, query_name, C_IN, T_PTR, NULL, 0,
                                    NULL, query_buf, buf_size)) == -1) {
                query_buf = realloc(query_buf, 2 * buf_size);
                if (!query_buf)
                    return EAI_MEMORY;
                buf_size *= 2;
            }
            uint16_t tran_id = *((uint16_t *)query_buf);

            uint8_t dns_serv_cnt = pl_get_ipv4_dns_server_count();
            if (dns_serv_cnt == 0) {
                free(query_buf);
                return EAI_FAIL;
            }

            // query only the first one
            // TODO: query other dns server if the first fails?
            struct sockaddr_in dns_addr;
            dns_addr.sin_family = AF_INET;
            dns_addr.sin_port = htons(53);
            pl_get_ipv4_dns_server_addr(0, &(dns_addr.sin_addr),
                                        sizeof(dns_addr.sin_addr));
            // using UDP to send the query
            int sock = socket(AF_INET, SOCK_DGRAM, 0);
            if (connect(sock, (struct sockaddr *)&dns_addr, sizeof(dns_addr))) {
                perror("connect:");
                free(query_buf);
                close(sock);
                return EAI_AGAIN;
            }
            ssize_t sent = send(sock, query_buf, query_buf_sz, 0);
            if (sent != query_buf_sz) {
                free(query_buf);
                close(sock);
                return EAI_AGAIN;
            }
            free(query_buf);

            // recv resp
            char *resp_buf = malloc(DNS_QUERY_SIZE);
            if (!resp_buf) {
                close(sock);
                return EAI_MEMORY;
            }
            size_t resp_buf_size = DNS_QUERY_SIZE;
            ssize_t recved = recv(sock, resp_buf, DNS_QUERY_SIZE, 0);
            while (recved == resp_buf_size) {
                resp_buf = realloc(resp_buf, 2 * resp_buf_size);
                if (!resp_buf) {
                    close(sock);
                    return EAI_MEMORY;
                }
                recved +=
                    recv(sock, resp_buf + resp_buf_size, resp_buf_size, 0);
                resp_buf_size *= 2;
            }
            close(sock);
            assert(tran_id == *(uint16_t *)resp_buf);

            // parse response
            struct dns_header *header = (struct dns_header *)resp_buf;
            size_t reader = sizeof(*header);
            assert(header->qr == 1); // response
            switch (header->rcode) {
            case 0:
                break;
            case 1:
                return EAI_AGAIN;
            case 2:
                return EAI_AGAIN;
            case 3:
                if (flags & NI_NAMEREQD)
                    return EAI_NONAME;
                else {
                    // return the ipaddress as host
                    char *hostname = inet_ntoa(addr_in->sin_addr);
                    strncpy(host, hostname, hostlen);
                    host[hostlen - 1] = '\0';
                    if (hostlen < strlen(hostname) + 1)
                        return EAI_OVERFLOW;
                    return 0;
                }
            case 4:
                return EAI_FAIL;
            default:
                break;
            }
            // skip query section
            for (int i = 0; i < ntohs(header->qdcount); ++i) {
                reader += dns_peek_name(resp_buf + reader);
                reader += sizeof(struct query_section);
            }

            // answer resource section
            for (int i = 0; i < ntohs(header->ancount); ++i) {
                reader += dns_peek_name(resp_buf + reader);
                struct rr_section *rr_rec =
                    (struct rr_section *)(resp_buf + reader);
                reader += sizeof(*rr_rec);

                switch (ntohs(rr_rec->rrtype)) {
                case T_PTR: {
                    int rv = dns_decode_name(resp_buf, reader, host, hostlen);
                    if (rv) {
                        free(resp_buf);
                        return EAI_OVERFLOW;
                    }
                    return 0;
                }
                default:
                    reader += ntohs(rr_rec->data_len);
                    break;
                }
            }
            free(resp_buf);
        }
    } else {
        return EAI_FAMILY;
    }

    return 0;
}