#ifndef _PKTLAB_LIBC_EPOLL_H
#define _PKTLAB_LIBC_EPOLL_H

#include <sys/epoll.h>

#define EPOLL_IN_EVENTS (EPOLLIN | EPOLLRDNORM)
#define EPOLL_OUT_EVENTS (EPOLLOUT | EPOLLWRNORM)
#define EPOLL_SUP_EVENTS (EPOLL_IN_EVENTS | EPOLL_OUT_EVENTS)

typedef struct epoll_node {
    int fd;
    struct epoll_event event;
} epoll_node_t;

typedef int (*libc_epoll_create_t)(int size);
typedef int (*libc_epoll_ctl_t)(int epfd, int op, int fd,
                                struct epoll_event *event);
typedef int (*libc_epoll_wait_t)(int epfd, struct epoll_event *events,
                                 int maxevents, int timeout);
#endif