#ifndef _PKTLAB_LIBC_FCNTL_H
#define _PKTLAB_LIBC_FCNTL_H
#include <fcntl.h>
#include <unistd.h>

typedef int (*libc_fcntl_t)(int fd, int cmd, ... /* arg */);
// F_GETFD

#endif