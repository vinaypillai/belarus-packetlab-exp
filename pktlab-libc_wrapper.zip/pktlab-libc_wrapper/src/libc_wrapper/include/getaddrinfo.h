#ifndef _PKTLAB_LIBC_GETADDRINFO_H
#define _PKTLAB_LIBC_GETADDRINFO_H
#define _GNU_SOURCE
#include <netdb.h>
#include <stddef.h>

// typedef for original libc function calls
typedef int (*libc_getaddrinfo_t)(const char *node, const char *service,
                                  const struct addrinfo *hints,
                                  struct addrinfo **res);
typedef void (*libc_freeaddrinfo_t)(struct addrinfo *res);

#define DNS_QUERY_SIZE 512
#define RR_NAME_SIZE 128

// function signatures
struct dns_header {
    unsigned qid : 16;

#if (defined BYTE_ORDER && BYTE_ORDER == BIG_ENDIAN) ||                        \
    (defined __sun && defined _BIG_ENDIAN)
    unsigned qr : 1;
    unsigned opcode : 4;
    unsigned aa : 1;
    unsigned tc : 1;
    unsigned rd : 1;

    unsigned ra : 1;
    unsigned unused : 3;
    unsigned rcode : 4;
#else
    unsigned rd : 1;
    unsigned tc : 1;
    unsigned aa : 1;
    unsigned opcode : 4;
    unsigned qr : 1;

    unsigned rcode : 4;
    unsigned unused : 3;
    unsigned ra : 1;
#endif

    unsigned qdcount : 16;
    unsigned ancount : 16;
    unsigned nscount : 16;
    unsigned arcount : 16;
} __attribute__((packed)); /* struct dns_header */

struct query_section {
    uint16_t qtype;
    uint16_t qclass;
} __attribute__((packed));

struct rr_section {
    uint16_t rrtype;
    uint16_t rrclass;
    uint32_t ttl;
    uint16_t data_len;
} __attribute__((packed));

static const struct addrinfo default_hints = {.ai_flags =
                                                  (AI_V4MAPPED | AI_ADDRCONFIG),
                                              .ai_family = PF_UNSPEC,
                                              .ai_socktype = 0,
                                              .ai_protocol = 0,
                                              .ai_addrlen = 0,
                                              .ai_addr = NULL,
                                              .ai_canonname = NULL,
                                              .ai_next = NULL};

// return number of bytes qname occupies starting at buf
static int dns_peek_name(char *buf) {
    size_t offset = 0;
    while (buf[offset]) {
        // name compression
        // a pointer must be the end of the name
        if ((buf[offset] & 0xc0) == 0xc0) {
            return offset + 2;
        }
        offset += buf[offset] + 1;
    }
    return ++offset;
}

static int dns_decode_name(char *dns_resp, size_t qname_offset, char *buf,
                           size_t buflen) {
    size_t offset = qname_offset;
    size_t buf_offset = 0;
    while (dns_resp[offset]) {
        if ((dns_resp[offset] & 0xc0) == 0xc0) {
            return dns_decode_name(
                dns_resp,
                (size_t)(ntohs(*(uint16_t *)(dns_resp + offset)) & 0x3f),
                buf + buf_offset, buflen - buf_offset);
        }
        uint8_t cnt = dns_resp[offset];
        // conservative estimate of buffer size
        if (cnt + 1 >= buflen - buf_offset)
            return -1;
        ++offset;
        for (uint8_t i = 0; i < cnt; ++i)
            buf[buf_offset++] = dns_resp[offset++];
        if (dns_resp[offset])
            buf[buf_offset++] = '.';
    }
    if (buf_offset < buflen) {
        buf[buf_offset++] = '\0';
        return 0;
    }
    return -1;
}

#endif