#ifndef _PKTLAB_LIBC_LOCK_H
#define _PKTLAB_LIBC_LOCK_H

#include "include/pktlab_libc.h"
#include <pthread.h>

struct pktlab_lock {
    pthread_mutex_t send_mtx;
    pthread_mutex_t recv_mtx;
    pthread_cond_t cv;
    volatile int send_ctr;
    volatile int recv_ctr;
};

extern struct pktlab_lock *pl_lock;

extern void pl_lock_init();
extern void pl_lock_destroy();
extern void pl_lock_send_lock(int *ctr);
extern void pl_lock_send_unlock();
extern void pl_lock_recv_lock(const int *ctr);
extern void pl_lock_recv_unlock();

#endif // _PKTLAB_LIBC_LOCK_H