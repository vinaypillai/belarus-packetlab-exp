#ifndef _PKTLAB_LIBC_POLL_H
#define _PKTLAB_LIBC_POLL_H
#include <poll.h>

typedef int (*libc_poll_t)(struct pollfd *fds, nfds_t nfds, int timeout);

#endif