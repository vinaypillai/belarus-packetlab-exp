#include "include/pktlab_libc.h"
#include "include/file.h"
#include "include/pktlab_libc_lock.h"
#include "include/pktlab_stat.h"
#include "pktlab_util/pktlab_ntp.h"
#include "pktlab_util/pktlab_ops.h"
#include "pktlab_util/pktlab_util.h"

#include <errno.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>

// dl handle
void *handle = NULL;
int me_socket = 0;

// is fd used by the wrapper
pl_socket_t **fd_map = NULL;
static int fd_max = 0;

static void debug_break() __attribute__((unused));
static void debug_break() { return; }

void sigint_handler(int sig) {
    if (fd_map)
        destroy_wrapper();
    exit(1);
}

void init_wrapper(void) {
    info("init wrapper");
    handle = dlopen("libc.so.6", RTLD_LOCAL | RTLD_LAZY);
    if (!handle)
        exit(-1);
    // make connection with the measurement endpoint
    if (!me_socket) {
#if PKTLAB_PIPED
        me_socket = pl_connect("127.0.0.1", PKTLAB_EC_PORT);
#else
        me_socket = pl_connect("127.0.0.1", PKTLAB_ME_PORT);
#endif
        pl_create_reader_writer(me_socket);
    }

    // intialize bitmap
    if (!fd_map) {
        // FIXME: system dependent
        FILE *fptr = fopen("/proc/sys/fs/file-max", "r");
        if (!fptr) {
            exit(-1);
        }
        fscanf(fptr, "%d", &fd_max);
        fclose(fptr);
        fd_map = calloc(fd_max, sizeof(*fd_map));
        if (!fd_map)
            exit(-1);
    }

    pl_lock_init();

// TODO:
#ifdef PKTLAB_NTP
    // perform ntp between endpoint and controller
    // ntpserver
    pl_ntp_server_run();
    // ntpclient
    pl_ntp_client_run();
#endif

    // set up atexit or on_exit
    atexit(destroy_wrapper);
    struct sigaction action;
    memset(&action, 0, sizeof(action));
    action.sa_handler = sigint_handler;
    sigaction(SIGINT, &action, NULL);
}

static void free_fd_map() {
    // free bytemap
    // FIXME: free socket struct pointed by fdmap
    if (fd_map) {
        for (int i = 0; i < fd_max; ++i) {
            if (fd_map[i]) {
                free_pl_socket(fd_map[i]);
                fd_map[i] = NULL;
            }
        }
        free(fd_map);
        fd_map = NULL;
    }
}

void destroy_wrapper(void) {
    static int enter = 0;
    if (!enter)
        enter = 1;
    else
        return;
    info("Destroy wrapper");

    free_fd_map();
    // close the connection to me
    LIBC_ORIG(close)(me_socket);
    pl_destroy_reader_writer();
    pl_lock_destroy();

    if (handle)
        dlclose(handle);
    handle = 0;
    stat_print_summary();
}
