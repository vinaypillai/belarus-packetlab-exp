#include "include/pktlab_stat.h"

// FIXME: warning when overflow happens
// record overflow
static uint64_t bytes_send = 0;
static uint64_t bytes_recv = 0;
double total_rtt = 0;
uint32_t rtt_n = 0;

void stat_add_byte_send(uint32_t num) { bytes_send += num; }

void stat_add_byte_recv(uint32_t num) { bytes_recv += num; }

void stat_add_rtt_point(const struct timeval *t1, const struct timeval *t2) {
    total_rtt += pktlab_timeval_to_time(t2) - pktlab_timeval_to_time(t1);
    ++rtt_n;
}

void stat_print_summary(void) {
#ifdef PKTLAB_SUMMARY
    printf("---->PACKETLAB WRAPPER SUMMARY BEGIN<-----\n");
    printf("Total bytes sent: %lu\n", bytes_send);
    printf("Total bytes received: %lu\n", bytes_recv);
    printf("No. of RTT data points: %u\n", rtt_n);
    printf("Average EC-ME RTT: %lf msec\n", total_rtt / rtt_n / 1000000);
    printf("---->PACKETLAB WRAPPER SUMMARY END<-----\n");
#endif
}
