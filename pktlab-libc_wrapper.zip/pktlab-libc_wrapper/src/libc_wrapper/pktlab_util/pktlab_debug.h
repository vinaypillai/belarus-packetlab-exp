#ifndef _PKTLAB_DEBUG_H
#define _PKTLAB_DEBUG_H
#include "include/pktlab_libc.h"
#include <stddef.h>

#define DEBUG_LABEL "DEBUG"
#define TRACE_LABEL "TRACE"
#define FATAL_LABEL "FATAL"
#define WARN_LABEL "WARN"
#define INFO_LABEL "INFO"
#define ERROR_LABEL "ERROR"

#ifdef DEBUG
#define debug(...)                                                             \
    pktlab_wrapper_print_(__FILE__, __LINE__, DEBUG_LABEL, __VA_ARGS__)
#else
#define debug(...)                                                             \
    do {                                                                       \
    } while (0)
#endif

#ifdef TRACE
#define trace(...)                                                             \
    pktlab_wrapper_print_(__FILE__, __LINE__, TRACE_LABEL, __VA_ARGS__)
#else
#define trace(...)                                                             \
    do {                                                                       \
    } while (0)
#endif

#define fatal(...)                                                             \
    do {                                                                       \
        pktlab_wrapper_print_(__FILE__, __LINE__, FATAL_LABEL, __VA_ARGS__);   \
        abort();                                                               \
    } while (0)
#define warn(...)                                                              \
    pktlab_wrapper_print_(__FILE__, __LINE__, WARN_LABEL, __VA_ARGS__)
#define info(...)                                                              \
    pktlab_wrapper_print_(__FILE__, __LINE__, INFO_LABEL, __VA_ARGS__)
#define error(...)                                                             \
    pktlab_wrapper_print_(__FILE__, __LINE__, ERROR_LABEL, __VA_ARGS__)

void pl_msg_dump_(struct pktlab_message *msg, size_t size)
    __attribute__((unused));
void print_err_exit(int exit_val, const char *fmt, ...);
void perror_exit(const char *str, int exit_val);
void pl_print_nstat(struct pktlab_message *msg);
void pktlab_wrapper_print_(const char *restrict filename, int lineno,
                           const char *restrict label, const char *restrict fmt,
                           ...);
#endif