#ifndef _PKTLAB_NTP_H
#define _PKTLAB_NTP_H

#include "include/socket.h"

extern struct sockaddr controller_addr;
extern int64_t t_offset;
extern struct timeval tv_offset;
extern bool add_tv_offset;

// server runs on the experiment controller
extern int pl_ntp_server_run();

// client runs on the measurement endpoint
extern int pl_ntp_client_run();

#endif