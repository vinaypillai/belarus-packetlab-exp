#include "pktlab_ops.h"
#include "include/file.h"
#include "include/pktlab_libc_lock.h"
#include "include/pktlab_stat.h"
#include "pktlab_debug.h"
#include "pktlab_ntp.h"
#include "pktlab_util.h"
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <alloca.h>
#include <arpa/inet.h>
#include <dlfcn.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define BUFSZ 0x8000000

#define ADDRSTRLEN 64

#define PROTO_2_ADDRFAM(proto)                                                 \
    (((proto & PKTLAB_NETPROTO_MASK) == PKTLAB_IP4_PROTO) ? AF_INET : AF_INET6)
#define PROTO_2_ADDRLEN(proto)                                                 \
    (((proto & PKTLAB_NETPROTO_MASK) == PKTLAB_IP4_PROTO)                      \
         ? PKTLAB_IPV4_WO_MSK_ADDR_LEN                                         \
         : PKTLAB_IPV6_ADDR_LEN)
#define LIBC_ORIG(func) ((libc_##func##_t)dlsym(handle, #func))

struct pktlab_writer *pl_writer = NULL;
struct pktlab_reader *pl_reader = NULL;



static int create_nopen(struct pktlab_message *msg, uint8_t *addrptr,
                        uint8_t *portptr, uint8_t sktid, uint8_t proto,
                        uint8_t intf, uint32_t rbufsize, uint16_t localport,
                        uint16_t remoteport) {
    uint8_t transproto = proto & PKTLAB_TRANSPORT_MASK;

    msg->type = PKTLAB_NOPEN_MESSAGE;
    msg->nopen.sktid = sktid;
    msg->nopen.proto = proto;
    msg->nopen.intf = intf;
    msg->nopen.rbufsz = rbufsize;

    if (transproto == PKTLAB_TCP_PROTO || transproto == PKTLAB_UDP_PROTO) {
        msg->nopen.addrlen = PROTO_2_ADDRLEN(proto);
        msg->nopen.addrptr = addrptr;

        memcpy(portptr, &localport, sizeof(uint16_t));
        memcpy(portptr + sizeof(uint16_t), &remoteport, sizeof(uint16_t));
        // pktlab_set16n(portptr+sizeof(uint16_t), remoteport);
        msg->nopen.portlen = PKTLAB_PORTLEN_MAX;
        msg->nopen.portptr = portptr;
    }

    return 0;
}

static int pl_create_nopen(struct pktlab_message *msg, uint8_t *addrptr,
                           uint8_t *portptr, uint8_t sktid, uint8_t proto,
                           uint8_t intf, uint32_t rbufsize, uint16_t localport,
                           uint16_t remoteport) {
    if (create_nopen(msg, addrptr, portptr, sktid, proto, intf, rbufsize,
                     localport, remoteport) < 0)
        perror_exit("create_nopen", -1);
    return 0;
}

static int create_nsend(struct pktlab_message *msg, uint8_t sktid,
                        uint8_t proto, uint16_t tidx, pktlab_time_t time,
                        uint32_t len, const void *ptr) {
    msg->type = PKTLAB_NSEND_MESSAGE;
    msg->nsend.sktid = sktid;
    msg->nsend.proto = proto;
    msg->nsend.tidx = tidx;
    msg->nsend.time = time;

    switch (proto & PKTLAB_TRANSPORT_MASK) {
    case PKTLAB_TCP_PROTO:
        msg->nsend.tcp.len = len;
        msg->nsend.tcp.ptr = ptr;
        break;
    case PKTLAB_UDP_PROTO:
        msg->nsend.udp.len = len;
        msg->nsend.udp.ptr = ptr;
        break;
    default:
        return -1;
    }

    return 0;
}

static int pl_create_nsend(struct pktlab_message *msg, uint8_t sktid,
                           uint8_t proto, uint16_t tidx, pktlab_time_t time,
                           uint32_t len, const void *ptr) {
    if (create_nsend(msg, sktid, proto, tidx, time, len, ptr) < 0)
        print_err_exit(-1, "create_nsend: ret -1\n");
    return 0;
}

static int create_mread(struct pktlab_message *msg, uint32_t memaddr,
                        uint32_t bytecnt) {
    if (bytecnt > PKTLAB_MREAD_MAX)
        return -1;

    msg->type = PKTLAB_MREAD_MESSAGE;
    msg->mread.addr = memaddr;
    msg->mread.len = bytecnt;
    return 0;
}

#if PKTLAB_PIPED
int pl_connect(const char *ip, int port) {
    if (ip == NULL) {
        return -1;
    }
    int sock = LIBC_ORIG(socket)(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock < 0)
        perror_exit("socket", -1);
    int on = 1;
    if (LIBC_ORIG(setsockopt)(sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) <
        0)
        perror_exit("setsockopt", -1);

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    if (inet_pton(AF_INET, ip, &addr.sin_addr.s_addr) != 1)
        perror_exit("inet_pton", -1);

    if (LIBC_ORIG(connect)(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0)
        perror_exit("connect", -1);

    return sock;
}
#else
int pl_connect(const char *ip, int port) {
    if (ip == NULL) {
        return -1;
    }

    int welcome_sock = LIBC_ORIG(socket)(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (welcome_sock < 0)
        perror_exit("socket", -1);

    int on = 1;
    if (LIBC_ORIG(setsockopt)(welcome_sock, SOL_SOCKET, SO_REUSEADDR, &on,
                              sizeof(on)) < 0) {
        LIBC_ORIG(close)(welcome_sock);
        perror_exit("setsockopt", -1);
    }

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);
    if (LIBC_ORIG(bind)(welcome_sock, (struct sockaddr *)&addr, sizeof(addr)) <
        0) {
        LIBC_ORIG(close)(welcome_sock);
        perror_exit("bind", -1);
    }

    if (listen(welcome_sock, 0) < 0) {
        LIBC_ORIG(close)(welcome_sock);
        perror_exit("listen", -1);
    }

    socklen_t socklen = sizeof(addr);
    int sock = accept(welcome_sock, (struct sockaddr *)&addr, &socklen);
    if (sock < 0) {
        LIBC_ORIG(close)(welcome_sock);
        perror_exit("accept", -1);
    }

    LIBC_ORIG(close)(welcome_sock);

    if (LIBC_ORIG(setsockopt)(sock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) <
        0) {
        LIBC_ORIG(close)(sock);
        perror_exit("setsockopt", -1);
    }

    char me_addr[ADDRSTRLEN] = {};
    if (inet_ntop(AF_INET, &(addr.sin_addr.s_addr), me_addr,
                  (socklen_t)sizeof(me_addr)) == NULL) {
        LIBC_ORIG(close)(sock);
        perror_exit("inet_ntop", -1);
    }

    info("> Got measurement endpoint connection from %s.", me_addr);

    socklen_t len = sizeof(controller_addr);

    memset(&addr, 0, sizeof(controller_addr));
    if (LIBC_ORIG(getsockname)(sock, &controller_addr, &len) < 0) {
        LIBC_ORIG(close)(sock);
        perror("NTP server getsockname");
        exit(-1);
    }

    char ipbuf[32] __attribute__((unused));
    debug(
        "ip: %s -- port: %d",
        inet_ntop(AF_INET,
                  &(((struct sockaddr_in *)&controller_addr)->sin_addr.s_addr),
                  ipbuf, sizeof(ipbuf)),
        ntohs(addr.sin_port));

    return sock;
}
#endif

void pl_create_reader_writer(int sock) {
    struct pktlab_reader *r = pktlab_create_reader(sock);
    if (r == NULL)
        perror_exit("pktlab_create_reader", -1);
    pl_reader = r;
    struct pktlab_writer *w = pktlab_create_writer(sock);
    if (w == NULL)
        perror_exit("pktlab_create_writer", -1);
    pl_writer = w;
}

void pl_destroy_reader_writer(void) {
    if (pl_reader) {
        free(pl_reader);
        pl_reader = NULL;
    }

    if (pl_writer) {
        free(pl_writer);
        pl_writer = NULL;
    }
}

int pl_nopen(pl_socket_t *pl_sock) {
    // #ifdef LIBC_DEBUG
    //     puts("> Sending nopen msg");
    // #endif

    struct pktlab_message send_msg;
    struct pktlab_message *recv_msg;

    uint8_t sktid = pl_sock->sktid;
    uint8_t proto = PKTLAB_IP4_PROTO;
    if (pl_sock->domain == AF_INET && (pl_sock->type & SOCK_STREAM)) {
        proto |= PKTLAB_TCP_PROTO;
    } else if (pl_sock->domain == AF_INET && (pl_sock->type & SOCK_DGRAM)) {
        proto |= PKTLAB_UDP_PROTO;
    } else {
        warn("Type: %d\n", pl_sock->type);
        warn("Protocol not supported");
        exit(1);
    }
    pl_sock->pktlab_proto = proto;

    uint8_t intf = pl_sock->intf;
    uint32_t rbufsize = BUFSZ;
    uint16_t localport = pl_sock->local_port;
    uint16_t remoteport = pl_sock->remote_port;
    uint8_t ports[PKTLAB_PORTLEN_MAX];

    debug("ip address is: %s",
          inet_ntoa(*(struct in_addr *)(pl_sock->remote_addr)));
    debug("remote port: %lu", pktlab_get16b(&pl_sock->remote_port));

    pl_create_nopen(&send_msg, (void *)&pl_sock->remote_addr, ports, sktid,
                    proto, intf, rbufsize, localport, remoteport);

    int rv = pl_send_n_recv(&send_msg, &recv_msg);

    free(recv_msg);
    return rv;
}

void pl_mread(uint32_t memaddr, uint32_t bytecnt, void *buf) {
    debug("pl_mread: memaddr %x bytecnt %x", memaddr, bytecnt);
    struct pktlab_message send_msg;
    struct pktlab_message *recv_msg;
    struct timeval t1, t2;
    int ctr;
    if (create_mread(&send_msg, memaddr, bytecnt) < 0)
        print_err_exit(-1, "create_mread: ret < 0\n");

    pl_lock_send_lock(&ctr);
    if (pl_try_send(pl_writer, &send_msg) != 1) {
        pl_lock_send_unlock();
        perror_exit("try_send", -1);
    }
    pl_lock_send_unlock();

    pl_lock_recv_lock(&ctr);
    LIBC_ORIG(gettimeofday)(&t1, NULL);
    if (pktlab_read_message(pl_reader, &recv_msg) < 0) {
        pl_lock_recv_unlock(&ctr);
        perror_exit("pktlab_read_message", -1);
    }
    LIBC_ORIG(gettimeofday)(&t2, NULL);
    pl_lock_recv_unlock();

    stat_add_rtt_point(&t1, &t2);

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    }

    switch (recv_msg->type) {
    case PKTLAB_MDATA_MESSAGE:
        if (recv_msg->mdata.len != bytecnt)
            print_err_exit(-1, "Memory data amount not expected: %u\n",
                           recv_msg->mdata.len);
        memcpy(buf, recv_msg->mdata.ptr, bytecnt);
        break;
    case PKTLAB_STATUS_MESSAGE:
        // an error
        print_err_exit(-1, "mread msg received status msg %d\n",
                       recv_msg->status.id);
        break;
    default:
        print_err_exit(-1, "Unknown msg type %d\n", recv_msg->type);
        break;
    }
    free(recv_msg);
}

int pl_nsend(pl_socket_t *pl_sock, const uint8_t *payload, size_t payloadlen) {
    struct pktlab_message send_msg;
    struct pktlab_message *recv_msg = NULL;

    uint8_t sktid = pl_sock->sktid;
    uint16_t tidx = pl_sock->tidx;
    pktlab_time_t time = 0;
    uint8_t proto = pl_sock->pktlab_proto;

    pl_create_nsend(&send_msg, sktid, proto, tidx, time, payloadlen, payload);

    pl_send_n_recv(&send_msg, &recv_msg);

    free(recv_msg);
    return payloadlen;
}

static int create_nclose(struct pktlab_message *msg, uint8_t sktid) {
    msg->type = PKTLAB_NCLOSE_MESSAGE;
    msg->nsend.sktid = sktid;
    return 0;
}

int pl_nclose(pl_socket_t *pl_sock) {
    struct pktlab_message send_msg;
    struct pktlab_message *recv_msg;
    debug("> Sending nclose msg");

    create_nclose(&send_msg, pl_sock->sktid);

    pl_send_n_recv(&send_msg, &recv_msg);

    if (recv_msg == NULL) {
        print_err_exit(-1, "pktlab_read_message: sock EOF\n");
    } else if (recv_msg->status.id != 0) { // only 0 imply success
        print_err_exit(-1, "Status msg %d\n", (int)recv_msg->status.id);
    }

    free(recv_msg);
    return 0;
}

uint8_t pl_get_ipv4_dns_server_count() {
    uint32_t memaddr = 0x10002020;
    uint32_t bytecnt = 0x1;
    uint8_t buf;
    pl_mread(memaddr, bytecnt, &buf);
    return buf;
}

int pl_get_ipv4_dns_server_addr(uint8_t offset, void *buf, size_t buflen) {
    uint32_t memaddr = 0x10002030 + offset * 4;
    uint32_t bytecnt = 0x4;
    if (buflen < bytecnt) {
        print_err_exit(
            -1, "pl_get_ipv4_dns_server: buffer too smaller for server addr\n");
    }
    pl_mread(memaddr, bytecnt, buf);
    return 0;
}

uint8_t pl_get_ipv4_list() {
    uint32_t memaddr = 0x10000000;
    uint32_t bytecnt = 0x1;

    uint8_t cnt;
    pl_mread(memaddr, bytecnt, &cnt);

    memaddr = 0x10000100;
    bytecnt = 8 * cnt;

    uint8_t buf[8 * 256];

    pl_mread(memaddr, bytecnt, buf);

    debug("-->Content<--");

    for (size_t j = 0; j < cnt; ++j) {
        char str[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, buf + j * 8, str, INET_ADDRSTRLEN);
        debug("%s", str);
    }
    return cnt;
}
