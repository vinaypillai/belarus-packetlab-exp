#ifndef _PKTLAB_SOCKET_H
#define _PKTLAB_SOCKET_H
#include "pktlab.h"
#include "include/time.h"



typedef enum pl_socket_state {
    PL_SOCKET_STATE_RESET = 0,
    PL_SOCKET_STATE_OPEN,
    PL_SOCKET_STATE_CONNECTED,
    PL_SOCKET_STATE_RECVED // has received 1+ messages on this socket; only
                           // useful for uncon socket
} pl_socket_state_t;

typedef enum pl_socket_type {
    PL_SOCKET_TYPE_DEFAULT,
    PL_SOCKET_TYPE_CON,
    PL_SOCKET_TYPE_UNCON,
} pl_socket_type_t;

typedef struct pl_socket_t {
    uint8_t sktid;
    uint8_t intf;
    uint16_t tidx;
    // an array of file descriptors currently refering to this pl socket
    // int* fd;
    int fd_size;
    int n_ref; // impl1: number of fds referring to this pl_sock

    int fd;
    // all parameters for socket call
    int domain;
    int type;
    int protocol;
    // pktlab protocol
    uint8_t pktlab_proto;
    // local port
    // remote address port
    uint16_t local_port;
    uint16_t remote_port;
    char remote_addr[16];
    // options flags?

    // timestamps
    pktlab_time_t ec_send_time, me_send_time, me_recv_time, ec_recv_time;
    bool send_flag; // flag to make sure sendtime is set at entry

    // buffer for received but not delivered messages
    char *buf;
    size_t buf_len;
    size_t buf_size;
    size_t buf_off; // reading offset

    pl_socket_state_t state;
    bool is_bound; // should be used together with state to determine whether it
                   // is bound to an address
    gettime_state_t time_state;
    pl_socket_type_t pl_type;
    size_t bytes_recved;
    size_t bytes_delivered;

    // TODO: lock this socket struct

} pl_socket_t;


extern void pl_sock_reset_time(pl_socket_t *pl_sock);
extern void pl_sock_init(pl_socket_t *pl_sock);
extern void free_pl_socket(pl_socket_t *pl_sock);

#define N_SKTID 256

extern pl_socket_t* sktid_plsock_map[N_SKTID];

extern uint8_t pl_get_sktid(pl_socket_t *pl_sock);
extern void pl_release_sktid(pl_socket_t *pl_sock);

#endif
