#ifndef _PKTLAB_UTIL_H
#define _PKTLAB_UTIL_H

#include "pktlab_socket.h"
#include "pktlab.h"

int pl_try_send(struct pktlab_writer *w, const struct pktlab_message *msg);
enum pktlab_status pl_send_n_recv(const struct pktlab_message *send_msg,
                                  struct pktlab_message **recv_msg);
void pl_set_tcpquickack(void);
void pl_mread_send_time(pl_socket_t *pl_sock);
pktlab_time_t libc_orig_pktlab_time_now();


#endif