#include "include/pktlab_libc.h"

#include "include/poll.h"
#include "include/time.h"
#include "pktlab_util/pktlab_ops.h"

#include <assert.h>
#include <errno.h>
#include <string.h>

#define MAX_TIMEOUT_SEC 0
#define MAX_TIMEOUT_USEC 5000

// some libraries use __poll_chk rather than poll
// they share the same interface and have the same functionality
// simply wrap this function as well
// similar to https://github.com/dmtcp/dmtcp/issues/241
int __poll_chk(struct pollfd *fds, nfds_t nfds, int timeout) {
    return poll(fds, nfds, timeout);
}

int __poll(struct pollfd *fds, nfds_t nfds, int timeout) {
    return poll(fds, nfds, timeout);
}

// timeout is in milliseconds
// only a limited set of events is handled
// POLLIN, POLLOUT, POLLRDNORM, POLLWRNORM
// priority band data and exception flags are ignored
int poll(struct pollfd *fds, nfds_t nfds, int timeout) {
    if (!fd_map || !fds || !nfds)
        return ((libc_poll_t)dlsym(RTLD_NEXT, "poll"))(fds, nfds, timeout);
    uint32_t timeout_sec, timeout_usec;
    struct timeval time_expire, time_cur, timeout_rem, timeout_tv;
    struct timeval timeout_max = {.tv_sec = MAX_TIMEOUT_SEC,
                                  .tv_usec = MAX_TIMEOUT_USEC};
    LIBC_ORIG(gettimeofday)(&time_cur, NULL);
    bool blocking = false;
    if (timeout < 0) {
        blocking = true;
        timeout_sec = MAX_TIMEOUT_SEC;
        timeout_usec = MAX_TIMEOUT_USEC;
    } else {
        millisec_to_timeval(timeout, &timeout_tv);
        timeradd(&time_cur, &timeout_tv, &time_expire);
        if (timeout < MAX_TIMEOUT_SEC * MILLI_PER_SEC +
                          MAX_TIMEOUT_USEC / MICRO_PER_MILLI) {
            timeout_sec = timeout / MILLI_PER_SEC;
            timeout_usec = timeout % MILLI_PER_SEC * MICRO_PER_MILLI;
        } else {
            timeout_sec = MAX_TIMEOUT_SEC;
            timeout_usec = MAX_TIMEOUT_USEC;
        }
    }

    // scan fds, are there any pl_sockets?
    for (nfds_t i = 0; i < nfds; ++i) {
        int fd = fds[i].fd;
        if (fd < 0)
            continue;
        if (fd_map[fd])
            break;
        else if (i == nfds - 1) {
            return LIBC_ORIG(poll)(fds, nfds, timeout);
        }
    }

    // for making poll call
    struct pollfd *fds_internal = malloc(sizeof(*fds_internal) * nfds);
    if (!fds_internal) {
        errno = ENOMEM;
        return -1;
    }
    nfds_t nfds_internal = 0;

    // lookup from sktid to corresponding pollfd query struct
    struct pollfd **pl_lookup = NULL;
    pl_lookup = calloc(N_SKTID, sizeof(*pl_lookup));
    if (!pl_lookup) {
        free(fds_internal);
        errno = ENOMEM;
        return -1;
    }

    struct pollfd me_sock_pollfd = {.fd = me_socket, .events = 0, .revents = 0};

    bool npoll_flag = false;
    bool poll_me_flag = false;

    int fd_ready = 0;

    for (nfds_t i = 0; i < nfds; ++i) {
        int fd = fds[i].fd;
        fds[i].revents = 0;
        if (fd < 0)
            continue;
        pl_socket_t *pl_sock = fd_map[fd];
        if (fd_map[fd]) {
            pl_lookup[pl_sock->sktid] = &fds[i];
            assert(pl_sock->fd == fd);
            me_sock_pollfd.events |= fds[i].events;
            poll_me_flag = true;
            if ((fds[i].events & (POLLIN | POLLRDNORM)) &&
                fd_map[fd]->buf_len) {
                fds[i].revents |= (fds[i].events & (POLLIN | POLLRDNORM));
                ++fd_ready;
            }
        } else {
            memcpy(&fds_internal[nfds_internal], &fds[i], sizeof(*fds));
            ++nfds_internal;
        }
    }

    if (fd_ready) {
        free(fds_internal);
        free(pl_lookup);
        return fd_ready;
    }

    npoll_flag = !!(me_sock_pollfd.events & (POLLIN | POLLRDNORM));

    if (poll_me_flag) {
        memcpy(&fds_internal[nfds_internal], &me_sock_pollfd,
               sizeof(me_sock_pollfd));
        ++nfds_internal;
    }

    int ctr;
    while (true) {
        if (npoll_flag) {
#ifdef PKTLAB_FIFO
            pl_send_npoll_fifo(timeout_sec, timeout_usec, &ctr);
#else
            pl_send_npoll(timeout_sec, timeout_usec);
#endif
            fd_ready = LIBC_ORIG(poll)(fds_internal, nfds_internal, -1);
        } else {
            fd_ready = LIBC_ORIG(poll)(fds_internal, nfds_internal, timeout);
        }

        if (fd_ready < 0) {
            // if poll is interrupted by a signal, it will return -1 here
            // without poll cancel, we have two choices
            // 1. wait for the npoll to return here
            // 2. set a flag to signal a pending poll, call recv_npoll before
            // doing anything else with the me next time
            if (npoll_flag)
#ifdef PKTLAB_FIFO
                pl_recv_npoll_fifo(NULL, NULL, 0, &ctr);
#else
                pl_recv_npoll(NULL, NULL, 0);
#endif

            free(fds_internal);
            free(pl_lookup);

            return fd_ready;
        }
        if (fd_ready) {
            // check me_sock_pollfd
            struct pollfd *me_sock_pollfd_ptr =
                &fds_internal[nfds_internal - 1];
            if (me_sock_pollfd_ptr->revents) {
                --fd_ready;

                // possible write through pl_sockets
                if (me_sock_pollfd_ptr->revents & (POLLOUT | POLLWRNORM)) {
                    for (nfds_t i = 0; i < nfds; ++i) {
                        if (fds[i].fd >= 0 && fd_map[fds[i].fd]) {
                            fds[i].revents |=
                                (fds[i].events & (POLLOUT | POLLWRNORM));
                            ++fd_ready;
                        }
                    }
                }
            }

            // check if there are fd's ready other than the me_socket
            int fds_base = 0;
            for (nfds_t i = 0; i < nfds_internal; ++i) {
                int fd = fds_internal[i].fd;
                if (!fds_internal[i].revents || fd == me_socket)
                    continue;
                for (int j = fds_base; j < nfds; ++j) {
                    if (fd == fds[j].fd) {
                        fds[j].revents |= fds_internal[i].revents;
                        fds_base = j + 1;
                        break;
                    }
                }
            }
        }

        // parse the npoll msg if necessary
        if (npoll_flag) {
#ifdef PKTLAB_FIFO
            fd_ready += pl_parse_npoll_poll_fifo(pl_lookup, &ctr);
#else
            fd_ready += pl_parse_npoll_poll(pl_lookup);
#endif
        }

        if (fd_ready || !npoll_flag) {
            free(fds_internal);
            free(pl_lookup);
            return fd_ready;
        }

        // handle remaining timeout
        if (blocking)
            continue;

        LIBC_ORIG(gettimeofday)(&time_cur, NULL);
        // expired
        if (!timercmp(&time_cur, &time_expire, <)) {
            free(fds_internal);
            free(pl_lookup);
            return fd_ready;
        }

        timersub(&time_expire, &time_cur, &timeout_rem);
        if (timercmp(&timeout_rem, &timeout_max, <)) {
            timeout_sec = timeout_rem.tv_sec;
            timeout_usec = timeout_rem.tv_usec;
        } else {
            timeout_sec = MAX_TIMEOUT_SEC;
            timeout_usec = MAX_TIMEOUT_USEC;
        }
    }
}