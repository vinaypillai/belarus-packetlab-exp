#include "include/pktlab_libc.h"

#include "include/select.h"
#include "include/time.h"
#include "pktlab_util/pktlab_ops.h"

#include <string.h>
#include <unistd.h>

#include <assert.h>

#define MAX_TIMEOUT_SEC 0
#define MAX_TIMEOUT_USEC 500000

// merge fd_set2 into fd_set1
#define FD_MERGE(fdsetp1, fdsetp2)                                             \
    do {                                                                       \
        for (int __i = 0;                                                      \
             __i < sizeof(*(fdsetp1)) / sizeof(__FDS_BITS(fdsetp1)[0]);        \
             ++__i) {                                                          \
            __FDS_BITS(fdsetp1)[__i] |= __FDS_BITS(fdsetp2)[__i];              \
        }                                                                      \
    } while (0)

/*
readfds: call npoll on the fd if exist, otherwise call libc select
writefds: if a pktlab socket, call select on me_socket, otherwise call libc
select exceptfds: not handled (directly go to libc select)

Any timeout less than MAX_TIMEOUT_SEC will be issued directly through npoll
timeout t/o values larger than that will be divided to 5 second intervals
*/

int select(int nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds,
           struct timeval *timeout) {
    if (!fd_map)
        return ((libc_select_t)dlsym(RTLD_NEXT, "select"))(
            nfds, readfds, writefds, exceptfds, timeout);
    trace("select");
    uint32_t timeout_sec, timeout_usec;
    struct timeval time_expire, time_cur, timeout_rem;
    struct timeval timeout_max = {.tv_sec = MAX_TIMEOUT_SEC, .tv_usec = 0};
    LIBC_ORIG(gettimeofday)(&time_cur, NULL);
    bool blocking = false;
    if (!timeout) {
        blocking = true;
        timeout_sec = MAX_TIMEOUT_SEC;
        timeout_usec = 0;
    } else {
        timeradd(&time_cur, timeout, &time_expire);
        if (timercmp(timeout, &timeout_max, <)) {
            timeout_sec = timeout->tv_sec;
            timeout_usec = timeout->tv_usec;
        } else {
            timeout_sec = MAX_TIMEOUT_SEC;
            timeout_usec = MAX_TIMEOUT_USEC;
        }
    }

    int nfds_internal = 0;
    fd_set readfds_internal, writefds_internal, exceptfds_internal;
    FD_ZERO(&readfds_internal);
    FD_ZERO(&writefds_internal);
    FD_ZERO(&exceptfds_internal);

    fd_set readfds_pl, writefds_pl, exceptfds_pl;
    FD_ZERO(&readfds_pl);
    FD_ZERO(&writefds_pl);
    FD_ZERO(&exceptfds_pl);

    int pl_write_num, pl_except_num;
    pl_write_num = pl_except_num = 0;

    int fd_ready = 0;
    bool npoll_flag = false;

    for (int fd = 0; fd < nfds; ++fd) {
        if (readfds && FD_ISSET(fd, readfds)) {
            if (fd_map[fd] && fd_map[fd]->state >= PL_SOCKET_STATE_CONNECTED) {
                if (fd_map[fd]->buf_len) {
                    ++fd_ready;
                } else {
                    FD_CLR(fd, readfds);
                    FD_SET(me_socket, &readfds_internal);
                    FD_SET(fd, &readfds_pl);
                    nfds_internal =
                        me_socket > nfds_internal ? me_socket : nfds_internal;
                    npoll_flag = true;
                }
            } else {
                FD_CLR(fd, readfds);
                FD_SET(fd, &readfds_internal);
                nfds_internal = fd > nfds_internal ? fd : nfds_internal;
            }
        }

        if (writefds && FD_ISSET(fd, writefds)) {
            if (fd_map[fd] && fd_map[fd]->state >= PL_SOCKET_STATE_CONNECTED) {
                FD_CLR(fd, writefds);
                FD_SET(me_socket, &writefds_internal);
                FD_SET(fd, &writefds_pl);
                ++pl_write_num;
                nfds_internal =
                    me_socket > nfds_internal ? me_socket : nfds_internal;
            } else {
                FD_CLR(fd, writefds);
                FD_SET(fd, &writefds_internal);
                nfds_internal = fd > nfds_internal ? fd : nfds_internal;
            }
        }

        if (exceptfds && FD_ISSET(fd, exceptfds)) {
            if (fd_map[fd] && fd_map[fd]->state >= PL_SOCKET_STATE_CONNECTED) {
                FD_CLR(fd, exceptfds);
                FD_SET(me_socket, &exceptfds_internal);
                FD_SET(fd, &exceptfds_pl);
                ++pl_except_num;
                nfds_internal =
                    me_socket > nfds_internal ? me_socket : nfds_internal;

            } else {
                FD_CLR(fd, exceptfds);
                FD_SET(fd, &exceptfds_internal);
                nfds_internal = fd > nfds_internal ? fd : nfds_internal;
            }
        }
    }

    if (fd_ready) {
        return fd_ready;
    }

    ++nfds_internal;
    int ctr;
    while (true) {
        if (npoll_flag) {
#ifdef PKTLAB_FIFO
            pl_send_npoll_fifo(timeout_sec, timeout_usec, &ctr);
#else
            pl_send_npoll(timeout_sec, timeout_usec);
#endif
            FD_SET(me_socket, &readfds_internal);
            fd_ready = LIBC_ORIG(select)(
                nfds_internal, readfds ? &readfds_internal : NULL,
                writefds ? &writefds_internal : NULL,
                exceptfds ? &exceptfds_internal : NULL, NULL);
        } else {
            fd_ready = LIBC_ORIG(select)(
                nfds_internal, readfds ? &readfds_internal : NULL,
                writefds ? &writefds_internal : NULL,
                exceptfds ? &exceptfds_internal : NULL, timeout);
        }

        // parse the returned fds from select
        if (fd_ready > 0) {
            if (writefds && FD_ISSET(me_socket, &writefds_internal)) {
                FD_CLR(me_socket, &writefds_internal);
                FD_MERGE(&writefds_internal, &writefds_pl);
                --fd_ready;
                fd_ready += pl_write_num;
            }

            if (exceptfds && FD_ISSET(me_socket, &exceptfds_internal)) {
                FD_CLR(me_socket, &exceptfds_internal);
                FD_MERGE(&exceptfds_internal, &exceptfds_pl);
                --fd_ready;
                fd_ready += pl_except_num;
            }
        }

        if (readfds && npoll_flag) {
            // wait for npoll msg to return
            if (FD_ISSET(me_socket, &readfds_internal)) {
                FD_CLR(me_socket, &readfds_internal);
                --fd_ready;
            }
#ifdef PKTLAB_FIFO
            fd_ready += pl_parse_npoll_select_fifo(&readfds_internal,
                                                   &readfds_pl, &ctr);
#else
            fd_ready += pl_parse_npoll_select(&readfds_internal, &readfds_pl);
#endif
        }

        // return if one of the two is true:
        // 1. there's fd ready
        // 2. the readfds doesn't contain any pl_sockets, so we can directly
        // return
        if (fd_ready || !npoll_flag) {
            if (readfds)
                memcpy(readfds, &readfds_internal, sizeof(*readfds));
            if (writefds)
                memcpy(writefds, &writefds_internal, sizeof(*writefds));
            if (exceptfds)
                memcpy(exceptfds, &exceptfds_internal, sizeof(*exceptfds));
            return fd_ready;
        }

        // if nothing ready, check timeout
        if (blocking) {
            continue;
        }

        LIBC_ORIG(gettimeofday)(&time_cur, NULL);
        // expired
        if (!timercmp(&time_cur, &time_expire, <)) {
            // FIXME: are these memcpy needed?
            if (readfds)
                memcpy(readfds, &readfds_internal, sizeof(*readfds));
            if (writefds)
                memcpy(writefds, &writefds_internal, sizeof(*writefds));
            if (exceptfds)
                memcpy(exceptfds, &exceptfds_internal, sizeof(*exceptfds));
            return fd_ready;
        }

        timersub(&time_expire, &time_cur, &timeout_rem);
        if (timercmp(&timeout_rem, &timeout_max, <)) {
            timeout_sec = timeout_rem.tv_sec;
            timeout_usec = timeout_rem.tv_usec;
        } else {
            timeout_sec = MAX_TIMEOUT_SEC;
            timeout_usec = MAX_TIMEOUT_USEC;
        }
    }
}