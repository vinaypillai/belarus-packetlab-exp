#include "include/socket.h"
#include "include/file.h"
#include "include/pktlab_libc.h"
#include "include/pktlab_stat.h"
#include "include/time.h"
#include "pktlab_util/pktlab_ops.h"
#include "pktlab_util/pktlab_util.h"
#include <errno.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>

#define NPOLL_TIMEOUT_SEC 1
#define NPOLL_TIMEOUT_USEC 0

// created to do time offsets
int last_op_sock = 0;

static inline bool is_same_remote(pl_socket_t *pl_sock,
                                  const struct sockaddr_in *addr) {
    if (pl_sock->remote_port == addr->sin_port &&
        !memcmp(pl_sock->remote_addr, &addr->sin_addr.s_addr,
                sizeof(in_addr_t))) {
        return true;
    }
    return false;
}

int socket(int domain, int type, int protocol) {
    INIT_HEADER();
    // vector1 doesn't provide ipv6 support
    // the wrapper doesn't either
    int fd = LIBC_ORIG(socket)(domain, type, protocol);
    if (fd == -1) {
        return -1;
    }

    if (domain != AF_INET) {
        return fd;
    }

    pl_socket_t *pl_sock = malloc(sizeof(*pl_sock));
    if (!pl_sock) {
        close(fd);
        return -1;
    }
    memset(pl_sock, 0, sizeof(*pl_sock));

    fd_map[fd] = pl_sock;
    pl_sock->fd = fd;
    pl_sock->domain = domain;
    pl_sock->type = type;
    pl_sock->protocol = protocol;
    pl_sock_init(pl_sock);
    pl_sock->n_ref = 1;
    pl_sock->state = PL_SOCKET_STATE_OPEN;
    last_op_sock = fd;
    return fd;
}

int connect(int socket, const struct sockaddr *address, socklen_t address_len) {
    INIT_HEADER();
    if (!fd_map[socket]) {
        return -1;
    }

    if (!address) {
        return -1;
    }

    pl_socket_t *pl_sock = fd_map[socket];
    // FIXME: call connect on an originally unconnected socket
    if (pl_sock->pl_type == PL_SOCKET_TYPE_DEFAULT) {
        pl_sock->pl_type = PL_SOCKET_TYPE_CON;
    }

    if (pl_sock->type == PL_SOCKET_TYPE_CON &&
        pl_sock->state != PL_SOCKET_STATE_OPEN) {
        errno = EADDRINUSE;
        return -1;
    }
    sa_family_t family = address->sa_family;
    if (family == AF_INET) {
        const struct sockaddr_in *address_in =
            (const struct sockaddr_in *)address;
        if (sizeof(*address_in) != address_len) {
            // FIXME: some errno
            return -1;
        }
        // FIXME: hardcoded address sequence
        pl_sock->intf = ((address_in->sin_addr.s_addr & 0x000000ff) == 127)
                            ? 1
                            : 0; // public ip intf
        pl_sock->sktid = pl_get_sktid(pl_sock);
        pl_sock->tidx = (uint16_t)pl_sock->sktid;
        memcpy(pl_sock->remote_addr, &(address_in->sin_addr.s_addr),
               sizeof(in_addr_t));
        if (address_in->sin_port != 0) {
            pl_sock->remote_port = address_in->sin_port;
            enum pktlab_status ret = pl_nopen(pl_sock);
            if (!ret)
                pl_sock->state = PL_SOCKET_STATE_CONNECTED;
            else
                pl_release_sktid(pl_sock);
            return ret;
        }

        // hacky fix
        // if the remote port is 0
        // loop through a range of ports, pick the one which doesn't return
        // BADPORT make sure local and remote port are the same
        for (uint16_t p = 20000; p < 21000; ++p) {
            pl_sock->remote_port = htons(p);
            pl_sock->local_port = htons(p);
            enum pktlab_status ret = pl_nopen(pl_sock);
            if (ret == PKTLAB_BADPORT)
                continue;
            if (!ret)
                pl_sock->state = PL_SOCKET_STATE_CONNECTED;
            else
                pl_release_sktid(pl_sock);
            return ret;
        }
    }
    errno = EAFNOSUPPORT;
    return -1;
}

ssize_t recv(int socket, void *buffer, size_t length, int flags) {
    // flags handled: MSG_PEEK
    INIT_HEADER();
    if (!fd_map[socket]) {
        return LIBC_ORIG(recv)(socket, buffer, length, flags);
    }
    if (!buffer) {
        return -1;
    }
    ssize_t cnt = 0;
    // TODO: flags
    pl_socket_t *pl_sock = fd_map[socket];
    bool poll = true;
    // FIXME: revise logic
    if (pl_sock->buf_len > 0) {
        poll = false;
        if (length > pl_sock->buf_len - pl_sock->buf_off) {
            memcpy(buffer, pl_sock->buf + pl_sock->buf_off,
                   pl_sock->buf_len - pl_sock->buf_off);
            cnt += pl_sock->buf_len - pl_sock->buf_off;
            if (!(flags & MSG_PEEK)) {
                pl_sock->buf_len = 0;
                pl_sock->buf_off = 0;
            }

        } else {
            memcpy(buffer, pl_sock->buf + pl_sock->buf_off, length);
            cnt = length;
            if (!(flags & MSG_PEEK)) {
                pl_sock->buf_off += length;
                if (pl_sock->buf_off == pl_sock->buf_len) {
                    pl_sock->buf_len = 0;
                    pl_sock->buf_off = 0;
                }
            }
        }
    }
    // need to send npoll message because the data in socket buffer is smaller
    // than the buffer length provided
    if (poll) {
        if (flags & MSG_PEEK) {
            // hacky way to peek: with length == 0
            pl_npoll(pl_sock, (uint8_t *)buffer + cnt, 0, NPOLL_TIMEOUT_SEC,
                     NPOLL_TIMEOUT_USEC);
            size_t cpy_len =
                (length - cnt >= pl_sock->buf_len - pl_sock->buf_off)
                    ? pl_sock->buf_len - pl_sock->buf_off
                    : length - cnt;
            memcpy((char *)buffer + cnt, pl_sock->buf + pl_sock->buf_off,
                   cpy_len);
            cnt += cpy_len;
        } else {
            cnt += pl_npoll(pl_sock, (uint8_t *)buffer + cnt, length - cnt,
                            NPOLL_TIMEOUT_SEC, NPOLL_TIMEOUT_USEC);
        }
    }
    if (cnt != 0) {
        if (pl_sock->time_state == GETTIME_SENT)
            pl_sock->time_state = GETTIME_RECVED;
        pl_sock->state = PL_SOCKET_STATE_RECVED;
        last_op_sock = socket;
    }
    if (!(flags & MSG_PEEK)) {
        pl_sock->bytes_delivered += cnt;
        stat_add_byte_recv(cnt);
    }
    debug("recved %lu bytes", cnt);
    return cnt;
}

ssize_t recvfrom(int socket, void *buffer, size_t length, int flags,
                 struct sockaddr *address, socklen_t *address_len) {
    INIT_HEADER();
    if (!fd_map[socket]) {
        errno = ENOTSOCK;
        return -1;
    }

    if (address && *address_len < 4) {
        errno = EINVAL;
        return -1;
    }

    // check param matches with the connect params
    pl_socket_t *pl_sock = fd_map[socket];
    ssize_t ret = recv(socket, buffer, length, flags);
    if (ret > 0 && address) {
        struct sockaddr_in *address_in = (struct sockaddr_in *)address;
        address_in->sin_family = AF_INET;
        memcpy(&(address_in->sin_addr), pl_sock->remote_addr, 4);
        address_in->sin_port = pl_sock->remote_port;
        // TODO: find out why should it be 16
        *address_len = 16;
    }
    address->sa_family = AF_INET;
    return ret;
}

ssize_t recvmsg(int socket, struct msghdr *message, int flags) {
    INIT_HEADER();

    if (!fd_map[socket]) {
        errno = ENOTSOCK;
        return -1;
    }

    if (message->msg_iovlen != 1) {
        warn("recvmsg msg_iovlen != 1");
    }

    struct sockaddr *address = (struct sockaddr *)message->msg_name;
    // TODO: can directly return without perror
    ssize_t rv;
    if ((rv = recvfrom(socket, message->msg_iov->iov_base,
                       message->msg_iov->iov_len, flags, address,
                       &message->msg_namelen)) == -1) {
        perror("recvmsg");
        return -1;
    }
    return rv;
}

ssize_t send(int socket, const void *message, size_t length, int flags) {
    INIT_HEADER();
    if (!fd_map[socket]) {
        return LIBC_ORIG(send)(socket, message, length, flags);
    }
    if (!message) {
        return -1;
    }
    if (fd_map && fd_map[socket] && !fd_map[socket]->send_flag) {
        fd_map[socket]->send_flag = true;
        fd_map[socket]->ec_send_time = libc_orig_pktlab_time_now();
    }
    // TODO: figure out what does the flags do
    pl_socket_t *pl_sock = fd_map[socket];
    // pl_sock->ec_send_time = libc_orig_pktlab_time_now();
    pl_sock->time_state = GETTIME_SENT;
    int ret = pl_nsend(pl_sock, message, length);
    stat_add_byte_send(ret);
    last_op_sock = socket;
    pl_sock->send_flag = false;
    return ret;
}

ssize_t sendmsg(int socket, const struct msghdr *message, int flags) {
    INIT_HEADER();

    if (fd_map && fd_map[socket] && !fd_map[socket]->send_flag) {
        fd_map[socket]->send_flag = true;
        fd_map[socket]->ec_send_time = libc_orig_pktlab_time_now();
    }

    // TODO: handle cmsg
    if (CMSG_FIRSTHDR(message) != NULL) {
        warn("sendmsg ignored cmsg");
        errno = EOPNOTSUPP;
        return -1;
    }

    ssize_t rv;
    const struct sockaddr *address = (const struct sockaddr *)message->msg_name;
    if (message->msg_namelen != sizeof(*address)) {
        warn("sendmsg unexpected msg_namelen %d", message->msg_namelen);
    }

    if (message->msg_iovlen != 1) {
        warn("sendmsg msg_iovlen != 1");
    }

    if ((rv = sendto(socket, message->msg_iov->iov_base,
                     message->msg_iov->iov_len, flags, address,
                     sizeof(*address))) != message->msg_iov->iov_len) {
        perror("sendmsg");
        return rv;
    }
    return rv;
}

ssize_t sendto(int socket, const void *message, size_t length, int flags,
               const struct sockaddr *dest_addr, socklen_t dest_len) {
    INIT_HEADER();
    // TODO flags are ignored
    // TODO ipv6?
    if (!fd_map[socket]) {
        errno = ENOTSOCK;
        return -1;
    }

    if (fd_map && fd_map[socket] && !fd_map[socket]->send_flag) {
        fd_map[socket]->send_flag = true;
        fd_map[socket]->ec_send_time = libc_orig_pktlab_time_now();
    }

    pl_socket_t *pl_sock = fd_map[socket];

    if (pl_sock->pl_type == PL_SOCKET_TYPE_CON &&
        (pl_sock->state == PL_SOCKET_STATE_CONNECTED ||
         pl_sock->state == PL_SOCKET_STATE_RECVED)) {
        // this error is optional, can simply ignore
        if (dest_addr != 0 || dest_len != 0) {
            errno = EISCONN;
            return -1;
        }
        return send(socket, message, length, flags);
    }

    if (!dest_addr) {
        if (pl_sock->state != PL_SOCKET_STATE_CONNECTED &&
            pl_sock->state != PL_SOCKET_STATE_RECVED) {
            errno = ENOTCONN;
            return -1;
        }
        return send(socket, message, length, flags);
    }

    if (dest_len != sizeof(struct sockaddr_in)) {
        warn("dest_len: %d doesn't match size of sockaddr_in", dest_len);
        return -1;
    }

    // handle socket reuse
    if (pl_sock->pl_type == PL_SOCKET_TYPE_DEFAULT) {
        pl_sock->pl_type = PL_SOCKET_TYPE_UNCON;
    }

    if (pl_sock->pl_type == PL_SOCKET_TYPE_UNCON) {
        const struct sockaddr_in *address_in =
            (const struct sockaddr_in *)dest_addr;
        if (!is_same_remote(pl_sock, address_in)) {
            switch (pl_sock->state) {
            case PL_SOCKET_STATE_CONNECTED: {
                char priv_buf[16];
                warn("sendto new address %s without recv first",
                     inet_ntop(AF_INET, &address_in->sin_addr.s_addr, priv_buf,
                               16));
                // FIXME: socket pool
                pl_nclose(pl_sock);
                pl_release_sktid(pl_sock);
                pl_sock_init(pl_sock);
                pl_sock->state = PL_SOCKET_STATE_OPEN;
                pl_sock->pl_type = PL_SOCKET_TYPE_UNCON;
            } break;
            case PL_SOCKET_STATE_RECVED: {
                pl_mread_send_time(pl_sock);
                pl_nclose(pl_sock);
                pl_release_sktid(pl_sock);
                pl_sock_init(pl_sock);
                pl_sock->state = PL_SOCKET_STATE_OPEN;
                pl_sock->pl_type = PL_SOCKET_TYPE_UNCON;
            } break;
            case PL_SOCKET_STATE_OPEN:
                break;
            default:
                warn("unexpected socket state %d at sendto", pl_sock->state);
                break;
            }
        } else {
            if (pl_sock->state == PL_SOCKET_STATE_RECVED) {
                pl_mread_send_time(pl_sock);
                pl_sock_reset_time(pl_sock);
                pl_sock->state = PL_SOCKET_STATE_CONNECTED;
            }
        }
    }

    // still make a connected socket
    // combining connect and send in a sense

    // connected socket should NOT reach here
    size_t rv;
    if (pl_sock->state == PL_SOCKET_STATE_OPEN) {
        if ((rv = connect(socket, dest_addr, dest_len)) != 0) {
            perror("endpoint connect");
            return rv;
        }
    }

    if ((rv = send(socket, message, length, flags)) != length) {
        perror("endpoint send");
        return rv;
    }
    return rv;
}

int getpeername(int socket, struct sockaddr *address, socklen_t *address_len) {
    if (!fd_map || !fd_map[socket])
        return ((libc_getpeername_t)dlsym(RTLD_NEXT, "getpeername"))(
            socket, address, address_len);

    pl_socket_t *pl_sock = fd_map[socket];
    if (pl_sock->state < PL_SOCKET_STATE_CONNECTED) {
        return ENOTCONN;
    }

    struct sockaddr_in *address_in = (struct sockaddr_in *)address;
    if (*address_len < sizeof(*address_in))
        return EINVAL;
    *address_len = sizeof(*address_in);
    memcpy(&(address_in->sin_addr.s_addr), pl_sock->remote_addr, 4);
    address_in->sin_family = AF_INET;
    address_in->sin_port = pl_sock->remote_port;
    return 0;
}

int getsockname(int socket, struct sockaddr *address, socklen_t *address_len) {
    // TODO: warning msg if called after bind
    if (!handle || !fd_map || !fd_map[socket])
        return ((libc_getsockname_t)dlsym(RTLD_NEXT, "getsockname"))(
            socket, address, address_len);

    pl_socket_t *pl_sock = fd_map[socket];
    if (pl_sock->state >= PL_SOCKET_STATE_CONNECTED) {
        // FIXME: need testing
        struct sockaddr_in *addr_in = (struct sockaddr_in *)address;
        addr_in->sin_family = AF_INET;
        uint32_t skt_off = 0x20000000 + 0x400 * (pl_sock->sktid - 1);
        char ip[16];
        pl_mread(skt_off + 0x010, sizeof(ip), ip);
        pl_mread(skt_off + 0x030, 2, &(addr_in->sin_port));
        return 0;
    }

    if (pl_sock->is_bound) {
        struct sockaddr_in *addr_in = (struct sockaddr_in *)address;
        addr_in->sin_family = AF_INET;
        addr_in->sin_addr.s_addr = 16777343;
        addr_in->sin_port = 0;
        return 0;
    }
    errno = EOPNOTSUPP;
    return -1;
}

int bind(int socket, const struct sockaddr *address, socklen_t address_len) {
    INIT_HEADER();
    pl_socket_t *pl_sock = fd_map[socket];
    if (!pl_sock) {
        return LIBC_ORIG(bind)(socket, address, address_len);
    }

    if (pl_sock->state >= PL_SOCKET_STATE_CONNECTED || pl_sock->is_bound) {
        errno = EINVAL;
        return -1;
    }

    if (address->sa_family != AF_INET) {
        errno = EINVAL;
        return -1;
    }

    // TODO:
    // only allow bind to address_any for now
    // monitoring new tools for future changes

    const struct sockaddr_in *addr_in = (const struct sockaddr_in *)address;
    // 16777343 == 127.0.0.1
    if (addr_in->sin_addr.s_addr != 0 && addr_in->sin_addr.s_addr != 16777343) {
        errno = EINVAL;
        return -1;
    }

    pl_sock->local_port = addr_in->sin_port;
    pl_sock->is_bound = true;
    return 0;
}

int setsockopt(int socket, int level, int option_name, const void *option_value,
               socklen_t option_len) {
    if (!fd_map || !fd_map[socket]) {
        return ((libc_setsockopt_t)dlsym(RTLD_NEXT, "setsockopt"))(
            socket, level, option_name, option_value, option_len);
    }
    return ((libc_setsockopt_t)dlsym(RTLD_NEXT, "setsockopt"))(
        socket, level, option_name, option_value, option_len);
    if (level != IPPROTO_TCP && level != IPPROTO_UDP) {
        errno = EINVAL;
        return -1;
    }
}