#include "include/time.h"
#include "include/pktlab_libc.h"
#include "include/pktlab_stat.h"
#include "include/socket.h"
#include "pktlab_util/pktlab_ntp.h"
#include "pktlab_util/pktlab_util.h"
#include <string.h>

int gettimeofday(struct timeval *tv, struct timezone *tz) {
#ifdef PKTLAB_USE_SYS_TIME
    debug("systime");
    return ((libc_gettimeofday_t)dlsym(RTLD_NEXT, "gettimeofday"))(tv, tz);
#endif
    debug("gettimeofday");
    // handle only tv for now
    if (!handle || !fd_map) {
        return ((libc_gettimeofday_t)dlsym(RTLD_NEXT, "gettimeofday"))(tv, tz);
    }

    int rv = LIBC_ORIG(gettimeofday)(tv, 0);
    if (rv) {
        return rv;
    }

    pl_socket_t *pl_sock = fd_map[last_op_sock];
    if (add_tv_offset)
        timeradd(tv, &tv_offset, tv);
    else
        timersub(tv, &tv_offset, tv);

    if (pl_sock == NULL) {
        debug("gettimeofday sec %ld usec %ld", tv->tv_sec, tv->tv_usec);
        return rv;
    }
    if (pl_sock->time_state == GETTIME_RECVED) {
        if (!pl_sock->me_send_time)
            pl_mread_send_time(pl_sock);
        pktlab_time_t diff = pl_sock->me_recv_time - pl_sock->me_send_time;
        pktlab_time_to_timeval(pl_sock->ec_send_time + diff, tv);
    }
    debug("gettimeofday sec %ld usec %ld", tv->tv_sec, tv->tv_usec);
    return rv;
}

int clock_gettime(clockid_t clk_id, struct timespec *tp) {
#if PKTLAB_USE_SYS_TIME
    debug("systime");
    return ((libc_clock_gettime_t)dlsym(RTLD_NEXT, "clock_gettime"))(clk_id,
                                                                     tp);
#else
    if (!handle || !fd_map) {
        return ((libc_clock_gettime_t)dlsym(RTLD_NEXT, "clock_gettime"))(clk_id,
                                                                         tp);
    }
    debug("clock_gettime");
    int rv = LIBC_ORIG(clock_gettime)(clk_id, tp);
    if (rv)
        return rv;
    pl_socket_t *pl_sock = fd_map[last_op_sock];
    if (pl_sock == NULL) {
        return 0;
    }
    if (pl_sock->time_state == GETTIME_RECVED) {
        if (!pl_sock->me_send_time)
            pl_mread_send_time(pl_sock);
        pktlab_time_t time_now = pl_sock->me_recv_time - pl_sock->me_send_time +
                                 pl_sock->ec_send_time;
        tp->tv_sec = time_now / NANOS_PER_SEC;
        tp->tv_nsec = time_now % NANOS_PER_SEC;
    }
    return rv;
#endif
}

void millisec_to_timeval(int milli, struct timeval *tv) {
    if (milli < 0) {
        tv->tv_sec = 0;
        tv->tv_usec = 0;
        return;
    }

    tv->tv_sec = milli / MILLI_PER_SEC;
    tv->tv_usec = milli % MILLI_PER_SEC * MICRO_PER_MILLI;
}