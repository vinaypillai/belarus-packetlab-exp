// private.c
//

#include "private.h"

#include <stdarg.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#define DEBUG_LABEL "DEBUG"
#define TRACE_LABEL "TRACE"

// 
// EXPORTED FUNCTION DEFINITIONS
// 

void pktlab_debug_ (
	const char * filename, int lineno, const char * fmt, ...)
{
	static char buf[256];
	va_list args;
	
	va_start(args, fmt);
	vsnprintf(buf, sizeof(buf), fmt, args);
	va_end(args);
	
	fprintf(stderr, DEBUG_LABEL " (%s:%d): %s\n", filename, lineno, buf);
}

void pktlab_trace_ (
	const char * filename, int lineno, const char * fmt, ...)
{
	static char buf[256];
	va_list args;
	
	va_start(args, fmt);
	vsnprintf(buf, sizeof(buf), fmt, args);
	va_end(args);
	
	fprintf(stderr, TRACE_LABEL " (%s:%d): %s\n", filename, lineno, buf);
}

void * pktlab_safe_malloc_(size_t size) {
	void * ptr;
	
	ptr = malloc(size);
	
	if (ptr == NULL) {
		perror(NULL);
		exit(EXIT_FAILURE);
		return NULL;
	} else
		return ptr;
}

void * pktlab_safe_calloc_(size_t nelts, size_t eltsz) {
	void * ptr;
	
	ptr = calloc(nelts, eltsz);
	
	if (ptr == NULL) {
		perror(NULL);
		exit(EXIT_FAILURE);
		return NULL;
	} else
		return ptr;
}

void * pktlab_safe_realloc_(void * ptr, size_t size) {
	
	ptr = realloc(ptr, size);
	
	if (ptr == NULL && size > 0) {
		perror(NULL);
		exit(EXIT_FAILURE);
		return NULL;
	} else
		return ptr;
}

char * pktlab_safe_strdup_(const char * str) {
	char * new_str;
	
	new_str = strdup(str);

	if (new_str == NULL) {
		perror(NULL);
		exit(EXIT_FAILURE);
		return NULL;
	} else
		return new_str;
}
