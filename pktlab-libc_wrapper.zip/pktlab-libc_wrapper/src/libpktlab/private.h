// private.h
// 

#ifndef _PRIVATE_H_
#define _PRIVATE_H_

#include <stddef.h>
#include <stdint.h>

#include <pktlab.h>

// 
// EXPORTED MACRO DEFINITIONS
// 

#define GOTO_IF(c,l)	if (c) goto l
#define RETURN_IF(c,v)	if (c) return (v)
#define CONTINUE_IF(c)	if (c) continue
#define BREAK_IF(c)		if (c) break

#define CEIL_MOD(x,m) (((x)+(m)-1)/(m)*(m))
#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

// 
// EXPORTED FUNCTION DECLARATIONS
//

#ifdef DEBUG
#define debug(...) pktlab_debug_(__FILE__, __LINE__, __VA_ARGS__)
#else
#define debug(...) do {} while(0)
#endif

extern void pktlab_debug_ (
	const char * restrict filename, int lineno,
	const char * restrict fmt, ...);

#ifdef TRACE
#define trace(...) pktlab_trace_(__FILE__, __LINE__, __VA_ARGS__)
#else
#define trace(...) do {} while(0)
#endif

extern void pktlab_trace_ (
	const char * restrict filename, int lineno,
	const char * restrict fmt, ...);

extern void * pktlab_safe_malloc_(size_t size);
extern void * pktlab_safe_calloc_(size_t nelts, size_t eltsz);
extern void * pktlab_safe_realloc_(void * ptr, size_t size);
extern char * pktlab_safe_strdup_(const char * str);

//
// SHORTER NAME MACROS
//

#define safe_malloc pktlab_safe_malloc_
#define safe_calloc pktlab_safe_calloc_
#define safe_realloc pktlab_safe_realloc_
#define safe_strdup pktlab_safe_strdup_

#define get8 pktlab_get8
#define get16n pktlab_get16n
#define get24n pktlab_get24n
#define get32n pktlab_get32n
#define get64n pktlab_get64n
#define get16b pktlab_get16b
#define get24b pktlab_get24b
#define get32b pktlab_get32b
#define get64b pktlab_get64b
#define get16l pktlab_get16l
#define get24l pktlab_get24l
#define get32l pktlab_get32l
#define get64l pktlab_get64l

#define set8 pktlab_set8
#define set16n pktlab_set16n
#define set24n pktlab_set24n
#define set32n pktlab_set32n
#define set64n pktlab_set64n
#define set16b pktlab_set16b
#define set24b pktlab_set24b
#define set32b pktlab_set32b
#define set64b pktlab_set64b
#define set16l pktlab_set16l
#define set24l pktlab_set24l
#define set32l pktlab_set32l
#define set64l pktlab_set64l

#define hton16 pktlab_hton16
#define hton32 pktlab_hton32
#define hton64 pktlab_hton64
#define ntoh16 pktlab_ntoh16
#define ntoh32 pktlab_ntoh32
#define ntoh64 pktlab_ntoh64

#endif
