// pktlab/text.c
// 

#include "pktlab.h"

#include <stddef.h>
#include <stdio.h>
#include <errno.h>
#include <inttypes.h>
#include <string.h>

#include "private.h"

// 
// INTERNAL FUNCTION DECLARATIONS
// 

// Message formatters are called by pktlab_format_message to format a
// message of particular type.

typedef int (*message_formatter_t) (
	char * restrict buf, size_t bufsz, 
	const struct pktlab_message * restrict msg);

static int format_raw_message (
	char * restrict buf, size_t bufsz, 
	const struct pktlab_message * restrict msg);

static int format_status_message (
	char * restrict buf, size_t bufsz, 
	const struct pktlab_message * restrict msg);

static int format_mread_message (
	char * restrict buf, size_t bufsz, 
	const struct pktlab_message * restrict msg);

static int format_mdata_message (
	char * restrict buf, size_t bufsz, 
	const struct pktlab_message * restrict msg);

static int format_nopen_message (
	char * restrict buf, size_t bufsz, 
	const struct pktlab_message * restrict msg);

// Helper functions.

static inline int xtoc(int x);

extern void format_xbytes (
	char * restrict buf, const void * restrict ptr, size_t len);

// 
// EXPORTED FUNCTION DECLARATIONS
// 

int pktlab_format_message (
	char * restrict buf, size_t bufsz,
	const struct pktlab_message * restrict msg)
{
	static const message_formatter_t formatters[] = {
		[PKTLAB_UNDEF_MESSAGE]		= &format_raw_message,
		[PKTLAB_STATUS_MESSAGE]		= &format_status_message,
		[PKTLAB_MREAD_MESSAGE]		= &format_mread_message,
		[PKTLAB_MDATA_MESSAGE]		= &format_mdata_message,
		[PKTLAB_NOPEN_MESSAGE]		= &format_nopen_message
	};

	message_formatter_t formatter;
	
	trace("pktlab_format_message(msg:{type:%d})", (int) msg->type);

	if (msg->type < sizeof(formatters) / sizeof(message_formatter_t))
		formatter = formatters[msg->type];
	else
		goto unknown;

	if (formatter == NULL)
		goto unknown;
	
	return formatter(buf, bufsz, msg);

unknown:
	errno = EINVAL;
	return -1;
}

int pktlab_parse_message (
	const char * str, struct pktlab_message * msg, void ** data)
{
	// ...
	return -1;
}

int pktlab_print_message (
	FILE * file, const struct pktlab_message * msg)
{
	// ...
	return -1;
}

int pktlab_scan_message (
	FILE * file, struct pktlab_message * msg, void ** data)
{
	// ...
	return -1;
}

const char * pktlab_status_name(enum pktlab_status status) {
	switch (status) {
	case PKTLAB_SUCCESS: return "SUCCESS";
	case PKTLAB_INTR: return "INTR";
	case PKTLAB_BUSY: return "BUSY";
	case PKTLAB_PORTINUSE: return "PORTINUSE";
//	case PKTLAB_PKT2LATE: return "PKT2LATE";
	case PKTLAB_PKT2BIG: return "PKT2BIG";
	case PKTLAB_BUF2BIG: return "BUF2BIG";
	case PKTLAB_UNIMPL: return "UNIMPL";
	case PKTLAB_UNKMSG: return "UNKMSG";
	case PKTLAB_BADMSG: return "BADMSG";
	case PKTLAB_UNXPMSG: return "UNXPMSG";
	case PKTLAB_SKTINUSE: return "SKTINUSE";
	case PKTLAB_BADSKT: return "BADSKT";
	case PKTLAB_BADPROTO: return "BADPROTO";
	case PKTLAB_BADADDR: return "BADADDR";
	case PKTLAB_BADPORT: return "BADPORT";
	default: return "UNKNOWN";
	}
}

const char * pktlab_status_descr (enum pktlab_status status) {
	switch (status) {
	case PKTLAB_SUCCESS: return "Success";
	
	// Non-fatal errors
	case PKTLAB_INTR: return "Interrupted";
	case PKTLAB_BUSY: return "Busy";
	case PKTLAB_PORTINUSE: return "Port not available";
//	case PKTLAB_PKT2LATE: return "Packet too late";
	case PKTLAB_PKT2BIG: return "Packet too large";
	case PKTLAB_BUF2BIG: return "Buffer too large";
	case PKTLAB_UNIMPL: return "Function not implemented";

	// Fatal errors
	case PKTLAB_UNKMSG: return "Unknown message type";
	case PKTLAB_BADMSG: return "Invalid message";
	case PKTLAB_UNXPMSG: return "Unexpected message type";
	case PKTLAB_SKTINUSE: return "Socket is in use";
	case PKTLAB_BADSKT: return "Invalid socket";
	case PKTLAB_BADPROTO: return "Invalid protocol";
	case PKTLAB_BADADDR: return "Invalid address";
	case PKTLAB_BADPORT: return "Invalid port";
	default: return "Unknown fault";
	}
}

const char * pktlab_msgtype_name (enum pktlab_message_type type) {
	static const char * const names[] = {
		[PKTLAB_UNDEF_MESSAGE] = "UNDEF",
		[PKTLAB_STATUS_MESSAGE] = "STATUS",
		[PKTLAB_MREAD_MESSAGE] = "MREAD",
		[PKTLAB_MDATA_MESSAGE] = "MDATA",
		[PKTLAB_NOPEN_MESSAGE] = "NSOCKET",
		[PKTLAB_NCLOSE_MESSAGE] = "NCLOSE",
		[PKTLAB_NPOLL_MESSAGE] = "NPOLL",
		[PKTLAB_NDATA_MESSAGE] = "NDATA",
		[PKTLAB_NSTAT_MESSAGE] = "NSTAT",
		[PKTLAB_NCAP_MESSAGE] = "NCAP",
		[PKTLAB_XSUB_MESSAGE] = "XSUB",
		[PKTLAB_XSTART_MESSAGE] = "XSTART",
		[PKTLAB_XYIELD_MESSAGE] = "XYIELD",
		[PKTLAB_XEND_MESSAGE] = "XEND",
		[PKTLAB_XDESCR_MESSAGE] = "XDESCR",
		[PKTLAB_XFILT_MESSAGE] = "XFILT",
		[PKTLAB_XKEY_MESSAGE] = "XKEY",
		[PKTLAB_XCERT_MESSAGE] = "XCERT"
	};
	
	const char * name = NULL;
	
	if (type < sizeof(names)/sizeof(names[0]))
		name = names[type];
	if (name == NULL)
		name = "UNKNOWN";
	return name;
}

const char * pktlab_sktstate_name(enum pktlab_socket_state state) {
	switch (state) {
	case PKTLAB_SKTST_FREE: return "FREE";
	case PKTLAB_SKTST_OPENING: return "OPENING";
	case PKTLAB_SKTST_OPEN: return "OPEN";
	case PKTLAB_SKTST_EOF: return "EOF";
	case PKTLAB_SKTST_REFUSED: return "REFUSED";
	case PKTLAB_SKTST_RESET: return "RESET";
//	case PKTLAB_SKTST_TIMEOUT: return "TIMEOUT";
	case PKTLAB_SKTST_UNREACH: return "UNREACH";
	default: return "UNKNOWN";
	}
}

// 
// INTERNAL FUNCTION DEFINITIONS
// 

int format_raw_message (
	char * restrict buf, size_t bufsz, 
	const struct pktlab_message * restrict msg)
{
	char msgstr[65];

	if (msg->raw.len > (sizeof(msgstr)-1)/2) {
		return snprintf(buf, bufsz,
			"RAW LEN=%" PRIu32, msg->raw.len);
	} else {
		format_xbytes(msgstr, msg->raw.ptr, msg->raw.len);
		return snprintf(buf, bufsz, "RAW DATA=%s", msgstr);
	}
}

int format_status_message (
	char * restrict buf, size_t bufsz, 
	const struct pktlab_message * restrict msg)
{
	char textbuf[65];

	if (msg->status.textptr != NULL && msg->status.textlen > 0) {
		if (msg->status.textlen < sizeof(textbuf)) {
			memcpy(textbuf, msg->status.textptr, msg->status.textlen);
			textbuf[msg->status.textlen] = '\0';
			return snprintf(buf, bufsz,
				"STATUS ID=%" PRIi16 " TEXT=\"%s\"",
				msg->status.id, textbuf);
		} else
			return snprintf(buf, bufsz,
				"STATUS ID=%" PRIi16 " TEXTLEN=%" PRIu32,
				msg->status.id, msg->status.textlen);
	} else
		return snprintf(buf, bufsz, "STATUS ID=%" PRIi16, msg->status.id);
}

int format_mread_message (
	char * buf, size_t bufsz, const struct pktlab_message * msg)
{
	return snprintf(buf, bufsz,
		"MREAD ADDR=0x%" PRIx32 " LEN=%" PRIu32,
		msg->mread.addr, msg->mread.len);
}

int format_mdata_message (
	char * buf, size_t bufsz, const struct pktlab_message * msg)
{
	char datastr[65];
	
	if (msg->mdata.len > (sizeof(datastr)-1)/2) {
		return snprintf(buf, bufsz,
			"MDATA ADDR=0x%" PRIx32 " LEN=%" PRIu32,
			msg->mdata.addr, msg->mdata.len);
	} else {
		format_xbytes(datastr, msg->mdata.ptr, msg->mdata.len);
		return snprintf(buf, bufsz,
			"MDATA ADDR=0x%" PRIx32 " DATA=%s",
			msg->mdata.addr, datastr);
	}
}

int format_nopen_message (
	char * buf, size_t bufsz, const struct pktlab_message * msg)
{
	uint_fast8_t netproto, transproto;
	uint_fast16_t localport_h, remoteport_h;
	const char * trname;
	char netprch;
	char addrstr[48];
	char portstr[32];

	netproto = msg->nopen.proto & PKTLAB_NETPROTO_MASK;
	transproto = msg->nopen.proto & PKTLAB_TRANSPORT_MASK;

	netprch = '0' + netproto;

	switch (transproto) {
	case PKTLAB_RAW_PROTO:
		switch (netproto) {
		case PKTLAB_IP4_PROTO:
		case PKTLAB_IP6_PROTO:
			return snprintf(buf, bufsz, "NOPEN SKTID=%d RAWPROTO=IP%c",
				(int) msg->nopen.sktid, netprch);
		default:
			return snprintf(buf, bufsz, "NOPEN SKTID=%d RAWPROTO=%c",
				(int) msg->nopen.sktid, netprch);
		}
	case PKTLAB_TCP_PROTO:
		trname = "TCP";
		break;
	case PKTLAB_UDP_PROTO:
		trname = "UDP";
		break;
	case PKTLAB_ICMP_ECHO_PROTO:
		switch (netproto) {
		case PKTLAB_IP4_PROTO:
		case PKTLAB_IP6_PROTO:
			return snprintf(buf, bufsz, "NOPEN SKTID=%d ICMPPROTO=IP%c",
				(int) msg->nopen.sktid, netprch);
		default:
			return snprintf(buf, bufsz, "NOPEN SKTID=%d ICMPPROTO=%c",
				(int) msg->nopen.sktid, netprch);
		}
	default:
		trname = "UNK";
		break;
	}
	
	switch (netproto) {
	case PKTLAB_IP4_PROTO:
		inet_ntop(AF_INET, msg->nopen.addrptr, addrstr, sizeof(addrstr));
		break;
	case PKTLAB_IP6_PROTO:
		inet_ntop(AF_INET6, msg->nopen.addrptr, addrstr, sizeof(addrstr));
		break;
	default:
		snprintf(addrstr, sizeof(addrstr), "ADDRLEN=%d",
			(int) msg->nopen.addrlen);
		break;
	}

	switch (transproto) {
	case PKTLAB_TCP_PROTO:
	case PKTLAB_UDP_PROTO:
		localport_h = get16n(msg->nopen.portptr+0);
		remoteport_h = get16n(msg->nopen.portptr+2);
		snprintf(portstr, sizeof(portstr), "LOCPORT=%u REMPORT=%u",
			(unsigned) localport_h, (unsigned) remoteport_h);
		break;
	default:
		snprintf(portstr, sizeof(portstr), "PORTLEN=%u",
			(unsigned) msg->nopen.portlen);
		break;
	}
	
	return snprintf(buf, bufsz,
		"NOPEN SKTID=%d PROTO=%s%c RBUFSZ=%" PRIu32 " ADDR=%s %s",
		(int) msg->nopen.sktid, trname, netprch, msg->nopen.rbufsz,
		addrstr, portstr);
}

int xtoc(int x) {
	if (0 <= x) {
		if (x < 10)
			return '0' + x;
		if (x < 16)
			return 'a' + x - 10;
	}
	
	return -1;
}

void format_xbytes(char * buf, const void * ptr, size_t len) {
	while (len > 0) {
		*buf++ = xtoc(*(uint8_t*)ptr >> 4);
		*buf++ = xtoc(*(uint8_t*)ptr & 0xf);
		ptr += 1;
		len -= 1;
	}

	*buf = '\0';
}

