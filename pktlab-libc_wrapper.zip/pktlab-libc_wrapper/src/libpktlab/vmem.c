// pktlab/vmem.c
//

#include <string.h>

#include <pktlab.h>

#include "private.h"

// 
// INTERNAL FUNCTION DECLARATIONS
// 

// The find_region function returns an index j with the property that
// 
// (a) there is no i < j such that addr < rgns[i].addr + rgns[j].len and
// (b) there is no i > j such that rgns[i].addr <= addr.
// 
// In particular, this means that if there an region containing addr, then
// its index will be returned. If there is no such region, than the first
// region following the address is returned or rgncnt if there is no such
// region (addr lies beyond last region).

static uint_fast32_t find_region (
	const struct pktlab_vmem_region * rgns, uint_fast32_t rgncnt,
	uint_fast32_t addr);

// 
// EXPORTED FUNCTION DEFINITIONS
// 

void pktlab_vmem_read (
	const struct pktlab_vmem_region * restrict rgn, uint_fast32_t rgncnt,
	uint_fast32_t addr, uint_fast32_t len,	void * restrict dst)
{
	uint_fast32_t start = addr;
	uint_fast32_t end = addr + len;
	uint_fast32_t read_start;
	uint_fast32_t read_end;
	uint_fast32_t read_off;
	uint_fast32_t read_len;
	uint_fast32_t dst_off;
	uint_fast32_t i0;
	uint_fast32_t i;
	
	trace("pktlab_vmem_read(rgncnt:%u, addr:0x%x, len:%u)",
		(unsigned int) rgncnt, (unsigned int) addr, (unsigned int) len);
	
	memset(dst, 0, len);
	
	i0 = find_region(rgn, rgncnt, addr);
	if (addr < rgn[i0].start) // no rgn containing such addr found
		return;
	
	for (i = i0; i < rgncnt && rgn[i].start < end; i++) {
		read_start = (start < rgn[i].start) ? rgn[i].start : start;
		read_end = (rgn[i].end < end) ? rgn[i].end : end;
		read_off = read_start - rgn[i].start;
		read_len = read_end - read_start;
		dst_off = read_start - start;
		
		debug("rgn_read(rgn:{start:0x%x,end:0x%x}, off:%u, len:%u)",
			(unsigned int) rgn[i].start, (unsigned int) rgn[i].end,
			(unsigned int) read_off, (unsigned int) read_len);
		
		rgn[i].read(rgn+i, read_off, read_len, dst + dst_off);
	}
}

void pktlab_vmem_write (
	const struct pktlab_vmem_region * restrict rgn, uint_fast32_t rgncnt,
	uint_fast32_t addr, uint_fast32_t len, const void * restrict src)
{
	uint_fast32_t start = addr;
	uint_fast32_t end = addr + len;
	uint_fast32_t write_start;
	uint_fast32_t write_end;
	uint_fast32_t write_off;
	uint_fast32_t write_len;
	uint_fast32_t src_off;
	uint_fast32_t i0;
	uint_fast32_t i;
	
	trace("pktlab_vmem_write(rgncnt:%u, addr:0x%x, len:%u)",
		(unsigned int) rgncnt, (unsigned int) addr, (unsigned int) len);
	
	i0 = find_region(rgn, rgncnt, addr);
	if (addr < rgn[i0].start) // no rgn containing such addr found
		return;
	
	for (i = i0; i < rgncnt && rgn[i].start < end; i++) {
		write_start = (start < rgn[i].start) ? rgn[i].start : start;
		write_end = (rgn[i].end < end) ? rgn[i].end : end;
		write_off = write_start - rgn[i].start;
		write_len = write_end - write_start;
		src_off = write_start - start;
		
		debug("rgn_write(rgn:{start:0x%x,end:0x%x}, off:%u, len:%u)",
			(unsigned int) rgn[i].start, (unsigned int) rgn[i].end,
			(unsigned int) write_off, (unsigned int) write_len);
		
		rgn[i].write(rgn+i, write_off, write_len, src + src_off);
	}
}

void pktlab_buffer_reader (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict dst)
{
	memcpy(dst, (const void*) rgn->aux + off, len);
}

void pktlab_buffer_writer (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, const void * restrict src)
{
	memcpy((void*) rgn->aux + off, src, len);
}

// 
// INTERNAL FUNCTION DEFINITIONS
// 

uint_fast32_t find_region (
	const struct pktlab_vmem_region * rgn, uint_fast32_t rgncnt,
	uint_fast32_t addr)
{
	uint_fast32_t lo = 0, hi = rgncnt;
	uint_fast32_t i; // lo <= i < hi

	trace("find_region(rgncnt:%u, addr:0x%x)",
		(unsigned int) rgncnt, (unsigned int) addr);
	
	// Find region containing addr or the first region starting after addr.
	// We maintain two loop invariants:
	// 
	// A. There is no i < lo s.t. addr < rgn[i].end.
	// B. There is no i >= hi s.t. addr >= rgn[i].start.
	
	while (hi - lo > 0) {
		i = lo + (hi - lo) / 2;
		if (addr < rgn[i].start)
			hi = i;
		else if (addr < rgn[i].end)
			return i;
		else
			lo = i+1;
	}
	
	return hi;
}
