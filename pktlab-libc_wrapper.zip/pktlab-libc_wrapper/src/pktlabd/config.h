// config.h
// 

#ifndef _CONFIG_H_
#define _CONFIG_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// 
// EXPORTED TYPE DEFINITIONS
// 

struct config {
    long long network_bufmax;
    const char * vmem_laddr_str_v4;
    const char * vmem_laddr_str_v6;
    const char * vmem_ldnsaddr_str_v4;
    const char * vmem_ldnsaddr_str_v6;
    const char * host_id;
};

//
// EXPORTED GLOBAL VARIABLES
//

extern struct config _config;

// 
// EXPORTED FUNCTION DECLARATIONS
// 

extern void config_initialize(void);
extern bool config_read(const char * path);

#endif
