// console.h
// 

#ifndef _CONSOLE_H_
#define _CONSOLE_H_

#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>

#include <pktlab.h>

#define DEBUG_LABEL "DEBUG"
#define TRACE_LABEL "TRACE"
#define FATAL_LABEL "FATAL"
#define WARN_LABEL "WARN"
#define INFO_LABEL "INFO"
#define ERROR_LABEL "ERROR"

// 
// EXPORTED FUNCTION DECLARATIONS
//

#ifdef DEBUG
#define debug(...) pktlabme_print_(__FILE__, __LINE__, DEBUG_LABEL, __VA_ARGS__)
#else
#define debug(...) do {} while(0)
#endif

#ifdef TRACE
#define trace(...) pktlabme_print_(__FILE__, __LINE__, TRACE_LABEL, __VA_ARGS__)
#else
#define trace(...) do {} while(0)
#endif

#define fatal(...) do { pktlabme_print_(__FILE__, __LINE__, FATAL_LABEL, __VA_ARGS__); abort(); } while(0)
#define warn(...) pktlabme_print_(__FILE__, __LINE__, WARN_LABEL, __VA_ARGS__)
#define info(...) pktlabme_print_(__FILE__, __LINE__, INFO_LABEL, __VA_ARGS__)
#define error(...) pktlabme_print_(__FILE__, __LINE__, ERROR_LABEL, __VA_ARGS__)

#define safe_str(str) ((str == NULL) ? "(null)" : str)

extern void pktlabme_print_ (
	const char * restrict filename, int lineno,
	const char * restrict label, 
	const char * restrict fmt, ...);

#endif
