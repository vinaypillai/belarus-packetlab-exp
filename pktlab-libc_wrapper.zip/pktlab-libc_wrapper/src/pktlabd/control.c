// control.c
// 

#include "control.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <netdb.h>

#include "worker.h"
#include "vmem.h"
#include "network.h"
#include "network_util.h"
#include "console.h"
#include "util.h"

// 
// COMPILE-TIME PARAMETERS
// 

#define RECONNECT_DELAY		5		// 5 sec
#define ADDRESS_TTL			3600	// 1 hour
// 
// INTERNAL DATA TYPES
// 

enum state {
	ST_UNKNOWN,
	ST_INIT,
	ST_SLEEP,
	ST_IDLE,
	ST_PAUSED,
	ST_EOF,
	ST_ERROR
};

// 
// INTERNAL GLOBAL VARIABLES
// 

static enum state _state;

static const char * _hoststr = NULL;
static const char * _portstr = NULL;
static struct addrinfo * _addrinfo = NULL;
static pktlab_time_t _addrinfo_expires;
static char _specstr[48];

static int _sockfd = -1;
static struct pktlab_reader * _reader;
static struct pktlab_writer * _writer;
static struct pktlab_message * _msgout = NULL;

static union {
	struct {
		pktlab_time_t expires;
	} sleep;

	struct {
	} connect;

	struct {
		uint32_t cnt;
	} paused;

	struct {
		int8_t id;
	} error;
} _st;

// 
// INTERNAL FUNCTION DEFINITIONS
// 

static void socket_connect(void);
static void socket_tryread(void);
static void socket_trywrite(void);
static void socket_read_error(int err);
static void socket_write_error(int err);

static void handle_message(struct pktlab_message * msg);

static void flush_msgout(void);
static void flush_unsent(void);
static void refresh_addrinfo(void);

static const char * state_name(enum state state) __attribute__ ((unused));

// 
// EXPORTED FUNCTION DEFINITIONS
// 

void control_initialize(void) {
	trace("%s()", __func__);
	_state = ST_INIT;
}

// The control_start function resolves the host name of the control server
// and connects to each address in turn. If all fail, control_start causes
// the program to exit. In the future, we may want to handle this by
// sleeping for some time and then trying again.

void control_start(const char * ctlspec, uint_fast32_t sleep_sec) {
	const char * sptr;
	char * hoststr;
	size_t hostlen;

	trace("%s(state:%s,ctlspec:%s)", __func__, state_name(_state), ctlspec);
	assert(_state == ST_INIT);
	
	sptr = strchr(ctlspec, ',');
	
	if (sptr != NULL) {
		hostlen = sptr - ctlspec;
		hoststr = safe_malloc(hostlen + 1);
		memcpy(hoststr, ctlspec, hostlen);
		hoststr[hostlen] = '\0';
		_hoststr = hoststr;
		_portstr = sptr+1;
	} else {
		_hoststr = ctlspec;
		_portstr = PKTLAB_DEFAULT_PORT_STR;
	}

	_st.sleep.expires = pktlab_time_now() + pktlab_time_sec(sleep_sec);
	_state = ST_SLEEP;
}

// Control communication.

void control_pause(void) {
	trace("%s(state:%s, pausecnt:%u)",
		__func__, state_name(_state), _st.paused.cnt);
	assert (_state == ST_IDLE || _state == ST_PAUSED);
	
	_state = ST_PAUSED;
	_st.paused.cnt += 1;
}

void control_resume(void) {
	trace("%s(state:%s, pausecnt:%u)",
		__func__, state_name(_state), _st.paused.cnt);	
	assert (_state == ST_PAUSED);
	
	_st.paused.cnt -= 1;
	if (_st.paused.cnt == 0)
		_state = ST_IDLE;
}

bool control_send(struct pktlab_message * msg) {
	trace("%s(state:%s, msg{type:%u})",
		__func__, state_name(_state), (unsigned int) msg->type);
	assert (_state == ST_IDLE || _state == ST_PAUSED);

	if (_msgout != NULL)
		return false;
	
	_msgout = msg;
	flush_msgout();
	
	return true;
}

bool control_report(enum pktlab_status status) {
	trace("%s(state:%s, status:%d)", __func__, state_name(_state), status);
	assert (_state == ST_IDLE || _state == ST_PAUSED);

	if (_msgout != NULL)
		return false;
	
	// If the status code is negative, the error is fatal. Change state to
	// error so connection is closed after message is sent.
	
	if (status < 0) {
		_st.error.id = status;
		_state = ST_ERROR;
	}

	_msgout = pktlab_create_status_message(status, NULL);
	flush_msgout();
	return true;
}

void control_reset(void) {
	trace("%s(state:%s)", __func__, state_name(_state));
	
	network_reset();
	
	pktlab_close_reader(_reader);
	_reader = NULL;
	
	pktlab_close_writer(_writer);
	_writer = NULL;

	free(_msgout);
	_msgout = NULL;

	info("%s: Controller connection closed", _specstr);
	close(_sockfd);
	_sockfd = -1;

	memset(_specstr, 0, sizeof(_specstr));

	_state = ST_INIT;
}

bool control_running(void) {
	trace("%s(state:%s): %s", __func__, state_name(_state),
		(_state >= ST_SLEEP) ? "True" : "False");
	if (_state >= ST_SLEEP)
		return true;
	return false;
}

// Select handlers.

int control_prepare_select (
	fd_set * rset, fd_set * wset, pktlab_time_t * select_until)
{	
	trace("%s(state:%s, msgout%c=NULL)", __func__, 
		state_name(_state), (_msgout == NULL) ? '=' : '!');
	
	switch (_state) {
	case ST_INIT:
		return 0;
	
	case ST_SLEEP:
		if (_st.sleep.expires < *select_until)
			*select_until = _st.sleep.expires;
		return 0;
	
	case ST_EOF:
	case ST_ERROR:
		FD_SET(_sockfd, wset);
		return _sockfd+1;

	case ST_IDLE:
		// Make sure we don't have an unsent outgoing message before
		// accepting another one. This is to ensure that we can always send
		// a status message.
		if (_msgout == NULL) {
			if (pktlab_read_message(_reader, NULL))
				*select_until = _time_now;
			else
				FD_SET(_sockfd, rset);
		}
		// fall-through
	
	case ST_PAUSED:
		if (_msgout != NULL || pktlab_writer_unsent(_writer) > 0)
			FD_SET(_sockfd, wset);
		return _sockfd+1;
	default:
		// not reached
		return 0;
	}
}

int control_process_select(int nsel, const fd_set * rset, const fd_set * wset) {
	int nhandled = 0;
	
	trace("%s(state:%s,nsel:%d)", __func__, state_name(_state), nsel);
		
	switch (_state) {
	case ST_INIT:
		return 0;
	
	case ST_SLEEP:
		if (_st.sleep.expires < _time_now)
			socket_connect();
		return 0;
	
	case ST_IDLE:
		if (_msgout == NULL) {
			socket_tryread();
			if (!control_running()) // socket_tryread may reset
				break;

			if (FD_ISSET(_sockfd, rset))
				nhandled += 1;
		}
		// no break

	case ST_PAUSED:
	case ST_EOF:
	case ST_ERROR:
		socket_trywrite();
		if (!control_running()) // socket_trywrite may reset
			break;

		if (FD_ISSET(_sockfd, wset))
			nhandled += 1;
		// no break;
	
	default:
		break;
	}
	
	return nhandled;
}

// 
// INTERNAL FUNCTION DEFINITIONS
// 

void socket_connect(void) {
	char hoststr[42], portstr[6];
	struct addrinfo * next;
	int result;
	
	trace("control:socket_connect(state:%s)", state_name(_state));

	// STEP 1. If our address list is more than ADDR_FRESHNESS seconds old,
	// resolve the host name again.
		
	if (_addrinfo == NULL || _addrinfo_expires < _time_now)
		refresh_addrinfo();
		
	while (_addrinfo != NULL) {
		// STEP 2: Get string representation of current address and store it
		// in _specstr for error reporting.
		
		result = getnameinfo (
			_addrinfo->ai_addr, _addrinfo->ai_addrlen,
			hoststr, sizeof(hoststr), portstr, sizeof(portstr),
			NI_NUMERICHOST | NI_NUMERICSERV);
		
		if (result != 0)
			fatal("%s", gai_strerror(errno));
		
		snprintf(_specstr, sizeof(_specstr), "%s,%s", hoststr, portstr);
		
		// STEP 3: Connect to address.
				
		_sockfd = socket (
			_addrinfo->ai_family,
			_addrinfo->ai_socktype,
			_addrinfo->ai_protocol);
		
		if (_sockfd < 0)
			fatal("%s", strerror(errno));
	
		result = connect(_sockfd, _addrinfo->ai_addr, _addrinfo->ai_addrlen);
		
		if (0 <= result)
			goto success;
	
		// We get here if an error occurred on the connect() call. We treat
		// timeout, connection refused, or network unreachable as non-fatal
		// error and continue. All other errors are fatal. Close socket and
		// free addrinfo structure.
		
		switch (errno) {
		case ETIMEDOUT:
		case ECONNREFUSED:
		case ENETUNREACH:
		case EHOSTUNREACH:
		case ENETDOWN:
			warn("%s: %s", _specstr, strerror(errno));
			break; // and continue loop
		default:
			fatal("%s: %s", _specstr, strerror(errno));
			break;
		}
			
		close(_sockfd);
		_sockfd = -1;
		
		next = _addrinfo->ai_next;
		_addrinfo->ai_next = NULL;
		freeaddrinfo(_addrinfo);
		_addrinfo = next;
	}
		
	// We get here if we go through all the addresses without making a
	// successful connection.
	
	warn("Could not connect to %s,%s; sleeping.", _hoststr, _portstr);
	
	_st.sleep.expires = _time_now + pktlab_time_sec(RECONNECT_DELAY);
	_state = ST_SLEEP;
	
	return;

success:

	// We get here if connect() succeeded. Make socket non-blocking.
	info("%s: Controller socket connected", _specstr);
	
	result = fcntl(_sockfd, F_GETFL);
	
	if (result < 0)
		fatal("%s", strerror(errno));
	
	result = fcntl(_sockfd, F_SETFL, result | O_NONBLOCK);
	
	if (result < 0)
		fatal("%s", strerror(errno));
	
	// Create reader and writer objects.
	
	_reader = pktlab_create_reader(_sockfd);	
	_writer = pktlab_create_writer(_sockfd);

	if (_reader == NULL || _writer == NULL)
		fatal("%s: %s", _specstr, strerror(errno));
	
	if (set_keepalive(_sockfd))
		warn("%s: set TCP keepalive failed (%s)", _specstr, strerror(errno));

	debug("Connected to %s", _specstr);
	_state = ST_IDLE;
	_st.paused.cnt = 0;
}

static void socket_tryread(void) {
	struct pktlab_message * msg;
	int result;
	
	trace("control:%s(state:%s, msgout%c=NULL)",
		__func__, state_name(_state), _msgout ? '!' : '=');

	if (_msgout != NULL)
		return;
	
	result = pktlab_read_message(_reader, &msg);
	
	if (result > 0) {
		if (msg == NULL) { // msg NULL signify EOF
			info("%s: Controller socket read EOF", _specstr);
			_state = ST_EOF;
		} else
			handle_message(msg);
	}
	
	if (result < 0)
		socket_read_error(errno);
}

static void socket_trywrite(void) {
	trace("control:%s(state:%s, msgout%c=NULL)",
		__func__, state_name(_state), _msgout ? '!' : '=');

	if (_msgout != NULL)
		flush_msgout();
	
	else if (_writer != NULL && pktlab_writer_unsent(_writer) > 0)
		flush_unsent();
	
	if (_msgout == NULL && (_writer == NULL || pktlab_writer_unsent(_writer) == 0)) {
		if (_state == ST_ERROR || _state == ST_EOF)
			control_reset();
	}
}

void socket_read_error(int err) {
	switch (err) {
	case ENOTCONN:
		info("%s: Controller disconnected", _specstr);
		break;
	default:
		error("%s: %s", _specstr, strerror(err));
		break;
	}
	
	control_reset();
}

void socket_write_error(int err) {
	switch (err) {
	default:
		error("%s: %s", _specstr, strerror(err));
		break;
	}
	
	control_reset();
}

void handle_message(struct pktlab_message * msg) {
	trace("control:handle_message(state:%s, msg:{type:%d})",
		state_name(_state), (int) msg->type);
	assert(_state == ST_IDLE);
	assert(_msgout == NULL);
	
	switch (msg->type) {
	case PKTLAB_MREAD_MESSAGE:
		vmem_handle_mread(msg);
		return;
	case PKTLAB_MWRITE_MESSAGE:
		vmem_handle_mwrite(msg);
		return;
	case PKTLAB_NOPEN_MESSAGE:
		network_handle_nopen(msg);
		return;
	case PKTLAB_NCLOSE_MESSAGE:
		network_handle_nclose(msg);
		return;
	case PKTLAB_NSEND_MESSAGE:
		network_handle_nsend(msg);
		return;
	case PKTLAB_NPOLL_MESSAGE:
		network_handle_npoll(msg);
		return;
	case PKTLAB_NCAP_MESSAGE:
		network_handle_ncap(msg);
		return;
	case PKTLAB_UNDEF_MESSAGE:
		_st.error.id = msg->raw.malformed ? PKTLAB_BADMSG : PKTLAB_UNKMSG;
		break;
	default:
		_st.error.id = PKTLAB_UNXPMSG;
		break;
	}
	
	// We get here if we received an unknown, unexpected, or malformed
	// message. Generate an error response.
	error("%s: Controller invalid message", _specstr);
	_msgout = pktlab_create_status_message(_st.error.id, NULL);
	_state = ST_ERROR;
	free(msg);
}

static void flush_msgout(void) {
	int result;
	
	trace("control:%s(state:%s, msgout:{type:%d})",
		__func__, state_name(_state), (int) _msgout->type);

	result = pktlab_write_message(_writer, _msgout);
	
	if (result < 0)
		socket_write_error(errno);
	
	if (result == 0)
		return;
	
	free(_msgout);
	_msgout = NULL;
}

void flush_unsent(void) {
	int result;
	
	trace("control:%s(state:%s)", __func__, state_name(_state));

	result = pktlab_flush_writer(_writer);
	
	if (result < 0)
		socket_write_error(errno);
}

void refresh_addrinfo(void) {
	struct addrinfo hints;
	int result;
	
	trace("control:%s(state:%s)", __func__, state_name(_state));

	// Free current sockaddr_list (if not empty).
	
	if (_addrinfo != NULL) {
		freeaddrinfo(_addrinfo);
		_addrinfo = NULL;
	}
	
	// Resolve the host name using getaddrinfo.
	
	memset(&hints, 0, sizeof(hints));
	hints.ai_flags = AI_ADDRCONFIG | AI_NUMERICSERV;
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	
	result = getaddrinfo(_hoststr, _portstr, &hints, &_addrinfo);
	
	if (result < 0 || _addrinfo == NULL)
		fatal("%s,%s: %s", _hoststr, _portstr, gai_strerror(result));
	
	_addrinfo_expires = _time_now + pktlab_time_sec(ADDRESS_TTL);
}
	
const char * state_name(enum state state) {
	static const char * const names[] = {
		[ST_UNKNOWN] = "UNKNOWN",
		[ST_INIT] = "INIT",
		[ST_SLEEP] = "SLEEP",
		[ST_IDLE] = "IDLE",
		[ST_PAUSED] = "PAUSED",
		[ST_EOF] = "EOF",
		[ST_ERROR] = "ERROR"
	};
	
	const char * name = NULL;
	
	if (state < sizeof(names) / sizeof(names[0]))
		name = names[state];
	
	return (name != NULL) ? name : names[ST_UNKNOWN];
}
	
