// control.h
// 

#ifndef _CONTROL_H_
#define _CONTROL_H_

#include <stdbool.h>
#include <stdint.h>
#include <sys/time.h>
#include <sys/select.h>
#include <pktlab.h>

// 
// EXPORTED FUNCTION DECLARATIONS
// 

extern void control_initialize(void);
extern void control_start (
	const char * ctlspec, uint_fast32_t sleep_sec);
extern void control_reset(void);
extern bool control_running(void);

// Control communication.

extern void control_pause(void);
extern void control_resume(void);

extern bool control_send(struct pktlab_message * msg);
extern bool control_report(enum pktlab_status status);

// Select handlers.

extern int control_prepare_select (
	fd_set * restrict rset, fd_set * restrict wset,
	pktlab_time_t * select_until);

extern int control_process_select (int nsel,
	const fd_set * restrict rset, const fd_set * restrict wset);

#endif
