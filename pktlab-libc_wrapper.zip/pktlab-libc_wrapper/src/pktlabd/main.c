// main.c
// 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

#include <pktlab.h>

#include "manager.h"

#define USAGE "pktlabd [ADDR[,PORT]] ..."
#define MECONF_PATH "me.conf" // Should be configured with autoconf

// 
// TYPE DEFINITIONS
//

// ...

// 
// RUN-TIME PARAMETERS
// 

struct {
	const char * const * ctlspecs;
	const char * confpath;
} _args;

// 
// GLOBAL VARIABLES
// 

// ...

// 
// INTERNAL FUNCTION DECLARATIONS
// 

static void initialize(int argc, char * const argv[]);

// 
// MAIN FUNCTION DEFINITION
// 

int main(int argc, char * const argv[]) {
	initialize(argc, argv);
	
	manager_init();
	manager_start(_args.confpath, _args.ctlspecs);
	manager_wait();
	
	exit(EXIT_SUCCESS);
	return 0;
}

// 
// INTERNAL FUNCTION DEFINITIONS
// 

void initialize(int argc, char * const argv[]) {
	static const char * const default_ctlspecs[] = { PKTLAB_DEFAULT_SPEC_STR };
	struct sigaction action;
	int optch;
	
	// Disable SIGPIPE signal; handle broken pipe error on write.
	
	memset(&action, 0, sizeof(action));
	action.sa_handler = SIG_IGN;
	sigaction(SIGPIPE, &action, NULL);
	
	// Close stdin and stdout.
	
	fclose(stdin);
	fclose(stdout);

	// Parse command-line arguments.
	
	while ((optch = getopt(argc, argv, "c:")) != -1) {
		switch (optch) {
		case 'c':
			_args.confpath = optarg;
			break;
		default:
			goto usage_error;
		}
	}
	
	argc -= optind;
	argv += optind;
	
	// set up default option/argument values
	if (argc > 0)
		_args.ctlspecs = (const char * const *) argv;
	else
		_args.ctlspecs = default_ctlspecs;

	if (_args.confpath == NULL)
		_args.confpath = MECONF_PATH;

	return;
	
usage_error:
	fprintf(stderr, "USAGE: " USAGE "\n");
	exit(EXIT_FAILURE);
	return;	
}
