// main.h
//

#ifndef _MAIN_H_
#define _MAIN_H_

#include <pktlab.h>

enum role {
	ROLE_MAIN,
	ROLE_MANAGER,
	ROLE_WORKER
};

extern pktlab_time_t _time_now;
extern enum role _role;

#endif
