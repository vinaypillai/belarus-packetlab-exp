// manager.c
//

#include "manager.h"

#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/wait.h>

#include <pktlab.h>

#include "config.h"
#include "console.h"
#include "util.h"
#include "worker.h"

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

// 
// INTERNAL TYPE DEFINITIONS
// 

struct worker {
	struct worker * next;
	const char * spec;
	int fd;
};

static struct worker * _workers = NULL;
static int _depfd = -1;
static char _confpath[PATH_MAX];

// 
// INTERNAL FUNCTION DECLARATIONS
// 

static void create_deputy(void);
static void create_worker(const char * spec);

static void deputy_start(int mgrfd);
static void wait_workers(void);

static int wait_child(void);

static int sendspec(int depfd, const char * spec);
static int recvspec(int mgrfd, char * buf, size_t bufsz);

static int recvfd(int depfd);
static int sendfd(int mgrfd, int outfd);

// 
// EXPORTED FUNCTION DEFINITIONS
// 

void manager_init(void) {
	trace("%s()", __func__);
	
	// ...
	// TODO:
	//   Implement init static data structures,
	//   and _workers, _depfd clean up functions

}

void manager_start (
	const char * confpath,
	const char * const * specs)
{
	trace("%s(confpath:%s,...)", __func__, safe_str(confpath));

	if (confpath != NULL)
		strncpy(_confpath, confpath, PATH_MAX-1);

	create_deputy();
	
	while (*specs != NULL)
		create_worker(*specs++);
}

void manager_wait(void) {
	int rst, exit_stat = EXIT_SUCCESS;

	trace("%s()", __func__);

	close(_depfd);

	rst = wait_child();
	assert(rst >= -2);

	switch (rst) {
	case -1:
		fatal("Deputy cannot be waited");
		exit_stat = EXIT_FAILURE;
		break;
	case -2:
		warn("Deputy unknown exit stat");
		break;
	default:
		info("Deputy exited with stat: %d", rst);
	}

	exit(exit_stat);
}

// 
// INTERNAL FUNCTION DEFINITIONS
// 

void create_deputy(void) {
	int fds[2];
	int result;
	
	trace("%s()", __func__);

	result = socketpair(AF_LOCAL, SOCK_STREAM, 0, fds);
	perror_exit_if(result < 0, "socketpair");
	
	debug("socketpair() returned {%d,%d}", fds[0], fds[1]);
	
	if (fork()) {
		close(fds[0]);
		_depfd = fds[1];
		return;
	} else {
		close(fds[1]);
		deputy_start(fds[0]);
	}
}

void create_worker(const char * spec) {
	struct worker * worker;
	int result;
	
	trace("%s(spec:\"%s\")", __func__, spec);

	result = sendspec(_depfd, spec);
	if (result < 0)
		exit(EXIT_FAILURE);
	
	result = recvfd(_depfd);
	if (result < 0)
		exit(EXIT_FAILURE);

	worker = safe_calloc(1, sizeof(struct worker));
	worker->spec = spec;
	worker->fd = result;
	worker->next = _workers;
	_workers = worker;
}

void deputy_start(int mgrfd) {
	static char spec[256];
	int fds[2];
	int result;
	
	trace("%s(mgrfd:%d)", __func__, mgrfd);
	debug("deputy PID is %d, PPID is %d", getpid(), getppid());

	config_initialize();
	if (config_read(_confpath))
		fatal("config_read(path:%s) failed", safe_str(_confpath));

	worker_initialize();
	
	while (true) {
		result = recvspec(mgrfd, spec, sizeof(spec));
		if (result == 0) {
			wait_workers();
			exit(EXIT_SUCCESS);
		} else if (result < 0)
			exit(EXIT_FAILURE);
		
		result = socketpair(AF_LOCAL, SOCK_STREAM, 0, fds);
		perror_exit_if(result < 0, "socketpair");

		if (fork()) {
			result = sendfd(mgrfd, fds[1]);
			if (result < 0)
				exit(EXIT_FAILURE);
			
			close(fds[0]);
			close(fds[1]);
			continue;
		} else
			break;
	}
	
	// We get here if we're the worker process. Close descriptors we don't
	// need and enter the worker task.
		
	close(mgrfd);
	close(fds[1]);
	worker_main(fds[0], spec);
	exit(EXIT_SUCCESS);
}

int wait_child(void) {
	int child_stat;

	// return val:
	// >= 0 for child return status
	// -1 for no child left
	// -2 for unknown child exit reason
	// -3 for none POSIX OS behavior

	while (wait(&child_stat) < 0) {
		switch (errno) {
		case ECHILD: // No more child
			return -1;
		case EINTR:
			continue;
		default: // should not happen in POSIX.1-2001
			return -3;
		}
	}

	return WIFEXITED(child_stat) ? WEXITSTATUS(child_stat) : -2;
}

void wait_workers(void) {
	int rst;

	trace("%s()", __func__);

	while ((rst = wait_child()) != -1) {
		assert(rst >= -2);

		if (rst == -2)
			warn("Worker exited with unknown stat");
		else
			info("Worker exited with stat: %d", rst);
	}
}

int sendspec(int depfd, const char * spec) {
	size_t speclen;
	ssize_t size;

	trace("%s(depfd:%d,spec:\"%s\")", __func__, depfd, spec);

	speclen = strlen(spec);
	size = write(depfd, spec, speclen+1);
	
	if (size < 0) {
		if (errno == EPIPE)
			return -1;
		perror(__func__);
		exit(EXIT_FAILURE);
	}
	
	return speclen;
}

int recvspec(int mgrfd, char * buf, size_t bufsz) {
	size_t len = 0;
	char * sptr;
	ssize_t rdlen;
	
	trace("%s(mgrfd:%d,bufsz:%zu)", __func__, mgrfd, bufsz);

	// Receive a null-terminaled string containing spec into buf. We need to
	// loop because a single message on a stream may be split into multiple
	// reads. Since we only send one string at a time, there is no data to
	// buffer for the next read after the null terminator.
	
	do {
		rdlen = read(mgrfd, buf+len, bufsz-len);
		
		if (rdlen <= 0) {
			if (rdlen == 0)
				return 0;
			perror(__func__);
			exit(EXIT_FAILURE);
		}
		
		sptr = memchr(buf+len, '\0', rdlen);
		
		if (sptr != NULL) {
			if (sptr+1 != buf + len + rdlen) {
				perror("recvspec: unexpected data");
				exit(EXIT_FAILURE);
			} else
				return len + rdlen;
		}
	} while ((len += rdlen) < bufsz);
	
	// We get here if the spec string is larger than bufsz. This should never
	// happen, so we panic.
	
	perror("recvspec: buffer overflow");
	exit(EXIT_FAILURE);
}

int recvfd(int depfd) {
	char bytebuf;
	struct iovec iov = { .iov_base = &bytebuf, .iov_len = sizeof(bytebuf) };
	char cmsgbuf[sizeof(struct cmsghdr) + sizeof(int)]; // XXX need to align
	struct cmsghdr * cmsgptr = (void*)cmsgbuf;
	struct msghdr msg;
	ssize_t size;
	int infd;

	memset(&msg, 0, sizeof(msg));
	memset(cmsgbuf, 0, sizeof(cmsgbuf));
	msg.msg_control = cmsgptr;
	msg.msg_controllen = sizeof(cmsgbuf);
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	
	// We expect a 1-byte message containing a descriptor.
	
	size = recvmsg(depfd, &msg, 0);
	
	if (size <= 0) {
		if (size == 0)
			return -1;
		perror(__func__);
		exit(EXIT_FAILURE);
	}	
	
	memcpy(&infd, CMSG_DATA(cmsgptr), sizeof(int));
	return infd;
}

int sendfd(int mgrfd, int outfd) {
	char bytebuf = '\0';
	struct iovec iov = { .iov_base = &bytebuf, .iov_len = sizeof(bytebuf) };
	char cmsgbuf[sizeof(struct cmsghdr) + sizeof(int)]; // XXX need to align
	struct cmsghdr * cmsgptr = (void*)cmsgbuf;
	struct msghdr msg;
	size_t size;

	memset(&msg, 0, sizeof(msg));	
	msg.msg_control = cmsgptr;
	msg.msg_controllen = sizeof(cmsgbuf);
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	
	memset(cmsgbuf, 0, sizeof(cmsgbuf));
	memcpy(CMSG_DATA(cmsgptr), &outfd, sizeof(int));
	cmsgptr->cmsg_len = sizeof(cmsgbuf);
	cmsgptr->cmsg_level = SOL_SOCKET;
	cmsgptr->cmsg_type = SCM_RIGHTS;
	
	size = sendmsg(mgrfd, &msg, MSG_EOR);
	
	if (size < 0) {
		if (errno == EPIPE)
			return -1;
		perror(__func__);
		exit(EXIT_FAILURE);
	} else
		return outfd;
}
