// manager.h
//

#ifndef _MANAGER_H_
#define _MANAGER_H_

// 
// EXPORTED FUNCTION DECLARATIONS
// 

void manager_init(void);
void manager_start (
    const char * confpath,
    const char * const * specs);
void manager_wait(void);

#endif
