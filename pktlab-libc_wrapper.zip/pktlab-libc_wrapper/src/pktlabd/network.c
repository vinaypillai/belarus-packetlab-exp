// network.c
//

#include "network.h"

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <unistd.h>
#include <inttypes.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

#include <pktlab.h>

#include "config.h"
#include "console.h"
#include "control.h"
#include "network_util.h"
#include "nqueue.h"
#include "util.h"
#include "vmem.h"
#include "worker.h"

// TODO Implement buffer usage accounting
// We currently do not account for buffer use, which could lead to memory
// exhaustion. To implement this, we need to do the following:
// 
// 1. Initialize maximum number of bytes used for buffers (_bufmax) at
//    start of experiment.
// 2. Account for all buffer allocations by incrementing _bufused.
// 3. Account for all receive buffer allocations by incrementing
//    skt->rbufused.
// 4. Do not receive on socket if rbufmax <= rbufused.
// 5. Account for all buffer releases by decrementing _bufused and
//    skt->rbufused (receive buffers only).

// 
// COMPILE-TIME CONSTANTS
// 

#ifndef CONNECT_TIMEOUT_MS
#define CONNECT_TIMEOUT_MS 60000
#endif

//
// INTERNAL CONSTANTS
// 

#define SKT_CNT 0x100
#define CTLFL_CNT 0x80
#define TSTP_CNT 0x10000

#define RBUFSIZE_START 0x40
#define CTLFL_START 0x100
#define VMEM_SKT_LEN 0x400

#define NSEND_DELAY_LOG_THRES 1000000 // in ticks

#define DEFAULT_BUFMAX 0x800000
#define BUF_OVERHEAD 0x40

#define UINT24_MAX UINT32_C(0xffffff)

// 
// INTERNAL TYPE DEFINITIONS
// 

struct socket {
	enum pktlab_socket_state state;
	uint8_t netproto;
	uint8_t transproto;
	uint8_t addrlen;
	int fd, err;
	struct nqueue txq;
	uint32_t msgoff;
	uint32_t rbufmax;
	uint32_t rbufused;
	pktlab_time_t open_until;
	uint8_t locaddr[PKTLAB_ADDRLEN_MAX];
	uint8_t remaddr[PKTLAB_ADDRLEN_MAX];
	uint16_t locport, remport;
	struct {
		uint32_t bytecnt;
		uint32_t pktcnt;
	} dropstats;
	uint8_t ctlfl[CTLFL_CNT];
};

enum state {
	ST_UNKNOWN,
	ST_INIT,
	ST_IDLE,
	ST_POLLWAIT,
	ST_POLLFLUSH
};

// 
// INTERNAL GLOBAL VARIABLES
// 

static struct socket _skt[SKT_CNT];
static struct nqueue _rxq;
static enum state _state;
static bool _dropfl; // true if at least one sock has dropped packets
static pktlab_time_t _send_tstp[TSTP_CNT];

static uint32_t _bufmax;
static uint32_t _bufused;

static pktlab_time_t _poll_until;

// 
// INTERNAL FUNCTION DECLARATIONS
// 

static void poll_flush(void);

static void state_change(enum state state);

static void raw_socket_open (
	uint_fast8_t sktid, uint_fast8_t netproto, uint_fast32_t rbufsz);

static void trans_socket_open (
	uint_fast8_t sktid, uint_fast8_t netproto, uint_fast8_t intf,
	uint_fast32_t rbufsz, uint_fast8_t transproto,
	const void * addrptr, uint_fast8_t addrlen,
	uint_fast16_t locport, uint_fast16_t remport);

static void socket_close(uint_fast8_t sktid);

static void socket_readable(uint_fast8_t sktid);
static void socket_writeable(uint_fast8_t sktid);
static void socket_connected(uint_fast8_t sktid);

static void socket_state_change (
	unsigned int sktid, enum pktlab_socket_state state);
//static void inject_null_ndata(uint_fast8_t sktid);

static void clear_dropstats(void);
static struct pktlab_message * create_nstat(void);

static bool freeall_filt(void * ptr, uintptr_t aux);
static bool freesktid_filt(void * ptr, uintptr_t sktid);

static const char * state_name(enum state state) __attribute__ ((unused));

static void skt_read (uint8_t sktid, void * buf);

static void show_skt(void);

// nsend and ndata buffer size should not be larger than 2 ^ 31 - 1 bytes
static int32_t nsend_mem_cal(const struct pktlab_message * restrict msg);
static int32_t ndata_mem_cal(const struct pktlab_message * restrict msg);

static bool have_space(uint_fast8_t sktid);
static uint32_t limited_add(const uint32_t target, const ssize_t incre);

// 
// EXPORTED FUNCTION DEFINITIONS
// 

void network_initialize(void) { // TODO add config file init
	long long conf_bufmax;

	trace("%s()", __func__);

	conf_bufmax = _config.network_bufmax; // should be <= UINT32_MAX and >= -1

	if (conf_bufmax < 0)
		conf_bufmax = DEFAULT_BUFMAX;

	_bufmax = conf_bufmax; // should not overflow
	info("Exporting bufmax: %" PRIu32, _bufmax);

	nqinit(&_rxq);
	_state = ST_INIT;
}

void network_start(void) {
	state_change(ST_IDLE);
}

void network_reset(void) {
	struct socket * skt;
	int sktid;
	
	trace("network_reset(state:%s)", state_name(_state));
	assert(_state > ST_INIT);

	// Close all sockets.
	
	for (sktid = 0; skt = _skt+sktid, sktid <= SKT_CNT; sktid++)
		if (skt->state != PKTLAB_SKTST_FREE)
			socket_close(sktid);
		
	// Free all buffered messages.
	
	while (!nqempty(&_rxq))
		free(nqget(&_rxq));
	
	state_change(ST_INIT);
}

int network_prepare_select (
	fd_set * rset, fd_set * wset, pktlab_time_t * select_until)
{
	struct pktlab_message * msg;
	struct socket * skt;
	unsigned int sktid;
	int nfds = 0;
	
	trace("%s(state:%s)", __func__, state_name(_state));
	assert(_state > ST_INIT);
	
	if (_state == ST_POLLWAIT && _poll_until < *select_until)
		*select_until = _poll_until;
	
	for (sktid = 0; skt = _skt+sktid, sktid < SKT_CNT; sktid++) {
		if (skt->state <= PKTLAB_SKTST_FREE)
			continue;
		
		debug("SKT[%d]:{fd:%d, txqlen:%zu, state:%s}",
			sktid, skt->fd, nqlen(&skt->txq),
			pktlab_sktstate_name(skt->state));
		
		switch (skt->state) {
		case PKTLAB_SKTST_OPENING:
			FD_SET(skt->fd, wset);
			nfds = MAX(nfds, skt->fd+1);
			if (skt->open_until < *select_until)
				*select_until = skt->open_until;
			break;
		
		case PKTLAB_SKTST_OPEN:
			if (skt->transproto != PKTLAB_TCP_PROTO || have_space(sktid)) {
				debug("rbuf (%" PRIu32 "/%" PRIu32 "),"
					" buf (%" PRIu32 "/%" PRIu32 ")",
					skt->rbufused, skt->rbufmax,
					_bufused, _bufmax);
				FD_SET(skt->fd, rset);
				nfds = MAX(nfds, skt->fd+1);
			}
			// no break
		
		case PKTLAB_SKTST_EOF:
			if ((msg = nqpeek(&skt->txq))) {
				assert(msg->type == PKTLAB_NSEND_MESSAGE);
				if (msg->nsend.time <= _time_now) {
					FD_SET(skt->fd, wset);
					nfds = MAX(nfds, skt->fd+1);
				} else {
					if (msg->nsend.time < *select_until)
						*select_until = msg->nsend.time;
				}
			}
			// no break
		
		default:
			break;
		}
	}
	
	return nfds;
}

int network_process_select (
	int nsel, const fd_set * rset, const fd_set * wset)
{
	struct socket * skt;
	unsigned int sktid;
	int nhandled = 0;
	
	trace("%s(state:%s)", __func__, state_name(_state));
	assert(_state > ST_INIT);
	
	for (sktid = 0; skt = _skt+sktid, sktid < SKT_CNT; sktid++) {
		if (skt->state <= PKTLAB_SKTST_FREE)
			continue;
		
		if (FD_ISSET(skt->fd, rset)) {
			socket_readable(sktid);
			nhandled += 1;
		}
		
		if (FD_ISSET(skt->fd, wset)) {
			switch (skt->state) {
			case PKTLAB_SKTST_OPENING:
				socket_connected(sktid);
				nhandled += 1;
				break;
			case PKTLAB_SKTST_OPEN:
			case PKTLAB_SKTST_EOF:
				socket_writeable(sktid);
				nhandled += 1;
				break;
			default: // should not happen
				debug("SKT %d descriptor %d is writable in state %s "
					"(should not happen)", (int) sktid, skt->fd,
					pktlab_sktstate_name(skt->state));
				break;
			}
		}
	}
		
	if (_state == ST_POLLWAIT) {
		if (_poll_until <= _time_now || !nqempty(&_rxq))
			state_change(ST_POLLFLUSH);
	}
	
	if (_state == ST_POLLFLUSH)
		poll_flush();
	
	return nhandled;
}

// Message handlers.
// 

void network_handle_nopen(struct pktlab_message * msg) {
	const uint_fast8_t sktid = msg->nopen.sktid;
	const uint_fast8_t netproto = msg->nopen.proto & PKTLAB_NETPROTO_MASK;
	const uint_fast8_t intf = msg->nopen.intf;
	const uint_fast32_t rbufsz = msg->nopen.rbufsz;
	const uint_fast8_t transproto = msg->nopen.proto & PKTLAB_TRANSPORT_MASK;
	const uint_fast8_t addrlen = msg->nopen.addrlen;
	const uint_fast8_t portlen = msg->nopen.portlen;
	const void * const addrptr = msg->nopen.addrptr;
	const void * const portptr = msg->nopen.portptr;
	struct socket * const skt = _skt + sktid;
	uint16_t locport, remport;
	uint_fast8_t expect_addrlen;
	uint_fast8_t expect_portlen;
	
	trace("network_handle_nopen(msg:{sktid:%d,proto:0x%02x,intf:%d})",
		(int) msg->nopen.sktid, (int) msg->nopen.proto, (int) msg->nopen.intf);
	assert(msg->type == PKTLAB_NOPEN_MESSAGE);
	
	if (skt->state != PKTLAB_SKTST_FREE) {
		control_report(PKTLAB_SKTINUSE);
		return;
	}	

	switch (netproto) {
	case PKTLAB_IP4_PROTO:
		expect_addrlen = 4;
		break;
	case PKTLAB_IP6_PROTO:
		expect_addrlen = 16;
		break;
	default:
		control_report(PKTLAB_BADPROTO);
		return;
	}
	
	switch (transproto) {
	case PKTLAB_RAW_PROTO:
		if (addrlen != 0 || portlen != 0)
			control_report(PKTLAB_BADMSG);
		else
			raw_socket_open(sktid, netproto, rbufsz);
		return;
	case PKTLAB_TCP_PROTO:
	case PKTLAB_UDP_PROTO:
		expect_portlen = 4;
		break;
	default:
		control_report(PKTLAB_BADPROTO);
		return;
	}
	
	if (addrlen != expect_addrlen) {
		control_report(PKTLAB_BADADDR);
		return;
	}
	
	if (portlen != expect_portlen) {
		control_report(PKTLAB_BADPORT);
		return;
	}
	
	// ports in network byte order
	memcpy(&locport, portptr+0, 2);
	memcpy(&remport, portptr+2, 2);
	
	if (remport == 0) {
		control_report(PKTLAB_BADPORT);
		return;
	}

	
	trans_socket_open(sktid, netproto, intf, rbufsz,
		transproto, addrptr, addrlen, locport, remport);
}

void network_handle_nclose(struct pktlab_message * msg) {
	const uint_fast8_t sktid = msg->nopen.sktid;
	struct socket * const skt = _skt + sktid;

	trace("network_handle_nclose(msg:{sktid:%d})", (int) sktid);
	assert(msg->type == PKTLAB_NCLOSE_MESSAGE);
	assert(_state == ST_IDLE);

	if (skt->state == PKTLAB_SKTST_FREE) {
		control_report(PKTLAB_BADSKT);
		return;
	} else
		control_report(PKTLAB_SUCCESS);
	
	socket_close(sktid);
}

void network_handle_npoll(struct pktlab_message * msg) {
	trace("%s(msg:{})", __func__);
	assert(msg->type == PKTLAB_NPOLL_MESSAGE);
	assert(_state == ST_IDLE);
	
	control_pause();

	if (nqempty(&_rxq)) {
		state_change(ST_POLLWAIT);
		_poll_until = msg->npoll.time;
	} else {
		state_change(ST_POLLFLUSH);
		poll_flush();
	}
}

void network_handle_nsend(struct pktlab_message * msg) {
	const uint_fast8_t sktid = msg->nsend.sktid;
	struct socket * const skt = _skt + sktid;
	enum pktlab_status status;
	int32_t msg_bufused;

	trace("%s(msg:{sktid:%d})", __func__, (int) msg->nsend.sktid);
	assert(msg->type == PKTLAB_NSEND_MESSAGE);
	assert(_state == ST_IDLE);
	
	if ((skt->netproto | skt->transproto) != msg->nsend.proto) {
		control_report(PKTLAB_BADPROTO);
		return;
	}

	if (skt->state <= PKTLAB_SKTST_FREE) {
		switch (skt->state) {
		case PKTLAB_SKTST_FREE:
			status = PKTLAB_BADSKT;
			break;
		default:
			status = PKTLAB_SKTERR;
			break;
		}	
		
		control_report(status);
		return;
	}

	msg_bufused = nsend_mem_cal(msg);
	if (msg_bufused < 0) {
		control_report(PKTLAB_BADPROTO);
		return;
	}

	if (((uint_fast64_t) _bufused+msg_bufused) > _bufmax) {
		control_report(PKTLAB_NOBUFS);
		return;
	}

	nqput(&skt->txq, msg);
	_bufused += msg_bufused;

	debug("buf (%" PRIu32 "/%" PRIu32 ")", _bufused, _bufmax);
	assert(_bufused <= _bufmax);
	control_report(PKTLAB_SUCCESS);
}

void network_handle_ncap(struct pktlab_message * msg) {
	trace("%s(msg:{})", __func__);
	assert(msg->type == PKTLAB_NCAP_MESSAGE);
	assert(_state == ST_IDLE);

	control_report(PKTLAB_UNIMPL);
}

void network_bufmax_read (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	uint32_t tmp_bufmax = pktlab_hton32(_bufmax);
	
	memcpy(buf, (char *) &tmp_bufmax + off, len);
}

void network_bufused_read (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	uint32_t tmp_bufused = pktlab_hton32(_bufused);

	memcpy(buf, (char *) &tmp_bufused + off, len);
}

/*
void network_skt_proto_read (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	const unsigned int start = off / sizeof(uint8_t);
	const unsigned int end = (off+len+sizeof(uint8_t)-1) / sizeof(uint8_t);
	unsigned int sktid;
	uint8_t proto;
	
	off -= start * sizeof(uint8_t);
	for (sktid = start; sktid < end; sktid++) {
		proto = _skt[sktid].proto;
		memcpy(buf, (void*)&proto + off, MIN(sizeof(uint8_t),len));
		buf += sizeof(uint8_t);
		len -= sizeof(uint8_t);
		off = 0;
	}
}

void network_skt_ctlfl_read (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	const unsigned int start = off / sizeof(uint8_t);
	const unsigned int end = (off+len+sizeof(uint8_t)-1) / sizeof(uint8_t);
	unsigned int sktid;
	uint8_t ctlfl;
	
	off -= start * sizeof(uint8_t);
	for (sktid = start; sktid < end; sktid++) {
		ctlfl = 0; // _skt[sktid].ctlfl;
		memcpy(buf, (void*)&ctlfl + off, MIN(sizeof(uint8_t),len));
		buf += sizeof(uint8_t);
		len -= sizeof(uint8_t);
		off = 0;
	}
}

void network_skt_ctlfl_write (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, const void * buf)
{
	const unsigned int start = off / sizeof(uint8_t);
	const unsigned int end = (off+len+sizeof(uint8_t)-1) / sizeof(uint8_t);
	unsigned int sktid;
	uint8_t ctlfl;
	
	off -= start * sizeof(uint8_t);
	for (sktid = start; sktid < end; sktid++) {
		ctlfl = 0; // _skt[sktid].ctlfl;
		memcpy((void*)&ctlfl + off, buf, MIN(sizeof(uint8_t),len));
		// _skt[sktid].ctlfl = ctlfl;
		buf += sizeof(uint8_t);
		len -= sizeof(uint8_t);
		off = 0;
	}
}

void network_skt_state_read (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	const unsigned int start = off / sizeof(uint8_t);
	const unsigned int end = (off+len+sizeof(uint8_t)-1) / sizeof(uint8_t);
	unsigned int sktid;
	int8_t state;
	
	off -= start * sizeof(uint8_t);
	for (sktid = start; sktid < end; sktid++) {
		state = _skt[sktid].state;
		memcpy(buf, (void*)&state + off, MIN(sizeof(int8_t),len));
		buf += sizeof(uint8_t);
		len -= sizeof(uint8_t);
		off = 0;
	}
}

void network_skt_locaddr_read (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	const unsigned int start = off / PKTLAB_ADDRLEN_MAX;
	const unsigned int end =
		(off+len+PKTLAB_ADDRLEN_MAX-1) / PKTLAB_ADDRLEN_MAX;
	unsigned int sktid;
	
	off -= start * PKTLAB_ADDRLEN_MAX;
	for (sktid = start; sktid < end; sktid++) {
		memcpy(buf, (void*)_skt[sktid].locaddr + off,
			MIN(PKTLAB_ADDRLEN_MAX,len));
		buf += PKTLAB_ADDRLEN_MAX;
		len -= PKTLAB_ADDRLEN_MAX;
		off = 0;
	}
}

void network_skt_remaddr_read (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	const unsigned int start = off / PKTLAB_ADDRLEN_MAX;
	const unsigned int end =
		(off+len+PKTLAB_ADDRLEN_MAX-1) / PKTLAB_ADDRLEN_MAX;
	unsigned int sktid;
	
	off -= start * PKTLAB_ADDRLEN_MAX;
	for (sktid = start; sktid < end; sktid++) {
		memcpy(buf, (void*)_skt[sktid].remaddr + off,
			MIN(PKTLAB_ADDRLEN_MAX,len));
		buf += PKTLAB_ADDRLEN_MAX;
		len -= PKTLAB_ADDRLEN_MAX;
		off = 0;
	}
}

void network_skt_locport_read (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	const unsigned int start = off / sizeof(uint16_t);
	const unsigned int end =
		(off+len+sizeof(uint16_t)-1) / sizeof(uint16_t);
	unsigned int sktid;
	uint16_t locport;
	
	off -= start * sizeof(uint16_t);
	for (sktid = start; sktid < end; sktid++) {
		locport = _skt[sktid].locport;
		memcpy(buf, (void*)&locport + off, MIN(sizeof(uint16_t),len));
		buf += sizeof(uint16_t);
		len -= sizeof(uint16_t);
		off = 0;
	}
}

void network_skt_remport_read (
	const struct pktlab_vmem_region * rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf)
{
	const unsigned int start = off / sizeof(uint16_t);
	const unsigned int end =
		(off+len+sizeof(uint16_t)-1) / sizeof(uint16_t);
	unsigned int sktid;
	uint16_t remport;
	
	off -= start * sizeof(uint16_t);
	for (sktid = start; sktid < end; sktid++) {
		remport = _skt[sktid].remport;
		memcpy(buf, (void*)&remport + off, MIN(sizeof(uint16_t),len));
		buf += sizeof(uint16_t);
		len -= sizeof(uint16_t);
		off = 0;
	}
}
*/

void network_skt_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf)
{
	unsigned int first_skt;
	unsigned int last_skt;
	unsigned int sktid;
	unsigned int read_start;
	unsigned int read_end;
	unsigned int read_off;
	unsigned int read_len;
	char skt_buf[VMEM_SKT_LEN];

	first_skt = off / VMEM_SKT_LEN;
	last_skt = (off + len) / VMEM_SKT_LEN + (((off + len) % VMEM_SKT_LEN) ? 1 : 0);

	debug("network_skt_read:{first_skt:%u, last_skt:%u}",
		first_skt, last_skt);

	read_off = 0;

	for (sktid = first_skt; sktid < last_skt; ++sktid) {

		read_start = (sktid == first_skt) ? off % VMEM_SKT_LEN : 0;
		read_end = (sktid == last_skt - 1) && ((off + len) % VMEM_SKT_LEN) ?
			(off + len) % VMEM_SKT_LEN : VMEM_SKT_LEN;
		read_len = read_end - read_start;

		debug("network_skt_read:{sktid:%u, start:%u, end:%u, len:%u, off:%u}",
			sktid, read_start, read_end, read_len, read_off);

		if (read_len == VMEM_SKT_LEN)
			skt_read(sktid, buf + read_off);
		else {
			memset(skt_buf, 0, VMEM_SKT_LEN);
			skt_read(sktid, skt_buf);
			memcpy(buf + read_off, skt_buf + read_start, read_len);
		}

		read_off += read_len;
	}
}

void network_skt_write (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, const void * restrict buf)
{
	unsigned int first_skt;
	unsigned int last_skt;
	unsigned int sktid;
	unsigned int write_start;
	unsigned int write_end;
	unsigned int write_len;
	unsigned int write_off;
	unsigned int buf_off;
	uint32_t tmp_rbufsize;

	first_skt = off / VMEM_SKT_LEN;
	last_skt = (off + len) / VMEM_SKT_LEN + (((off + len) % VMEM_SKT_LEN) ? 1 : 0);

	debug("network_skt_write:{first_skt:%u, last_skt:%u}",
		first_skt, last_skt);

	for (sktid = first_skt; sktid < last_skt; ++sktid) {

		if (_skt[sktid].state < PKTLAB_SKTST_OPEN)
			continue; // allow write only when socket is open or once opened but have sent all req

		write_start = (sktid == first_skt) ? off % VMEM_SKT_LEN : 0;
		write_end = (sktid == last_skt - 1) && ((off + len) % VMEM_SKT_LEN) ?
			(off + len) % VMEM_SKT_LEN : VMEM_SKT_LEN;
		
		// write skt rbufsiz
		write_off = (write_start > RBUFSIZE_START) ? write_start - RBUFSIZE_START : 0;
		buf_off = (RBUFSIZE_START > write_start) ? RBUFSIZE_START - write_start : 0;
		write_len = MIN(RBUFSIZE_START + sizeof(uint32_t), write_end) > MAX(RBUFSIZE_START, write_start) ?
			MIN(RBUFSIZE_START + sizeof(uint32_t), write_end) - MAX(RBUFSIZE_START, write_start) : 0;

		tmp_rbufsize = pktlab_hton32(_skt[sktid].rbufmax);
		memcpy(((char *) &tmp_rbufsize) + write_off, buf + buf_off, write_len);
		_skt[sktid].rbufmax = pktlab_ntoh32(tmp_rbufsize);

		// write ctlfl
		write_off = (write_start > CTLFL_START) ? write_start - CTLFL_START : 0;
		buf_off = (CTLFL_START > write_start) ? CTLFL_START - write_start : 0;
		write_len = MIN(CTLFL_START + CTLFL_CNT, write_end) > MAX(CTLFL_START, write_start) ?
			MIN(CTLFL_START + CTLFL_CNT, write_end) - MAX(CTLFL_START, write_start) : 0;

		memcpy(_skt[sktid].ctlfl + write_off, buf + buf_off, write_len);
	}
}

void network_tstp_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf)
{
	memcpy(buf, (char *) _send_tstp + off, len);
}

// 
// INTERNAL FUNCTION DEFINITIONS
//

void poll_flush(void) {
	struct pktlab_message * msg;
	uint_fast8_t sktid;
	int_fast32_t msg_bufused;
	uint_fast32_t datalen;

	trace("network:%s(state:%s)", __func__, state_name(_state));
	assert (_state == ST_POLLFLUSH);
	
	while ((msg = nqpeek(&_rxq))) {
		sktid = msg->ndata.sktid;
		datalen = msg->ndata.len;
		msg_bufused = ndata_mem_cal(msg);
		if (control_send(msg)) {
			_skt[sktid].rbufused -= datalen;
			_bufused -= msg_bufused;

			debug("%s: sktid (%" PRIuFAST8 "),"
				" rbuf (%" PRIu32 "/%" PRIu32 "), buf (%" PRIu32 "/%" PRIu32 ")",
				__func__, sktid, _skt[sktid].rbufused, _skt[sktid].rbufmax, _bufused, _bufmax);
			assert(_bufused <= _bufmax && _skt[sktid].rbufused <= _skt[sktid].rbufmax);

			nqdrop(&_rxq);
		} else
			return;
	}
	
	msg = create_nstat();
	
	if (control_send(msg)) {
		control_resume();
		state_change(ST_IDLE);
		clear_dropstats();
		_dropfl = false;
	} else
		free(msg);
}

void state_change(enum state state) {
	debug("network: state changed from %s to %s",
		state_name(_state), state_name(state));
	_state = state;
}

void raw_socket_open (
	uint_fast8_t sktid, uint_fast8_t netproto, uint_fast32_t rbufsz)
{
//	struct socket * const skt = _skt + sktid;

	trace("network:%s(msg:{sktid:%d,netproto:0x%02x})",
		__func__, (int) sktid, (int) netproto);
	
	control_report(PKTLAB_UNIMPL);
}

void trans_socket_open (
	uint_fast8_t sktid, uint_fast8_t netproto, uint_fast8_t intf,
	uint_fast32_t rbufsz, uint_fast8_t transproto,
	const void * addrptr, uint_fast8_t addrlen,
	uint_fast16_t locport, uint_fast16_t remport)
{
	struct socket * const skt = _skt + sktid;
	const void * locaddrptr = NULL;
	struct sockaddr_storage sa_mem;
	uint8_t loc_addr[PKTLAB_ADDRLEN_MAX] = {};
	enum pktlab_status status;
	socklen_t sa_len;
	int sockdomain;
	int socktype;
	int sockproto;
	bool inprogress;
	int sockfd;
	int result;
	
	trace("network:%s(msg:{sktid:%d,netproto:0x%02x,intf:%d,addlen:%d})",
		__func__, (int) sktid, (int) netproto, (int) intf, (int) addrlen);
	
	switch (netproto) {
	case PKTLAB_IP4_PROTO:
		sockdomain = PF_INET;
		break;
	case PKTLAB_IP6_PROTO:
		sockdomain = PF_INET6;
		break;
	default:
		control_report(PKTLAB_BADPROTO);
		goto fail0;
	}
	
	switch (transproto) {
	case PKTLAB_TCP_PROTO:
		socktype = SOCK_STREAM;
		sockproto = IPPROTO_TCP;
		break;
	case PKTLAB_UDP_PROTO:
		socktype = SOCK_DGRAM;
		sockproto = IPPROTO_UDP;
		break;
	default:
		control_report(PKTLAB_BADPROTO);
		goto fail0;
	}
	
	sockfd = socket(sockdomain, socktype, 0);
	
	if (sockfd < 0) {
		debug("socket(PF_INET%s,SOCK_%s,IPPROTO_%s): %s",
			(sockdomain == PF_INET) ? "" : "6",
			(socktype == SOCK_STREAM) ? "STREAM" : "DGRAM",
			(sockproto == IPPROTO_TCP) ? "TCP" : "UDP",
			strerror(errno));
		fatal("%s", strerror(errno));
		control_report(PKTLAB_UNKFAULT);
		goto fail0;
	}
	
	if (vmem_indx_get_laddr(netproto, intf, loc_addr)) {
		fatal("Retrieve local address error");
		control_report(PKTLAB_BADINTF);
		goto fail1;
	}

	sa_len = mksockaddr((void*)&sa_mem, locport, loc_addr, addrlen);
	result = bind(sockfd, (void*)&sa_mem, sa_len);

	if (result < 0) {
		debug("bind(%" PRIuFAST16 "): %s",
			pktlab_ntoh16(locport), strerror(errno));
		
		switch (errno) {
		case EADDRINUSE:
			status = PKTLAB_PORTINUSE;
			break;
		default:
			status = PKTLAB_UNKFAULT;
			break;
		}

		control_report(status);
		goto fail1;
	}
	
	fcntl(sockfd, F_SETFL, fcntl(sockfd, F_GETFL) | O_NONBLOCK);
	
	sa_len = mksockaddr((void*)&sa_mem, remport, addrptr, addrlen);
	result = connect(sockfd, (void*)&sa_mem, sa_len);
	
	if (result < 0) {
		debug("connect(addrlen:%d): %s", (int) addrlen, strerror(errno));
		
		switch (errno) {
		case EINPROGRESS:
			inprogress = true;
			break;
		default:
			control_report(PKTLAB_UNKFAULT);
			goto fail1;
		}
	} else {
		inprogress = false;

		if (transproto == PKTLAB_TCP_PROTO)
			if (set_keepalive(skt->fd) < 0)
				warn("SKT[%" PRIuFAST8 "] setsockopt keepalive failed: %s",
					sktid, strerror(errno));
	}
	
	// Get local address.
	
	sa_len = sizeof(sa_mem);
	result = getsockname(sockfd, (void*)&sa_mem, &sa_len);
	
	if (result < 0)
		fatal("getsockname(%d): %s", sockfd, strerror(errno));
	
	switch (netproto) {
	case PKTLAB_IP4_PROTO:
		locaddrptr = &((struct sockaddr_in*)&sa_mem)->sin_addr;
		break;
	case PKTLAB_IP6_PROTO:
		locaddrptr = &((struct sockaddr_in6*)&sa_mem)->sin6_addr;
		break;
	default:
		goto fail1;
	}
	
	// Initialize socket structure.
	
	memset(skt, 0, sizeof(struct socket));
	
	skt->netproto = netproto;
	skt->transproto = transproto;
	skt->rbufmax = rbufsz;
	skt->fd = sockfd;
	memcpy(skt->locaddr, locaddrptr, MIN(sizeof(skt->locaddr), addrlen));
	memcpy(skt->remaddr, addrptr, MIN(sizeof(skt->remaddr), addrlen));
	skt->addrlen = addrlen;
	skt->locport = locport;
	skt->remport = remport;

	skt->state = (inprogress) ? PKTLAB_SKTST_OPENING : PKTLAB_SKTST_OPEN;
	control_report(PKTLAB_SUCCESS);		
	return;

fail1:
	close(sockfd);
fail0:
	return;
}

void socket_close(uint_fast8_t sktid) {
	struct socket * skt = _skt+sktid;

	trace("network:%s(sktid:%d)", __func__, (int) sktid);

	nqfilter(&_rxq, freesktid_filt, sktid);
	nqfilter(&skt->txq, freeall_filt, 0);
	nqvacuum(&skt->txq);
	close(skt->fd);
	
	memset(skt, 0, sizeof(struct socket));
	socket_state_change(sktid, PKTLAB_SKTST_FREE);
}

void socket_readable(uint_fast8_t sktid) {
	uint_fast32_t avail_buf;
	struct socket * skt = _skt+sktid;
	struct pktlab_message * msg;
	void * ptr;
	uint_fast8_t transproto = skt->transproto;
	ssize_t readcnt;
	pktlab_time_t recv_time;
	enum pktlab_socket_state sktst;
	int32_t msg_bufused;
	
	trace("network:%s(sktid:%d)", __func__, (int) sktid);

	// When buffer full,
	// TCP socket: do nothing
	// Other socket: drop all received
	if (have_space(sktid)) {
		avail_buf = MIN(skt->rbufmax-skt->rbufused,
			_bufmax-_bufused-BUF_OVERHEAD);
		avail_buf = MIN(avail_buf, PKTLAB_NDATA_MAX);
	} else if (transproto == PKTLAB_TCP_PROTO) {
		return;
	} else {
		avail_buf = 0;
	}


	msg = safe_malloc(sizeof(struct pktlab_message) + PKTLAB_NDATA_MAX);
	ptr = msg + 1; // points to end of pktlab_message structure

	assert(transproto == PKTLAB_TCP_PROTO ||
		transproto == PKTLAB_UDP_PROTO ||
		transproto == PKTLAB_RAW_PROTO);

	switch (transproto) {
	case PKTLAB_TCP_PROTO:
		readcnt = read(skt->fd, ptr, avail_buf);
		break;
	case PKTLAB_UDP_PROTO:
		readcnt = read(skt->fd, ptr, PKTLAB_NDATA_MAX);
		break;
	case PKTLAB_RAW_PROTO:
		warn("Raw socket read not implemented");
		readcnt = 0;
		break;
	default:
		warn("Unknown transproto: 0x%X", transproto);
		readcnt = 0; // should not happen, will return 0 length ndata message
		break;
	}

	recv_time = pktlab_time_now();
	
	if (readcnt <= 0) {
		if (readcnt < 0) {
			debug("read(%d,%u): %s", skt->fd,
				PKTLAB_NDATA_MAX, strerror(errno));
						
			skt->err = errno;
			switch (skt->err) {
			case ETIMEDOUT:
				sktst = PKTLAB_SKTST_TIMEDOUT;
				break;
			case ECONNRESET:
				sktst = PKTLAB_SKTST_RESET;
				break;
			case ENETUNREACH:
			case EHOSTUNREACH:
				sktst = PKTLAB_SKTST_UNREACH;
				break;
			default:
				sktst = PKTLAB_SKTST_UNKFAULT;
				break;
			}
			
			socket_state_change(sktid, sktst);
			free(msg);
			return;
			
		} else {
			socket_state_change(sktid, PKTLAB_SKTST_EOF);
			return;
		}
	}


	if (avail_buf < readcnt) {
		// drop data
		_dropfl = true;
		skt->dropstats.pktcnt = limited_add(skt->dropstats.pktcnt, 1);
		skt->dropstats.bytecnt = limited_add(skt->dropstats.bytecnt, readcnt-avail_buf);
		readcnt = avail_buf;

		if (avail_buf == 0) {
			free(msg);
			return;
		}
	}


	msg = safe_realloc(msg, sizeof(struct pktlab_message) + readcnt);
	msg->type = PKTLAB_NDATA_MESSAGE;
	msg->ndata.ptr = ptr;
	msg->ndata.len = readcnt;
	msg->ndata.sktid = sktid;
	msg->ndata.proto = skt->netproto | skt->transproto;
	msg->ndata.time = recv_time;
	msg_bufused = ndata_mem_cal(msg);

	nqput(&_rxq, msg);

	skt->rbufused += readcnt;
	_bufused += msg_bufused;

	debug("rbuf (%" PRIu32 "/%" PRIu32 "), "
		"buf (%" PRIu32 "/%" PRIu32 ")",
		skt->rbufused, skt->rbufmax,
		_bufused, _bufmax);
	assert(_bufused <= _bufmax && _skt->rbufused <= _skt->rbufmax);
}

void socket_writeable(uint_fast8_t sktid) {
	struct socket * skt = _skt+sktid;
	struct pktlab_message * msg;
	uint_fast32_t off = skt->msgoff;
	enum pktlab_socket_state sktst;
	ssize_t writecnt;
	size_t len = 0;
	const uint_fast8_t transproto = skt->transproto;
	pktlab_time_t msg_time, send_time;
	uint_fast8_t msg_sktid;
	uint_fast8_t msg_proto;
	uint_fast16_t msg_tidx;
	int32_t msg_bufused;

	// TODO divide tcp udp logic from network module

	trace("network:%s(sktid:%d)", __func__, (int) sktid);

	while ((msg = nqpeek(&skt->txq))) {
		assert (msg->type == PKTLAB_NSEND_MESSAGE);
		show_skt();

		msg_sktid = msg->nsend.sktid;
		msg_proto = msg->nsend.proto;
		msg_time = msg->nsend.time;
		msg_tidx = msg->nsend.tidx;

		assert (msg_sktid == sktid);
		assert (msg_proto == (skt->netproto | transproto));
		if (msg_time > _time_now)
			return;


		assert(transproto == PKTLAB_RAW_PROTO ||
			transproto == PKTLAB_TCP_PROTO ||
			transproto == PKTLAB_UDP_PROTO);

		switch(transproto) {
		case PKTLAB_RAW_PROTO:
			warn("Raw socket write not implemented");
			writecnt = 0;
			break;
		case PKTLAB_TCP_PROTO:
			len = msg->nsend.tcp.len;
			writecnt = write(skt->fd,
				msg->nsend.tcp.ptr + off, len - off);
			send_time = pktlab_time_now();
			break;
		case PKTLAB_UDP_PROTO:
			len = msg->nsend.udp.len;
			writecnt = write(skt->fd,
				msg->nsend.udp.ptr + off, len - off);
			send_time = pktlab_time_now();
			break;
		default:
			warn("Unknown transport protocol: 0x%X", transproto);
			writecnt = 0;
			break;
		}

		switch(transproto) {
		case PKTLAB_RAW_PROTO:
			// discard all of them
			free(nqget(&skt->txq));
			off = 0;
			break;
		case PKTLAB_TCP_PROTO:
		case PKTLAB_UDP_PROTO:
			if (writecnt < 0) {
				debug("write(%d,%u): %s", skt->fd,
					len, strerror(errno));
				if (errno == EWOULDBLOCK)
					goto try_later;

				skt->err = errno;
				switch (skt->err) {
				case ETIMEDOUT:
					sktst = PKTLAB_SKTST_TIMEDOUT;
					break;
				case ECONNRESET:
					sktst = PKTLAB_SKTST_RESET;
					break;
				case ENETUNREACH:
				case EHOSTUNREACH:
					sktst = PKTLAB_SKTST_UNREACH;
					break;
				default:
					sktst = PKTLAB_SKTST_UNKFAULT;
					break;
				}

				socket_state_change(sktid, sktst);
				return;
			} else if (off == 0) {
				_send_tstp[msg_tidx] = pktlab_hton64(send_time);

				if (send_time-msg->nsend.time > NSEND_DELAY_LOG_THRES)
					debug("Large nsend delay (%" PRIu64 " ticks): "
						  "req (%" PRIu64 "); sent (%" PRIu64")",
						send_time-msg->nsend.time,
						msg->nsend.time, send_time);
			}

			if (writecnt+off < len) {
				off += writecnt;
			} else {
				msg_bufused = nsend_mem_cal(msg);
				assert(msg_bufused >= 0);

				_bufused -= msg_bufused;
				free(nqget(&skt->txq));
				off = 0;

				debug("buf (%" PRIu32 "/%" PRIu32 ")", _bufused, _bufmax);
				assert(_bufused <= _bufmax);
			}
			break;
		default:
			warn("%s: unknown nsend msg buf size not accounted before discarding", __func__);
			free(nqget(&skt->txq)); // should not happen, behavior is to discard all of them
			off = 0;
			break;
		}
	}
	
	// We get here if we drain the transmit queue or the write would block.
try_later:
	skt->msgoff = off;
}

void socket_connected(uint_fast8_t sktid) {
	struct socket * const skt = _skt + sktid;
	int result, sockerr = 0;
	socklen_t optlen;
	
	trace("network:%s(msg:{sktid:%d})", __func__, (int) sktid);
	assert(_state > ST_INIT);
	
	// Use socket error to determine outcome of open.
	
	optlen = sizeof(sockerr);
	result = getsockopt(skt->fd, SOL_SOCKET, SO_ERROR, &sockerr, &optlen);
	
	if (result < 0)
		fatal("%s", strerror(errno));
	
	switch (sockerr) {
	case 0:
		socket_state_change(sktid, PKTLAB_SKTST_OPEN);

		if (skt->transproto == PKTLAB_TCP_PROTO)
			if (set_keepalive(skt->fd) < 0)
				warn("SKT[%" PRIuFAST8 "] setsockopt keepalive failed: %s",
					sktid, strerror(errno));
		break;
	case ECONNREFUSED:
		socket_state_change(sktid, PKTLAB_SKTST_REFUSED);
		break;
	case ETIMEDOUT:
		socket_state_change(sktid, PKTLAB_SKTST_TIMEDOUT);
		break;
	case EHOSTUNREACH:
		socket_state_change(sktid, PKTLAB_SKTST_UNREACH);
		break;
	default:
		warn("SKT %s: %s.", (int) sktid, strerror(sockerr));
		socket_state_change(sktid, PKTLAB_SKTST_UNKFAULT);
		break;
	}
}

void socket_state_change(unsigned int sktid, enum pktlab_socket_state state) {
	debug("network: socket %u state changed from %s to %s", sktid,
		pktlab_sktstate_name(_skt[sktid].state), pktlab_sktstate_name(state));
	_skt[sktid].state = state;
}

/*
void inject_null_ndata(uint_fast8_t sktid) {
	struct socket * const skt = _skt+sktid;
	struct pktlab_message * msg;
	
	trace("network:%s(sktid:%d)", __func__, (int) sktid);
	assert(skt->state < PKTLAB_SKTST_FREE || skt->state > PKTLAB_SKTST_OPENING);

	msg = safe_calloc(1, sizeof(struct pktlab_message));
	msg->type = PKTLAB_NDATA_MESSAGE;
	msg->ndata.ptr = NULL;
	msg->ndata.len = 0;
	msg->ndata.sktid = sktid;
	msg->ndata.proto = skt->netproto | skt->transproto;
	msg->ndata.time = _time_now;
	nqput(&_rxq, msg);
}
*/

void clear_dropstats(void) {
	unsigned int sktid;
	
	for (sktid = 0; sktid < SKT_CNT; sktid++)
		memset(&_skt[sktid].dropstats, 0, sizeof(_skt[sktid].dropstats));
}

struct pktlab_message * create_nstat(void) {
	struct pktlab_message * msg;
	struct socket * skt;
	unsigned int sktid;
	char statbuf[PKTLAB_STATLIST_SIZE*SKT_CNT];
	char * ptr = statbuf;
	size_t len = 0;
	uint8_t tmp_sktid;
	uint8_t tmp_stat;
	uint32_t bytecnt;
	uint32_t pktcnt;

	// statlist contains all states of non free sockets
	for (sktid = 0; skt = _skt+sktid, sktid < SKT_CNT; sktid++) {
		if (skt->state == PKTLAB_SKTST_FREE)
			continue;
		
		tmp_sktid = sktid;
		tmp_stat = skt->state;
		bytecnt = MIN(skt->dropstats.bytecnt, UINT32_C(0xffffff));
		pktcnt = MIN(skt->dropstats.pktcnt, UINT32_C(0xffffff));

		memcpy(ptr+0, &tmp_sktid, sizeof(uint8_t));
		memcpy(ptr+1, &tmp_stat, sizeof(uint8_t));
		pktlab_set24n(ptr+2, bytecnt);
		pktlab_set24n(ptr+5, pktcnt);

		ptr += PKTLAB_STATLIST_SIZE;
	}

	len = ptr - statbuf;

	msg = safe_calloc(1, sizeof(struct pktlab_message) + len);
	msg->type = PKTLAB_NSTAT_MESSAGE;

	memcpy(msg + 1, statbuf, len);
	msg->nstat.ptr = msg + 1;
	msg->nstat.len = len;

	return msg;
}

bool freeall_filt(void * ptr, uintptr_t aux) {
	free(ptr);
	return false;
}

bool freesktid_filt(void * ptr, uintptr_t sktid) {
	struct pktlab_message * msg = ptr;
	if (msg->ndata.sktid == sktid) {
		free(ptr);
		return false;
	} else
		return true;
}

const char * state_name(enum state state) {
	static const char * const names[] = {
		[ST_UNKNOWN] = "UNKNOWN",
		[ST_INIT] = "INIT",
		[ST_IDLE] = "IDLE",
		[ST_POLLWAIT] = "POLLWAIT",
		[ST_POLLFLUSH] = "POLLFLUSH"
	};
	
	const char * name = NULL;
	
	if (state < sizeof(names) / sizeof(names[0]))
		name = names[state];
	
	return (name != NULL) ? name : names[ST_UNKNOWN];
}

void skt_read(uint8_t sktid, void * buf) {
	char * ptr = buf;
	uint8_t proto = _skt[sktid].netproto | _skt[sktid].transproto;
	
	memcpy(ptr, &proto, sizeof(uint8_t));
	ptr += 0x1;

	memcpy(ptr, &(_skt[sktid].state), sizeof(int8_t));
	ptr += 0x1;

	ptr += 0xE; // padding

	memcpy(ptr, _skt[sktid].locaddr, PKTLAB_ADDRLEN_MAX);
	ptr += PKTLAB_ADDRLEN_MAX;

	memcpy(ptr, _skt[sktid].remaddr, PKTLAB_ADDRLEN_MAX);
	ptr += PKTLAB_ADDRLEN_MAX;

	memcpy(ptr, &(_skt[sktid].locport), sizeof(uint16_t));
	ptr += sizeof(uint16_t);

	memcpy(ptr, &(_skt[sktid].remport), sizeof(uint16_t));
	ptr += sizeof(uint16_t);

	ptr += 0xC; // padding

	pktlab_set32n(ptr, _skt[sktid].rbufmax);
	ptr += sizeof(uint32_t);

	ptr += 0xC; // padding

	pktlab_set32n(ptr, _skt[sktid].dropstats.bytecnt);
	ptr += sizeof(uint32_t);
	pktlab_set32n(ptr, _skt[sktid].dropstats.pktcnt);
	ptr += sizeof(uint32_t);

	ptr += 0xA8; // padding

	memcpy(ptr, _skt[sktid].ctlfl, CTLFL_CNT);
	ptr += CTLFL_CNT;

	memset(ptr, 0, VMEM_SKT_LEN - (ptr - (char *)buf));
}

void show_skt(void) {
	int sktid;
	struct socket * skt;
	for (sktid = 0; skt = _skt+sktid, sktid < SKT_CNT; sktid++) {
		if (skt->state <= PKTLAB_SKTST_FREE)
			continue;

		debug("SKT[%d]:{fd:%d, txqlen:%zu, state:%s}",
			sktid, skt->fd, nqlen(&skt->txq),
			pktlab_sktstate_name(skt->state));
	}
}

int32_t nsend_mem_cal(const struct pktlab_message * restrict msg) {
	int32_t msglen;
	uint_fast8_t transproto;

	assert(msg->type == PKTLAB_NSEND_MESSAGE);

	transproto = (msg->nsend.proto) & PKTLAB_TRANSPORT_MASK;
	debug("%s: transproto (%" PRIuFAST8 ")", __func__, transproto);

	// nsend common msg fmt:
	// sktid 1B, proto 1B, tidx 2B, time 8B and len of data

	switch (transproto) {
	case PKTLAB_TCP_PROTO:
		msglen = PKTLAB_HLEN + 1 + 1 + 2 + 8 + msg->nsend.tcp.len;
		break;
	case PKTLAB_UDP_PROTO:
		msglen = PKTLAB_HLEN + 1 + 1 + 2 + 8 + msg->nsend.udp.len;
		break;
	default:
		warn("%s: unknown transproto: 0x%X", __func__, transproto);
		return -1;
	}

	debug("%s: msg_bufused: %" PRId32, __func__,
		(int32_t) BUF_OVERHEAD + msglen);
	return (int32_t) BUF_OVERHEAD + msglen;
}

int32_t ndata_mem_cal(const struct pktlab_message * restrict msg) {
	assert(msg->type == PKTLAB_NDATA_MESSAGE);
	assert(((uintmax_t) BUF_OVERHEAD + msg->ndata.len) <= INT32_MAX);
	int_fast32_t ret;
	ret = BUF_OVERHEAD + msg->ndata.len;
	debug("%s: msg_bufused: %" PRId32 " datalen: %" PRIu32, __func__,
		ret, msg->ndata.len);
	return ret;
}

bool have_space(uint_fast8_t sktid) {
	struct socket * skt = _skt+sktid;
	if (skt->rbufmax > skt->rbufused &&
		_bufmax-_bufused > BUF_OVERHEAD)
		return true;
	return false;
}

uint32_t limited_add(const uint32_t target, const ssize_t incre) {
	assert(incre >= 0);
	if ((uintmax_t) target+incre > UINT32_MAX) {
		info("Wrap over detected for %" PRIu32 " and %zd" , target, incre);
		return UINT32_MAX;
	}

	return target+incre;
}
