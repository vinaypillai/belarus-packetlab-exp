// network.h
// 

#ifndef _NETWORK_H_
#define _NETWORK_H_

#include <sys/time.h>
#include <sys/select.h>
#include <pktlab.h>

// 
// EXPORTED FUNCTION DECLARATIONS
// 

extern void network_initialize(void);
extern void network_start(void);
extern void network_reset(void);

// Select handlers.

extern int network_prepare_select (
	fd_set * restrict rset, fd_set * restrict wset,
	pktlab_time_t * restrict select_until);

extern int network_process_select(
	int nsel, const fd_set * restrict rset, const fd_set * restrict wset);

// Network request handlers.

extern void network_handle_nopen(struct pktlab_message * msg);
extern void network_handle_nclose(struct pktlab_message * msg);
extern void network_handle_npoll(struct pktlab_message * msg);
extern void network_handle_nsend(struct pktlab_message * msg);
extern void network_handle_ncap(struct pktlab_message * msg);

// Memory read/write handlers.

extern void network_bufmax_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf);

extern void network_bufused_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * buf);

extern void network_skt_proto_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf);

extern void network_skt_ctlfl_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf);

extern void network_skt_ctlfl_write (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, const void * restrict buf);

extern void network_skt_state_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf);

extern void network_skt_locaddr_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf);

extern void network_skt_remaddr_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf);

extern void network_skt_locport_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf);

extern void network_skt_remport_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf);

extern void network_skt_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf);

extern void network_skt_write (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, const void * restrict buf);

extern void network_tstp_read (
	const struct pktlab_vmem_region * restrict rgn,
	uint_fast32_t off, uint_fast32_t len, void * restrict buf);

#endif

