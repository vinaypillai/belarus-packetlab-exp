// vmem.h
// 

#ifndef _VMEM_H_
#define _VMEM_H_

#include <stdbool.h>

#include <pktlab.h>

// 
// EXPORTED FUNCTION DECLARATIONS
// 

extern void vmem_initialize(void);

// Memory request handlers.

extern void vmem_handle_mread(struct pktlab_message * msg);
extern void vmem_handle_mwrite(struct pktlab_message * msg);

// Utilities for other modules

extern bool vmem_indx_get_laddr (
    uint8_t net_proto, uint8_t indx, void * buf);

extern bool vmem_indx_get_ldnsaddr (
    uint8_t net_proto, uint8_t indx, void * buf);

#endif

