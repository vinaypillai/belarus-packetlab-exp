// vmem_local_dns_addr.c
//

#include <assert.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <arpa/inet.h>
#include <sys/socket.h>

#include <pktlab.h>

#include "console.h"
#include "network_util.h"
#include "vmem_local_dns_addr.h"

//
// INTERNAL CONSTANTS
//

#define DNS_CNT 16

#define BUF_SIZ 4096

// 
// INTERNAL TYPE DEFINITIONS
// 

struct local_dns_addr {
    uint8_t v4cnt;
    uint8_t v6cnt;
    uint8_t v4addrls[DNS_CNT][PKTLAB_IPV4_WO_MSK_ADDR_LEN];
    uint8_t v6addrls[DNS_CNT][PKTLAB_IPV6_ADDR_LEN];
};

//
// INTERNAL GLOBAL VARIABLE
//

static struct local_dns_addr _loc_dns_addr_ls;

//
// INTERNAL FUNCTION DECLARATION
//

static bool get_local_dns_resolv_conf(const char * resolv_path);

//
// EXPORTED FUNCTION DEFINITION
//

void vmem_ldnsaddr_initialize_str (
    const char * restrict v4_dnsaddr_str,
    const char * restrict v6_dnsaddr_str)
{
    char v4_dnsaddrs[BUF_SIZ] = {};
    char v6_dnsaddrs[BUF_SIZ] = {};
    char * ptr;

    trace("%s(v4dnsaddr:%s,v6dnsaddr:%s)", __func__,
        safe_str(v4_dnsaddr_str), safe_str(v6_dnsaddr_str));

    if (v4_dnsaddr_str != NULL) {
        strncpy(v4_dnsaddrs, v4_dnsaddr_str, BUF_SIZ-1);
        ptr = strtok(v4_dnsaddrs, ",");
        while (ptr != NULL) {
            if (parse_addr_n_store (
                    PKTLAB_IP4_PROTO, 0, ptr,
                    _loc_dns_addr_ls.v4addrls[_loc_dns_addr_ls.v4cnt],
                    PKTLAB_IPV4_WO_MSK_ADDR_LEN) == 0) {
                info("Exporting entry %" PRIu8 " IPv4 ldnsaddr: %s",
                    _loc_dns_addr_ls.v4cnt, ptr);
                ++_loc_dns_addr_ls.v4cnt;
            } else
                warn("Cannot understand IPv4 ldnsaddr: %s, omitting", ptr);
            ptr = strtok(NULL, ",");
        }
    }

    if (v6_dnsaddr_str != NULL) {
        strncpy(v6_dnsaddrs, v6_dnsaddr_str, BUF_SIZ-1);
        ptr = strtok(v6_dnsaddrs, ",");
        while (ptr != NULL) {
            if (parse_addr_n_store (
                    PKTLAB_IP6_PROTO, 0, ptr,
                    _loc_dns_addr_ls.v6addrls[_loc_dns_addr_ls.v6cnt],
                    PKTLAB_IPV6_ADDR_LEN) == 0) {
                info("Exporting entry %" PRIu8 " IPv6 ldnsaddr: %s",
                    _loc_dns_addr_ls.v6cnt, ptr);
                ++_loc_dns_addr_ls.v6cnt;
            } else
                warn("Cannot understand ldnsaddr laddr: %s, omitting", ptr);
            ptr = strtok(NULL, ",");
        }
    }
}

void vmem_ldnsaddr_initialize_resolv_conf(const char * restrict resolv_path) {
    trace("%s(resolv_path:%s)", __func__, safe_str(resolv_path));

    memset(&_loc_dns_addr_ls, 0, sizeof(struct local_dns_addr));
    get_local_dns_resolv_conf(resolv_path);

    debug("DNScnt:{%u}", _loc_dns_addr_ls.v4cnt);
}

void vmem_ldnsaddr_cnt_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf)
{
    char * ptr = buf;
    
    if (len == 0)
        return;

    if (off == 0x0) {
        *ptr = _loc_dns_addr_ls.v4cnt;
        off += 1;
        len -= 1;
        ptr += sizeof(uint8_t);
    
        if (len == 0)
            return;
    }

    if (off == 0x1) {
        *ptr = _loc_dns_addr_ls.v6cnt;
        off += 1;
        len -= 1;
        ptr += sizeof(uint8_t);
    
        if (len == 0)
            return;
    }
}

void vmem_ldnsaddr_v4_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf)
{
    memcpy(buf, (char *) _loc_dns_addr_ls.v4addrls + off, len);
}

void vmem_ldnsaddr_v6_read (
    const struct pktlab_vmem_region * restrict rgn,
    uint_fast32_t off, uint_fast32_t len, void * buf)
{
    memcpy(buf, (char *) _loc_dns_addr_ls.v6addrls + off, len);
}

uint8_t vmem_util_ldnsaddr_cnt_read(uint8_t net_proto) {
    assert(net_proto == PKTLAB_IP4_PROTO || net_proto == PKTLAB_IP6_PROTO);
    return (net_proto == PKTLAB_IP4_PROTO) ? _loc_dns_addr_ls.v4cnt : _loc_dns_addr_ls.v6cnt;
}

void vmem_util_ldnsaddr_v4_read(uint8_t indx, void * buf) {
    assert(indx < _loc_dns_addr_ls.v4cnt);
    assert(buf != NULL);
    memcpy(buf, _loc_dns_addr_ls.v4addrls[indx], PKTLAB_IPV4_WO_MSK_ADDR_LEN);
}

void vmem_util_ldnsaddr_v6_read(uint8_t indx, void * buf) {
    assert(indx < _loc_dns_addr_ls.v6cnt);
    assert(buf != NULL);
    memcpy(buf, _loc_dns_addr_ls.v6addrls[indx], PKTLAB_IPV6_ADDR_LEN);
}


//
// INTERNAL FUNCTION DEFINITION
//

bool get_local_dns_resolv_conf(const char * restrict resolv_path) {
    FILE * fp;
    char line[BUF_SIZ], * ptr;
    int af;
    void * dst;
    uint8_t * cnt;

    fp = fopen(resolv_path, "r");
    if (fp == NULL) {
        warn("Open %s failed", resolv_path);
        return true;
    }

    while (!feof(fp)) {
        if (fgets(line, BUF_SIZ, fp) == NULL)
            break;

        ptr = strtok(line, " \t\n");

        if (ptr != NULL && strcmp(ptr, "nameserver") == 0) {
            ptr = strtok(NULL, " \t\n");

            if (!strchr(ptr, ':')) {
                if (_loc_dns_addr_ls.v4cnt >= DNS_CNT)
                    continue;

                af = AF_INET;
                dst = _loc_dns_addr_ls.v4addrls[_loc_dns_addr_ls.v4cnt];
                cnt = &(_loc_dns_addr_ls.v4cnt);
            } else {
                if (_loc_dns_addr_ls.v6cnt >= DNS_CNT)
                    continue;

                af = AF_INET6;
                dst = _loc_dns_addr_ls.v6addrls[_loc_dns_addr_ls.v6cnt];
                cnt = &(_loc_dns_addr_ls.v6cnt);
            }

            if (inet_pton(af, ptr, dst))
                *cnt += 1;
        }
    }

    fclose(fp);
    return false;
}
