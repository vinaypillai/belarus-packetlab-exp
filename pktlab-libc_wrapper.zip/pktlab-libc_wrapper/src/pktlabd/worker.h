// worker.h
// 

#ifndef _WORKER_H_
#define _WORKER_H_

#include <pktlab.h>

// 
// EXPORTED GLOBAL VARIABLES
// 

extern pktlab_time_t _time_now;

// 
// EXPORTED FUNCTION DECLARATIONS
// 

void worker_initialize(void);
void worker_main(int mgrfd, const char * spec);

#endif
