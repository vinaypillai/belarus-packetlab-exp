//
//  Python Wrapper for the pktlab library
//  By TB Yan, based on original code by Prof. Kirill Levchenko
//

//
// Define and include for python first is best practice
//

#define PY_SSIZE_T_CLEAN
#include <python3.6/Python.h>

//
// INTERNAL CONSTANTS
//

#define MODULE_NAME "pypl"

#define UINT16_T_MAX 65536
#define UINT32_T_MAX 4294967296

//
// INTERNAL MACRO
//

#define RETURN_IF(c,v) if (c) return (v)

#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <pktlab.h>

//
// INTERNAL FUNCTION DEFINITION
//

// Utility for transforming iovec to a single char array
static int 
iovec_2_arr(struct iovec * restrict iov, int iovec_len, char ** arr_ptr, size_t * arr_len) {

    *arr_len = 0;
    for (int i = 0; i < iovec_len; ++i)
        *arr_len += (iov + i)->iov_len;

    *arr_ptr = (char *) malloc(*arr_len);
    if (arr_ptr == NULL) {
        PyErr_SetString(PyExc_RuntimeError, "iov conversion failed.");
        return 1;
    }
        

    size_t cur_indx = 0;
    for (int i = 0; i < iovec_len; ++i) {
        memcpy(*arr_ptr + cur_indx, (iov + i)->iov_base, (iov + i)->iov_len);
        cur_indx += (iov + i)->iov_len;
    }

    return 0;
}

// internal encode nsend msg function for udp and tcp
static PyObject *
_encode_nsend_msg_rawtcpudp(PyObject * self, PyObject * args, PyObject * kwargs) {

    unsigned char sktid;
    unsigned char proto;
    unsigned int tidx;
    unsigned long long time;
    PyBytesObject * data;
    char * kwList[] = {"sktid", "proto", "tidx", "time", "data", NULL};

    RETURN_IF(!PyArg_ParseTupleAndKeywords(args, kwargs, "bbIKS", kwList,
                                           &sktid, &proto, &tidx, &time, &data), NULL);

    Py_ssize_t data_len = PyBytes_Size((PyObject *)data);
    const char * raw_data = PyBytes_AsString((PyObject *)data);

    if (tidx >= UINT16_T_MAX) {
        PyErr_SetString(PyExc_ValueError, "tidx too large.");
        return NULL;
    }

    struct pktlab_message nsend_msg = {};
    nsend_msg.type = PKTLAB_NSEND_MESSAGE;
    nsend_msg.nsend.sktid = (uint8_t) sktid;
    nsend_msg.nsend.proto = (uint8_t) proto;
    nsend_msg.nsend.tidx = (uint16_t) tidx;
    nsend_msg.nsend.time = (pktlab_time_t) time;

    switch (nsend_msg.nsend.proto & PKTLAB_TRANSPORT_MASK) {
    case PKTLAB_RAW_PROTO:
        nsend_msg.nsend.raw.ptr = raw_data;
        nsend_msg.nsend.raw.len = data_len;
        break;
    case PKTLAB_TCP_PROTO:
        nsend_msg.nsend.tcp.ptr = raw_data;
        nsend_msg.nsend.tcp.len = data_len;
        break;
    case PKTLAB_UDP_PROTO:
        nsend_msg.nsend.udp.ptr = raw_data;
        nsend_msg.nsend.udp.len = data_len;
        break;
    default:
        PyErr_SetString(PyExc_ValueError, "Invalid transproto value.");
        return NULL;
    }

    char enc_buf[PKTLAB_ENCODE_BUFSZ] = {};
    struct iovec msg_iov[PKTLAB_ENCODE_IOVCNT] = {};
    int msg_iovcnt;
    msg_iovcnt = pktlab_encode_message(&nsend_msg, enc_buf, msg_iov);

    char * msg_arr;
    size_t msg_len;
    RETURN_IF(iovec_2_arr(msg_iov, msg_iovcnt, &msg_arr, &msg_len), NULL);

    PyObject * ret = PyBytes_FromStringAndSize(msg_arr, msg_len);
    free(msg_arr);

    return ret;
}

// Utility to add key value pair to py dictionary
// Performs checking of NULL and Py_XDECREF
static int
dict_insert_key_value(PyObject * dict, PyObject * key, PyObject * value) {
    if (dict == NULL || key == NULL || value == NULL) {
        PyErr_SetString(PyExc_ValueError, "Insert dict parameters NULL.");
        goto fail;
    }

    if (PyDict_SetItem(dict, key, value))
        goto fail;

    return 0;

fail:
    Py_XDECREF(dict);
    Py_XDECREF(key);
    Py_XDECREF(value);
    return 1;
}

static int
dict_insert_status(PyObject * dict, struct pktlab_message * msg) {

    PyObject * key = PyUnicode_FromString("id");
    PyObject * value = PyLong_FromLong((long) (msg->status).id);
    RETURN_IF(dict_insert_key_value(dict, key, value), 1);

    key = PyUnicode_FromString("str");
    value = PyUnicode_FromStringAndSize((msg->status).textptr,
                                        (msg->status).textlen);
    RETURN_IF(dict_insert_key_value(dict, key, value), 1);

    return 0;
}

static int
dict_insert_mdata(PyObject * dict, struct pktlab_message * msg) {

    PyObject * key = PyUnicode_FromString("memaddr");
    PyObject * value = PyLong_FromUnsignedLong((unsigned long) (msg->mdata).addr);
    RETURN_IF(dict_insert_key_value(dict, key, value), 1);

    key = PyUnicode_FromString("data");
    value = PyBytes_FromStringAndSize((msg->mdata).ptr,
                                      (msg->mdata).len);
    RETURN_IF(dict_insert_key_value(dict, key, value), 1);

    return 0;
}

static int
dict_insert_ndata(PyObject * dict, struct pktlab_message * msg) {

    PyObject * key = PyUnicode_FromString("sktid");
    PyObject * value = PyLong_FromLong((long) (msg->ndata).sktid);
    RETURN_IF(dict_insert_key_value(dict, key, value), 1);

    key = PyUnicode_FromString("proto");
    value = PyLong_FromLong((long) (msg->ndata).proto);
    RETURN_IF(dict_insert_key_value(dict, key, value), 1);

    key = PyUnicode_FromString("time");
    value = PyLong_FromUnsignedLongLong((unsigned long long) (msg->ndata).time);
    RETURN_IF(dict_insert_key_value(dict, key, value), 1);

    key = PyUnicode_FromString("data");
    value = PyBytes_FromStringAndSize((msg->ndata).ptr,
                                      (msg->ndata).len);
    RETURN_IF(dict_insert_key_value(dict, key, value), 1);

    return 0;
}

static int
parse_statlist(const char * ptr, long * sktid, long * stat,
    unsigned long long * bytecnt, unsigned long long * pktcnt) {

    *sktid = pktlab_get8(ptr);
    *stat = pktlab_get8(ptr + 1);
    *bytecnt = pktlab_get24n(ptr + 2);
    *pktcnt = pktlab_get24n(ptr + 5);

    return 0;
}

static int
dict_insert_nstat(PyObject * dict, struct pktlab_message * msg) {

    if ((msg->nstat).len % PKTLAB_STATLIST_SIZE != 0) {
        PyErr_SetString(PyExc_ValueError, "nstat message statlist length incorrect.");
        Py_XDECREF(dict);
        return 1;
    }

    PyObject * key = PyUnicode_FromString("statlist");
    PyObject * value = PyList_New(0);
    if (key == NULL || value == NULL) {
        PyErr_SetString(PyExc_ValueError, "nstat create statlist key value pair failed.");
        Py_XDECREF(dict);
        Py_XDECREF(key);
        Py_XDECREF(value);
        return 1;
    }

    for (uint32_t i = 0; i < (msg->nstat).len / PKTLAB_STATLIST_SIZE; ++i) {
        long sktid, stat;
        unsigned long long bytecnt, pktcnt;
        parse_statlist((msg->nstat).ptr + i * PKTLAB_STATLIST_SIZE, &sktid, &stat, &bytecnt, &pktcnt);

        PyObject * tup = PyTuple_New(4);
        PyObject * sktid_obj = PyLong_FromLong(sktid);
        PyObject * stat_obj = PyLong_FromLong(stat);
        PyObject * bytecnt_obj = PyLong_FromUnsignedLongLong(bytecnt);
        PyObject * pktcnt_obj = PyLong_FromUnsignedLongLong(pktcnt);
        if (tup == NULL ||
            sktid_obj == NULL ||
            stat_obj == NULL ||
            bytecnt_obj == NULL ||
            pktcnt_obj == NULL) {
            PyErr_SetString(PyExc_ValueError, "nstat create list tuple failed.");
            Py_XDECREF(dict);
            Py_XDECREF(key);
            Py_XDECREF(value);
            Py_XDECREF(tup);
            Py_XDECREF(sktid_obj);
            Py_XDECREF(stat_obj);
            Py_XDECREF(bytecnt_obj);
            Py_XDECREF(pktcnt_obj);
            return 1;
        }

        if (PyTuple_SetItem(tup, 0, sktid_obj) == -1 ||
            PyTuple_SetItem(tup, 1, stat_obj) == -1 ||
            PyTuple_SetItem(tup, 2, bytecnt_obj) == -1 ||
            PyTuple_SetItem(tup, 3, pktcnt_obj) == -1) {
            PyErr_SetString(PyExc_ValueError, "nstat set list tuple item failed.");
            Py_XDECREF(dict);
            Py_XDECREF(key);
            Py_XDECREF(value);
            Py_XDECREF(tup);
            Py_XDECREF(sktid_obj);
            Py_XDECREF(stat_obj);
            Py_XDECREF(bytecnt_obj);
            Py_XDECREF(pktcnt_obj);
            return 1;
        }

        if (PyList_Append(value, tup)) {
            Py_XDECREF(dict);
            Py_XDECREF(key);
            Py_XDECREF(value);
            Py_XDECREF(tup);
            return 1;
        } else
            Py_XDECREF(tup);
    }

    RETURN_IF(dict_insert_key_value(dict, key, value), 1);

    return 0;
}

// add constant to module
static int
add_module_obj(PyObject * module) {

    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_HLEN), 1);
    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_TICKS_PER_SECOND), 1);
    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_MREAD_MAX), 1);

    PyObject * value = PyLong_FromUnsignedLongLong((unsigned long long) PKTLAB_TIME_MAX);
    RETURN_IF(value == NULL, 1);
    if (PyModule_AddObject(module, "PKTLAB_TIME_MAX", value)) {
        Py_XDECREF(value);
        return 1;
    }

    // Message type
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_UNDEF_MESSAGE", PKTLAB_UNDEF_MESSAGE), 1);

    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_STATUS_MESSAGE", PKTLAB_STATUS_MESSAGE), 1);

    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_MREAD_MESSAGE", PKTLAB_MREAD_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_MWRITE_MESSAGE", PKTLAB_MWRITE_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_MDATA_MESSAGE", PKTLAB_MDATA_MESSAGE), 1);

    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_NOPEN_MESSAGE", PKTLAB_NOPEN_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_NCLOSE_MESSAGE", PKTLAB_NCLOSE_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_NPOLL_MESSAGE", PKTLAB_NPOLL_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_NSEND_MESSAGE", PKTLAB_NSEND_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_NDATA_MESSAGE", PKTLAB_NDATA_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_NSTAT_MESSAGE", PKTLAB_NSTAT_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_NCAP_MESSAGE", PKTLAB_NCAP_MESSAGE), 1);

    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_XSUB_MESSAGE", PKTLAB_XSUB_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_XSTART_MESSAGE", PKTLAB_XSTART_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_XYIELD_MESSAGE", PKTLAB_XYIELD_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_XEND_MESSAGE", PKTLAB_XEND_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_XDESCR_MESSAGE", PKTLAB_XDESCR_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_XFILT_MESSAGE", PKTLAB_XFILT_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_XKEY_MESSAGE", PKTLAB_XKEY_MESSAGE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_XCERT_MESSAGE", PKTLAB_XCERT_MESSAGE), 1);

    // pktlab operation status
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SUCCESS", PKTLAB_SUCCESS), 1);

    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_INTR", PKTLAB_INTR), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_BUSY", PKTLAB_BUSY), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_PORTINUSE", PKTLAB_PORTINUSE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_PKT2BIG", PKTLAB_PKT2BIG), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_BUF2BIG", PKTLAB_BUF2BIG), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTERR", PKTLAB_SKTERR), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_UNIMPL", PKTLAB_UNIMPL), 1);

    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_UNKMSG", PKTLAB_UNKMSG), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_BADMSG", PKTLAB_BADMSG), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_UNXPMSG", PKTLAB_UNXPMSG), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTINUSE", PKTLAB_SKTINUSE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_BADSKT", PKTLAB_BADSKT), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_BADPROTO", PKTLAB_BADPROTO), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_BADADDR", PKTLAB_BADADDR), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_BADPORT", PKTLAB_BADPORT), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_BADINTF", PKTLAB_BADINTF), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_UNKFAULT", PKTLAB_UNKFAULT), 1);

    // Proto
    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_IP4_PROTO), 1);
    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_IP6_PROTO), 1);
    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_RAW_PROTO), 1);
    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_TCP_PROTO), 1);
    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_UDP_PROTO), 1);
    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_ICMP_ECHO_PROTO), 1);
    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_NETPROTO_MASK), 1);
    RETURN_IF(PyModule_AddIntMacro(module, PKTLAB_TRANSPORT_MASK), 1);

    // xattr type
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_UNKNOWN_XATTR", PKTLAB_UNKNOWN_XATTR), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_NAME_XATTR", PKTLAB_NAME_XATTR), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SEQNO_XATTR", PKTLAB_SEQNO_XATTR), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_TIME_VALID_XATTR", PKTLAB_TIME_VALID_XATTR), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SERVER_HOST_XATTR", PKTLAB_SERVER_HOST_XATTR), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SERVER_PORT_XATTR", PKTLAB_SERVER_PORT_XATTR), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_FILTER_HASH_XATTR", PKTLAB_FILTER_HASH_XATTR), 1);

    // pktlab sock status
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTST_FREE", PKTLAB_SKTST_FREE), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTST_OPENING", PKTLAB_SKTST_OPENING), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTST_OPEN", PKTLAB_SKTST_OPEN), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTST_EOF", PKTLAB_SKTST_EOF), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTST_REFUSED", PKTLAB_SKTST_REFUSED), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTST_RESET", PKTLAB_SKTST_RESET), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTST_TIMEDOUT", PKTLAB_SKTST_TIMEDOUT), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTST_UNREACH", PKTLAB_SKTST_UNREACH), 1);
    RETURN_IF(PyModule_AddIntConstant(module, "PKTLAB_SKTST_UNKFAULT", PKTLAB_SKTST_UNKFAULT), 1);

    return 0;
}

//
// PYPL FUNCTION MACRO
//

#define pypl_encode_nsend_msg_raw _encode_nsend_msg_rawtcpudp // encode nsend msg raw function
#define pypl_encode_nsend_msg_tcp _encode_nsend_msg_rawtcpudp // encode nsend msg tcp function
#define pypl_encode_nsend_msg_udp _encode_nsend_msg_rawtcpudp // encode nsend msg udp function

//
// PYPL FUNCTION DEFINITION
//

// encode nopen msg function
static PyObject *
pypl_encode_nopen_msg(PyObject * self, PyObject * args, PyObject * kwargs) {

    unsigned char sktid;
    unsigned char proto;
    unsigned char intf;
    unsigned long rbufsize;
    char * remoteaddr = NULL;
    unsigned int localport = 0;
    unsigned int remoteport = 0;
    unsigned char netproto, transproto;
    char * kwList[] = {"sktid", "proto", "intf", "rbufsize",
        "remoteaddr", "localport", "remoteport", NULL};

    RETURN_IF(!PyArg_ParseTupleAndKeywords(args, kwargs, "bbbk|sII", kwList,
                                           &sktid, &proto, &intf, &rbufsize,
                                           &remoteaddr, &localport, &remoteport), NULL);

    netproto = proto & PKTLAB_NETPROTO_MASK;
    transproto = proto & PKTLAB_TRANSPORT_MASK;

    if ((transproto == PKTLAB_TCP_PROTO || transproto == PKTLAB_UDP_PROTO) &&
        (remoteaddr == NULL || remoteport == 0)) {
        PyErr_SetString(PyExc_ValueError, "Missing remoteaddr, remote port value.");
        return NULL;
    }

    if (rbufsize >= UINT32_T_MAX) {
        PyErr_SetString(PyExc_ValueError, "rebufsize too large.");
        return NULL;
    }

    if (localport >= UINT16_T_MAX) {
        PyErr_SetString(PyExc_ValueError, "localport too large.");
        return NULL;
    }

    if (remoteport >= UINT16_T_MAX) {
        PyErr_SetString(PyExc_ValueError, "remoteport too large.");
        return NULL;
    }

    struct pktlab_message nopen_msg = {};
    nopen_msg.type = PKTLAB_NOPEN_MESSAGE;
    nopen_msg.nopen.sktid = (uint8_t) sktid;
    nopen_msg.nopen.proto = (uint8_t) proto;
    nopen_msg.nopen.intf = (uint8_t) intf;
    nopen_msg.nopen.rbufsz = (uint32_t) rbufsize;

    char addr[PKTLAB_ADDRLEN_MAX] = {};
    char port[PKTLAB_PORTLEN_MAX] = {};
    int af;

    switch (transproto) {
    case PKTLAB_RAW_PROTO:
    case PKTLAB_ICMP_ECHO_PROTO:
        switch (netproto) {
            case PKTLAB_IP4_PROTO:
            case PKTLAB_IP6_PROTO:
                break;
            default:
                PyErr_SetString(PyExc_ValueError, "Invalid netproto value.");
                return NULL;
        }
        break;
    case PKTLAB_TCP_PROTO:
    case PKTLAB_UDP_PROTO:
        switch (netproto) {
            case PKTLAB_IP4_PROTO:
                af = AF_INET;
                nopen_msg.nopen.addrlen = 4;
                break;
            case PKTLAB_IP6_PROTO:
                af = AF_INET6;
                nopen_msg.nopen.addrlen = 16;
                break;
            default:
                PyErr_SetString(PyExc_ValueError, "Invalid netproto value.");
                return NULL;
        }

        if (!inet_pton(af, remoteaddr, addr)) {
            PyErr_SetString(PyExc_ValueError, "remoteaddr does not contain a character string " \
                                              "representing a valid network address.");
            return NULL;
        }
        nopen_msg.nopen.addrptr = addr;

        pktlab_set16n(port, (uint16_t) localport);
        pktlab_set16n(port + sizeof(uint16_t), (uint16_t) remoteport);
        nopen_msg.nopen.portlen = 4;
        nopen_msg.nopen.portptr = port;
        break;
    default:
        PyErr_SetString(PyExc_ValueError, "Invalid transproto value.");
        return NULL;
    }

    char enc_buf[PKTLAB_ENCODE_BUFSZ] = {};
    struct iovec msg_iov[PKTLAB_ENCODE_IOVCNT] = {};
    int msg_iovcnt;
    msg_iovcnt = pktlab_encode_message(&nopen_msg, enc_buf, msg_iov);

    char * msg_arr;
    size_t msg_len;
    RETURN_IF(iovec_2_arr(msg_iov, msg_iovcnt, &msg_arr, &msg_len), NULL);

    PyObject * ret = PyBytes_FromStringAndSize(msg_arr, msg_len);
    free(msg_arr);

    return ret;
}

// encode nsend msg function for icmp
static PyObject *
pypl_encode_nsend_msg_icmp(PyObject * self, PyObject * args, PyObject * kwargs) {

    unsigned char sktid;
    unsigned char proto;
    unsigned int tidx;
    unsigned long long time;
    const char * remoteaddr = NULL;
    unsigned char ttl;
    unsigned int seq;
    PyBytesObject * data;
    char * kwList[] = {"sktid", "proto", "tidx", "time",
        "remoteaddr", "ttl", "seq", "data", NULL};

    RETURN_IF(!PyArg_ParseTupleAndKeywords(args, kwargs, "bbIKsbIS", kwList,
                                           &sktid, &proto, &tidx, &time,
                                           &remoteaddr, &ttl, &seq, &data), NULL);

    Py_ssize_t data_len = PyBytes_Size((PyObject *)data);
    const char * raw_data = PyBytes_AsString((PyObject *)data);

    if (tidx >= UINT16_T_MAX) {
        PyErr_SetString(PyExc_ValueError, "tidx too large.");
        return NULL;
    }

    if (seq >= UINT16_T_MAX) {
        PyErr_SetString(PyExc_ValueError, "seq too large.");
        return NULL;
    }

    if ((proto & PKTLAB_TRANSPORT_MASK) != PKTLAB_ICMP_ECHO_PROTO) {
        PyErr_SetString(PyExc_ValueError, "Invalid transproto value.");
        return NULL;
    }

    struct pktlab_message nsend_msg = {};
    nsend_msg.type = PKTLAB_NSEND_MESSAGE;
    nsend_msg.nsend.sktid = (uint8_t) sktid;
    nsend_msg.nsend.proto = (uint8_t) proto;
    nsend_msg.nsend.tidx = (uint16_t) tidx;
    nsend_msg.nsend.time = (pktlab_time_t) time;
    nsend_msg.nsend.icmp.ttl = (uint8_t) ttl;
    nsend_msg.nsend.icmp.seq = (uint16_t) seq;
    nsend_msg.nsend.icmp.dataptr = (void *) raw_data;
    nsend_msg.nsend.icmp.datalen = (uint32_t) data_len;

    char addr[PKTLAB_ADDRLEN_MAX] = {};
    int af;

    switch (proto & PKTLAB_NETPROTO_MASK) {
        case PKTLAB_IP4_PROTO:
            af = AF_INET;
            nsend_msg.nsend.icmp.addrlen = 4;
            break;
        case PKTLAB_IP6_PROTO:
            af = AF_INET6;
            nsend_msg.nsend.icmp.addrlen = 16;
            break;
        default:
            PyErr_SetString(PyExc_ValueError, "Invalid netproto value.");
            return NULL;
    }

    if (!inet_pton(af, remoteaddr, addr)) {
        PyErr_SetString(PyExc_ValueError, "remoteaddr does not contain a character string "
                                            "representing a valid network address.");
        return NULL;
    }
    nsend_msg.nsend.icmp.addrptr = addr;

    char enc_buf[PKTLAB_ENCODE_BUFSZ] = {};
    struct iovec msg_iov[PKTLAB_ENCODE_IOVCNT] = {};
    int msg_iovcnt;
    msg_iovcnt = pktlab_encode_message(&nsend_msg, enc_buf, msg_iov);

    char * msg_arr;
    size_t msg_len;
    RETURN_IF(iovec_2_arr(msg_iov, msg_iovcnt, &msg_arr, &msg_len), NULL);

    PyObject * ret = PyBytes_FromStringAndSize(msg_arr, msg_len);
    free(msg_arr);

    return ret;
}

// encode nclose msg function
static PyObject *
pypl_encode_nclose_msg(PyObject * self, PyObject * args, PyObject * kwargs) {

    unsigned char sktid;
    char * kwList[] = {"sktid", NULL};

    RETURN_IF(!PyArg_ParseTupleAndKeywords(args, kwargs, "b", kwList, &sktid), NULL);

    struct pktlab_message nclose_msg = {};
    nclose_msg.type = PKTLAB_NCLOSE_MESSAGE;
    nclose_msg.nclose.sktid = (uint8_t) sktid;

    char enc_buf[PKTLAB_ENCODE_BUFSZ] = {};
    struct iovec msg_iov[PKTLAB_ENCODE_IOVCNT] = {};
    int msg_iovcnt;
    msg_iovcnt = pktlab_encode_message(&nclose_msg, enc_buf, msg_iov);

    char * msg_arr;
    size_t msg_len;
    RETURN_IF(iovec_2_arr(msg_iov, msg_iovcnt, &msg_arr, &msg_len), NULL);

    PyObject * ret = PyBytes_FromStringAndSize(msg_arr, msg_len);
    free(msg_arr);

    return ret;
}

// encode mread msg function
static PyObject *
pypl_encode_mread_msg(PyObject * self, PyObject * args, PyObject * kwargs) {

    unsigned long memaddr;
    unsigned long bytecnt;
    char * kwList[] = {"memaddr", "bytecnt", NULL};

    RETURN_IF(!PyArg_ParseTupleAndKeywords(args, kwargs, "kk", kwList, 
                                           &memaddr, &bytecnt), NULL);

    if (memaddr >= UINT32_T_MAX) {
        PyErr_SetString(PyExc_ValueError, "memaddr too large.");
        return NULL;
    }

    if (bytecnt >= UINT32_T_MAX) {
        PyErr_SetString(PyExc_ValueError, "bytecnt too large.");
        return NULL;
    }

    struct pktlab_message mread_msg = {};
    mread_msg.type = PKTLAB_MREAD_MESSAGE;
    mread_msg.mread.addr = (uint32_t) memaddr;
    mread_msg.mread.len = (uint32_t) bytecnt;

    char enc_buf[PKTLAB_ENCODE_BUFSZ] = {};
    struct iovec msg_iov[PKTLAB_ENCODE_IOVCNT] = {};
    int msg_iovcnt;
    msg_iovcnt = pktlab_encode_message(&mread_msg, enc_buf, msg_iov);

    char * msg_arr;
    size_t msg_len;
    RETURN_IF(iovec_2_arr(msg_iov, msg_iovcnt, &msg_arr, &msg_len), NULL);

    PyObject * ret = PyBytes_FromStringAndSize(msg_arr, msg_len);
    free(msg_arr);

    return ret;
}

// encode mwrite msg function
static PyObject *
pypl_encode_mwrite_msg(PyObject * self, PyObject * args, PyObject * kwargs) {

    unsigned long memaddr;
    PyBytesObject * data;
    char * kwList[] = {"memaddr", "data", NULL};

    RETURN_IF(!PyArg_ParseTupleAndKeywords(args, kwargs, "kS", kwList, 
                                           &memaddr, &data), NULL);

    Py_ssize_t data_len = PyBytes_Size((PyObject *)data);
    const char * raw_data = PyBytes_AsString((PyObject *)data);

    if (memaddr >= UINT32_T_MAX) {
        PyErr_SetString(PyExc_ValueError, "memaddr too large.");
        return NULL;
    }

    struct pktlab_message mwrite_msg = {};
    mwrite_msg.type = PKTLAB_MWRITE_MESSAGE;
    mwrite_msg.mwrite.addr = (uint32_t) memaddr;
    mwrite_msg.mwrite.ptr = raw_data;
    mwrite_msg.mwrite.len = data_len;

    char enc_buf[PKTLAB_ENCODE_BUFSZ] = {};
    struct iovec msg_iov[PKTLAB_ENCODE_IOVCNT] = {};
    int msg_iovcnt;
    msg_iovcnt = pktlab_encode_message(&mwrite_msg, enc_buf, msg_iov);

    char * msg_arr;
    size_t msg_len;
    RETURN_IF(iovec_2_arr(msg_iov, msg_iovcnt, &msg_arr, &msg_len), NULL);

    PyObject * ret = PyBytes_FromStringAndSize(msg_arr, msg_len);
    free(msg_arr);

    return ret;
}

// encode npoll msg function
static PyObject *
pypl_encode_npoll_msg(PyObject * self, PyObject * args, PyObject * kwargs) {

    unsigned long long time;
    char * kwList[] = {"time", NULL};

    RETURN_IF(!PyArg_ParseTupleAndKeywords(args, kwargs, "K", kwList, &time), NULL);

    struct pktlab_message npoll_msg = {};
    npoll_msg.type = PKTLAB_NPOLL_MESSAGE;
    npoll_msg.npoll.time = time;

    char enc_buf[PKTLAB_ENCODE_BUFSZ] = {};
    struct iovec msg_iov[PKTLAB_ENCODE_IOVCNT] = {};
    int msg_iovcnt;
    msg_iovcnt = pktlab_encode_message(&npoll_msg, enc_buf, msg_iov);

    char * msg_arr;
    size_t msg_len;
    RETURN_IF(iovec_2_arr(msg_iov, msg_iovcnt, &msg_arr, &msg_len), NULL);

    PyObject * ret = PyBytes_FromStringAndSize(msg_arr, msg_len);
    free(msg_arr);

    return ret;
}



// decode msg function
static PyObject *
pypl_decode_msg(PyObject * self, PyObject * args) {

    PyBytesObject * msg;
    RETURN_IF(!PyArg_ParseTuple(args, "S", &msg), NULL);

    Py_ssize_t msg_len = PyBytes_Size((PyObject *) msg);
    const char * raw_msg = PyBytes_AsString((PyObject *) msg);

    struct pktlab_message decoded_msg = {};
    if (pktlab_decode_message(&decoded_msg, raw_msg, msg_len) == 0) {
        PyErr_SetString(PyExc_RuntimeError, "pktlab decode message failure.");
        return NULL;
    }

    PyObject * ret_dict = PyDict_New();
    PyObject * key = PyUnicode_FromString("type");
    PyObject * value = PyLong_FromLong((long) decoded_msg.type);
    RETURN_IF(dict_insert_key_value(ret_dict, key, value), NULL);

    switch (decoded_msg.type) {
        case PKTLAB_STATUS_MESSAGE:
            RETURN_IF(dict_insert_status(ret_dict, &decoded_msg), NULL);
            break;
        case PKTLAB_MDATA_MESSAGE:
            RETURN_IF(dict_insert_mdata(ret_dict, &decoded_msg), NULL);
            break;
        case PKTLAB_NDATA_MESSAGE:
            RETURN_IF(dict_insert_ndata(ret_dict, &decoded_msg), NULL);
            break;
        case PKTLAB_NSTAT_MESSAGE:
            RETURN_IF(dict_insert_nstat(ret_dict, &decoded_msg), NULL);
            break;
        default:
            PyErr_SetString(PyExc_ValueError, "Unkown message type.");
            Py_XDECREF(ret_dict);
            return NULL;
    }

    return ret_dict;
}

// real sec to pktlab time unit
static PyObject * 
pypl_pktlab_time_sec(PyObject * self, PyObject * args) {

    unsigned long sec;
    RETURN_IF(!PyArg_ParseTuple(args, "k", &sec), NULL);
    
    return PyLong_FromUnsignedLongLong((unsigned long long) sec * PKTLAB_TICKS_PER_SECOND);
}

// pktlab time unit to real sec
static PyObject * 
pypl_pktlab_time_to_unix_time(PyObject * self, PyObject * args) {

    unsigned long long t;
    RETURN_IF(!PyArg_ParseTuple(args, "K", &t), NULL);

    return PyLong_FromUnsignedLong((unsigned long) (t / PKTLAB_TICKS_PER_SECOND));
}


// Module Method Table
static PyMethodDef pyplMethods[] = {
    
    {"encode_nopen_msg", (PyCFunction) pypl_encode_nopen_msg, METH_VARARGS|METH_KEYWORDS, 
                "Encode pktlab nopen message."},
    {"encode_nsend_msg_raw", (PyCFunction) pypl_encode_nsend_msg_raw, METH_VARARGS|METH_KEYWORDS,
                "Encode pktlab nsend message for raw socket."},
    {"encode_nsend_msg_tcp", (PyCFunction) pypl_encode_nsend_msg_tcp, METH_VARARGS|METH_KEYWORDS,
                "Encode pktlab nsend message for tcp socket."},
    {"encode_nsend_msg_udp", (PyCFunction) pypl_encode_nsend_msg_udp, METH_VARARGS|METH_KEYWORDS,
                "Encode pktlab nsend message for udp socket."},
    {"encode_nsend_msg_icmp", (PyCFunction) pypl_encode_nsend_msg_icmp, METH_VARARGS|METH_KEYWORDS,
                "Encode pktlab nsend message for icmp socket."},
    {"encode_nclose_msg", (PyCFunction) pypl_encode_nclose_msg, METH_VARARGS|METH_KEYWORDS, 
                "Encode pktlab nclose message."},
    {"encode_npoll_msg", (PyCFunction) pypl_encode_npoll_msg, METH_VARARGS|METH_KEYWORDS, 
                "Encode pktlab npoll message."},
    {"encode_mread_msg", (PyCFunction) pypl_encode_mread_msg, METH_VARARGS|METH_KEYWORDS, 
                "Encode pktlab mread message."},
    {"encode_mwrite_msg", (PyCFunction) pypl_encode_mwrite_msg, METH_VARARGS|METH_KEYWORDS, 
                "Encode pktlab mwrite message."},
    {"decode_msg", (PyCFunction) pypl_decode_msg, METH_VARARGS, 
                "Decode pktlab message."},
    {"pktlab_time_sec", (PyCFunction) pypl_pktlab_time_sec, METH_VARARGS, 
                "Transform real world second to pktlab time unit."},
    {"pktlab_time_to_unix_time", (PyCFunction) pypl_pktlab_time_to_unix_time, METH_VARARGS, 
                "Transform pktlab time unit to real world second."},
    {NULL, NULL, 0, NULL}
};

// Module Definition Structure
static struct PyModuleDef pyplModuleDef = {

    // TODO
    PyModuleDef_HEAD_INIT,
    MODULE_NAME, 
    "Python wrapper for pktlab library", 
    -1,             /* size of per-interpreter state of the module,
                    or -1 if the module keeps state in global variables. */
    pyplMethods
};

// Module Init function
PyMODINIT_FUNC
PyInit_pypl(void)
{
    PyObject * module;

    RETURN_IF((module = PyModule_Create(&pyplModuleDef)) == NULL, NULL);
    RETURN_IF(add_module_obj(module), NULL);

    return module;
}
