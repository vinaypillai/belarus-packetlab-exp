# relayd.py - relay daemon for relaying pktlab messages
#

import argparse
import base64
import inspect
import os
import pypl
import select
import socket
import sys
import threading
import traceback

parser = argparse.ArgumentParser()
parser.add_argument("me_port", help="Port where measurement endpoint will connect to.", type=int)
parser.add_argument("ec_port", help="Port where experiment controller will connect to.", type=int)
args = parser.parse_args()

def log(text, label=None):
    caller_frame_record = inspect.stack()[1]
    info = inspect.getframeinfo(caller_frame_record[0])
    print_str = "({}:{}:{}): {}".format(
        os.path.basename(info.filename), info.lineno, info.function, text)
    if not label is None:
        print_str = str(label) + " " + print_str
    print(print_str, flush=True)

def open_welcome_sock(port, listen_cnt=1, blocking=True):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setblocking(blocking)
    sock.bind(("", port))
    sock.listen(listen_cnt)
    return sock

def accept_sock(sock):
    ac_sock, addr = sock.accept()
    return (ac_sock, addr)

class PktLabReader:
    def __init__(self, sock):
        self.sock = sock
        self.msg = b""
        self.indata = False
        self.remlen = 0

    def read(self):
        if len(self.msg) < pypl.PKTLAB_HLEN:
            rst = self.sock.recv(pypl.PKTLAB_HLEN - len(self.msg))
            if rst == b"":
                raise EOFError("Socket EOF")

            self.msg += rst

            if len(self.msg) == pypl.PKTLAB_HLEN:
                remlen = int.from_bytes(self.msg[1:pypl.PKTLAB_HLEN], "big")
                if remlen == 0:
                    msg = self.msg
                    self.msg = b""
                    self.indata = False
                    self.remlen = 0
                    return 1, msg
                else:
                    self.indata = True
                    self.remlen = remlen

            return 0, b""
        else:
            assert self.indata
        
            rst = self.sock.recv(self.remlen)
            if rst == b"":
                raise EOFError("Socket EOF")

            self.msg += rst
            self.remlen -= len(rst)

            if self.remlen == 0:
                msg = self.msg
                self.msg = b""
                self.indata = False
                self.remlen = 0
                return 1, msg
            
            return 0, b""

class PktLabWriter:
    def __init__(self, sock):
        self.sock = sock
        self.sentlen = 0
        self.msg = b""

    def write(self, msg):
        rst = self.sock.send(self.msg + msg)
        
        if rst + self.sentlen == len(self.msg) + len(msg):
            # sent remainder msg and also new msg
            self.sentlen = 0
            self.msg = b""
            return 1
        elif rst + self.sentlen > len(self.msg):
            # sent remainder msg and a part of new msg
            self.sentlen = rst + self.sentlen - len(self.msg)
            self.msg = msg
            return 1
        else:
            # sent only remainder msg, rejecting new msg
            self.sentlen = rst + self.sentlen
            return 0

class RelayDaemon:
    def __init__(self, meport, ecport, log_label="RELAYD"):
        self.meport = meport
        self.ecport = ecport
        self.me_sock = None
        self.ec_sock = None
        self.me_addr = ""
        self.ec_addr = ""
        self.reader = {}
        self.writer = {}
        self.dt = threading.Thread(target=self.daemon, daemon=True)
        self.log_label = log_label

        me_wsock = open_welcome_sock(meport, 0, True)
        ec_wsock = open_welcome_sock(ecport, 0, True)

        try:
            self.me_sock, self.me_addr = accept_sock(me_wsock)
        except BlockingIOError:
            pass
        me_wsock.close()
        self.me_sock.setblocking(False)

        self.reader[self.me_sock.fileno()] = PktLabReader(self.me_sock)
        self.writer[self.me_sock.fileno()] = PktLabWriter(self.me_sock)

        try:
            self.ec_sock, self.ec_addr = accept_sock(ec_wsock)
        except BlockingIOError:
            pass
        ec_wsock.close()
        self.ec_sock.setblocking(False)

        self.reader[self.ec_sock.fileno()] = PktLabReader(self.ec_sock)
        self.writer[self.ec_sock.fileno()] = PktLabWriter(self.ec_sock)

        return

    def counterpart(self, sockfd):
        if sockfd == self.me_sock.fileno():
            return self.ec_sock.fileno()
        elif sockfd == self.ec_sock.fileno():
            return self.me_sock.fileno()
        return -1

    def flush_writer(self, sockfd, msg_ls):
        msg_ls.append(b"")
        while (len(msg_ls) > 0):
            rlist, wlist, _ = select.select([sockfd], [sockfd], [])

            if len(wlist) > 0:
                try:
                    ret = self.writer[sockfd].write(msg_ls[0])
                except Exception as e:
                    log("sockfd ({}) writer exception: {}".format(sockfd, e), self.log_label)
                    log("Traceback: {}".format(
                        base64.b64encode(traceback.format_exc().encode())), self.log_label)
                    return

                if ret == 1:
                    msg_ls.pop(0)
            elif len(rlist) > 0:
                try:
                    self.reader[sockfd].read()
                except EOFError:
                    log("sockfd ({}) reader EOF".format(sockfd), self.log_label)
                    log("Traceback: {}".format(
                        base64.b64encode(traceback.format_exc().encode())), self.log_label)
                    return

        log("sockfd ({}) flushed".format(sockfd), self.log_label)
        return

    def daemon(self):
        rsocklist = [self.me_sock.fileno(), self.ec_sock.fileno()]
        wsocklist = []

        msg_buf = {self.me_sock.fileno():[], self.ec_sock.fileno():[]}

        while (True):
            log("Running select({},{})".format(rsocklist, wsocklist), self.log_label)
            rlist, wlist, _ = select.select(rsocklist, wsocklist, [])

            for sockfd in rlist:
                try:
                    ret, msg = self.reader[sockfd].read()
                except EOFError:
                    log("sockfd ({}) reader EOF".format(sockfd), self.log_label)
                    log("Traceback: {}".format(
                        base64.b64encode(traceback.format_exc().encode())), self.log_label)

                    self.flush_writer(self.counterpart(sockfd),
                        msg_buf[self.counterpart(sockfd)])
                    log("Flushed counterpart, exiting", self.log_label)
                    return
                
                if ret == 1:
                    msg_buf[self.counterpart(sockfd)].append(msg)
                    if not self.counterpart(sockfd) in wsocklist:
                        wsocklist.append(self.counterpart(sockfd))

            for sockfd in wlist:
                assert len(msg_buf[sockfd]) > 0

                try:
                    ret = self.writer[sockfd].write(msg_buf[sockfd][0])
                except Exception as e:
                    log("sockfd ({}) writer exception: {}".format(sockfd, e), self.log_label)
                    log("Traceback: {}".format(
                        base64.b64encode(traceback.format_exc().encode())), self.log_label)

                    self.flush_writer(self.counterpart(sockfd),
                        msg_buf[self.counterpart(sockfd)])
                    log("Flushed counterpart, exiting", self.log_label)
                    return

                if ret == 1:
                    msg_buf[sockfd].pop(0)
                    if len(msg_buf[sockfd]) == 0:
                        wsocklist.remove(sockfd)

    def run(self):
        self.dt.start()
        self.dt.join()
        return

def infiniteloop():
    log("Starting relay server", "INFINITE")
    relayd = RelayDaemon(args.me_port, args.ec_port)
    relayd.run()
    log("Done", "INFINITE")

if __name__ == "__main__":
    if args.me_port == args.ec_port:
        print("**Warning**: me_port and ec_port same.", file=sys.stderr)

    while (True): infiniteloop()