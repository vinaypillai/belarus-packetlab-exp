#!/bin/bash
printf -v USAGE "Usage: bash $0 CTRL_SPEC TIME_IN_SEC\n  CTRL_SPEC:\ttarget controller for pktlabme to connect to\n  TIME_IN_SEC:\tnumber of seconds to run pktlabme"

if [ "$#" -ne 2 ]; then
    echo "$USAGE"
    exit 3
fi

start=$(date +%s)
maxtime="$2"
while true; do
    cur=$(date +%s)
    if (( start+maxtime < cur )); then
        break
    fi

    ./pktlabme "$1"
done

echo "DONE"

